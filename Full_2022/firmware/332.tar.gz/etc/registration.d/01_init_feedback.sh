#!/bin/sh

#------------------------------------------------------------------
# © 2013 Belkin International, Inc. and/or its affiliates. All rights reserved.
#------------------------------------------------------------------
source /etc/init.d/feedback_registration_functions.sh	 
###############################################################################
#	Feedback Events
#
#	You may add a new line for a new feedback event
#
# 	The format of each line of a feedback event string is:
# 	name_of_event | path/filename_of_handler ;\
#
#	Optionally if the handler takes a parameter
# 	name_of_event | path/filename_of_handler | parameter ;\
#
#
###############################################################################


FEEDBACK_EVENTS="\
          system_state-normal|/etc/led/solid.sh ;\
          system_state-error|/etc/led/blink_15_sec.sh ;\
          system_state-heartbeat|/etc/led/pulsate.sh ;\
          fwupd-start|/etc/led/pulsate.sh ;\
          fwupd-success|/etc/led/solid.sh ;\
          fwupd-failed|/etc/led/blink_15_sec.sh ;\
          wps-running|/etc/led/pulsate_wps.sh ;\
          wps-success|/etc/led/solid.sh ;\
          wps-failed|/etc/led/blink_15_sec.sh ;\
          wps-stopped|/etc/led/solid.sh ;\
          led_ethernet_on|/etc/led/rear_all_default.sh ;\
          led_ethernet_off|/etc/led/rear_all_off.sh ;\		  
         "


###############################################################################
#	No need to edit below
###############################################################################
	 	 
register_events_handler "$FEEDBACK_EVENTS"


