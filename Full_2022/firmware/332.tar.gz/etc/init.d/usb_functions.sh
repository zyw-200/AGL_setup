#!/bin/sh 
source /etc/init.d/ulog_functions.sh
MODULE_PATH=/lib/modules/`uname -r`/
USB_DEVICES_DIR="/sys/bus/usb/devices"
USB_STORAGE_DIR="/sys/bus/usb/drivers/usb-storage"
USB_SILEX_DIR="/sys/bus/usb/drivers/sxuptp_driver"
STORAGE_DEVICE_SCRIPT="/etc/init.d/service_usb/mountscript.sh"
USB1_ROOT_HUB="1-0:1.0"
USB2_ROOT_HUB="2-0:1.0"
USB3_ROOT_HUB="3-0:1.0"
USB1="usb1"         #EHCI
USB2="usb2"         #XHCI         
USB3="usb3"         #OHCI
USB_CTRL_1_1="1-1"  #USB2.0 in USB Port1 (Honda, Esprit, Lemans)
USB_CTRL_1_2="1-2"  #USB2.0 in USB Port2 (Honda, Esprit, Lemans)
USB_CTRL_2_1="2-1"  #USB3.0 in USB Port1 (Honda)
USB_CTRL_3_1="3-1"  #USB1.1 in USB Port1 (Honda)
USB_CTRL_3_2="3-2"  #USB1.1 in USB Port2 (Honda)
utctx_batch_get()
{
    SYSCFG_FAILED='false'
    eval `utctx_cmd get $1`
    if [ $SYSCFG_FAILED = 'true' ] ; then
        echo "Call failed"
        return 1
    fi
}
get_usb_config_by_port_num()
{
    if [ -z "$1" ] ; then
      USB_friendly_name=
      USB_current_mode=
      return
    fi
    if [ "$1" -le `syscfg get UsbPortCount` ] ; then
      USB="UsbPort_$1"
      eval `utctx_cmd get "$USB"`
      eval NS='$'SYSCFG_$USB
              ARGS="\
              $NS::friendly_name \
              $NS::current_mode" 
      utctx_batch_get "$ARGS"
      eval `echo USB_friendly_name='$'SYSCFG_${NS}_friendly_name`
      eval `echo USB_current_mode='$'SYSCFG_${NS}_current_mode`
      ulog usb manager "USB_current_mode = $USB_current_mode"
    else
      USB_friendly_name="System_${1}"
      USB_current_mode=unused
    fi
}
provisioned_mode_to_desired_port_mode()
{
    if [ -z "$1" ] ; then
      USB_desired_mode=
      return
    fi
    echo $* | grep -q virtualUSB;
    if [ "0" = "$?" ] ; then
      echo $* | grep -q storage
      if [ "0" = "$?" ] ; then
         USB_desired_mode="detect"
      else
         USB_desired_mode="virtualUSB"
      fi
    else
      echo $* | grep -q storage
      if [ "0" = "$?" ] ; then
         USB_desired_mode="storage"
      else 
         USB_desired_mode="$1"
      fi
    fi
}
get_usb_port_info()
{
    if [ -n "$1" ] ; then
      get_usb_config_by_port_num $1
      SYSEVENT_usb_port_type=`sysevent get usb_port_${USB_port}_type`
      SYSEVENT_usb_port_state=`sysevent get usb_port_${USB_port}_state`
      SYSEVENT_usb_port_device=`sysevent get usb_port_${USB_port}_device`
    else
      USB_friendly_name=
      USB_current_mode=
      SYSEVENT_usb_port_type=
      SYSEVENT_usb_port_state=
      SYSEVENT_usb_port_device=
    fi
}
remove_usb_drivers()
{
    USB_port_count=`syscfg get UsbPortCount`
    USB_removed_port=`sysevent get usb_port_${1}_type`
    if [ "2" = "$USB_port_count" ] ; then
      if [ "1" = "$1" ] ; then
          USB_unremoved_port=`sysevent get usb_port_2_type`
      else
          USB_unremoved_port=`sysevent get usb_port_1_type`
      fi
    fi
    ulog usb manager "$PID remove_usb_drivers: port_count=$USB_port_count"
    ulog usb manager "$PID Removed usb port type=$USB_removed_port"
    case $2 in
    6)
        ulog usb manager "$PID usb camera being removed from usb_port ${1}"
    ;;
    7)
        ulog usb manager "$PID usb printer being removed from usb_port ${1}"
        [ "1" = "$USB_port_count" ] && rm_virtualusb_drivers
        [ "2" = "$USB_port_count" ] && [ "printer" != "$USB_unremoved_port" ] && rm_virtualusb_drivers 
    ;;
    8)
        ulog usb manager "$PID usb storage being removed from usb_port ${1}"
        [ "1" = "$USB_port_count" ] && rm_storage_drivers
        [ "2" = "$USB_port_count" ] && [ "storage" != "$USB_unremoved_port" ] && rm_storage_drivers
    ;;
    9)
        ulog usb manager "$PID usb hub being removed from usb_port ${1}"
    ;;
    *)
        ulog usb manager "$PID Unsupported usb device of type (${2}) is removed"
    ;;
    esac
    sysevent set usb_port_${1}_type none
    sysevent set usb_port_${1}_state down
}
add_virtualusb_drivers()
{
    MODEL=`syscfg get device modelNumber`
    if [ -n "$MODEL" ] ; then 
      PRODUCT_STRING="product=\"${MODEL}\""
    fi
    MODULE_PATH=/lib/modules/`uname -r`/
    insmod -q ${MODULE_PATH}/sxuptp_wq.ko
    insmod -q ${MODULE_PATH}/sxuptp.ko netif=br0
    insmod -q ${MODULE_PATH}/sxuptp_driver.ko
    insmod -q ${MODULE_PATH}/jcp.ko $PRODUCT_STRING
    ulog usb manager "add_virtualusb_drivers() $PRODUCT_STRING"
}
rm_virtualusb_drivers()
{
    rmmod -f jcp 2> /dev/null
    rmmod -f sxuptp_driver 2> /dev/null
    rmmod -f sxuptp 2> /dev/null
    rmmod -f sxuptp_wq 2> /dev/null
   
    ulog usb manager "remove_virtualusb_drivers()"
}
add_storage_drivers()
{
    MODULE_PATH=/lib/modules/`uname -r`/
    insmod -q ${MODULE_PATH}/usb-storage.ko
    insmod -q ${MODULE_PATH}/ufsd.ko
   
    ulog usb manager "add_storage_drivers()"
}
rm_storage_drivers()
{
    rmmod -f usb_storage 2> /dev/null
    rmmod -f ufsd 2> /dev/null
   
    ulog usb manager "remove_storage_drivers()"
}
unmount_storage_drive()
{
    
    MOUNT_DIR=`sysevent get usb_device_mount_pt_${1}`
    
    if [ ! -z "$MOUNT_DIR" ] && [ -e ${MOUNT_DIR} ] ; then
      drv="`echo $MOUNT_DIR | sed "s/\/tmp\///g"`"
      ulog usb manager "unmount and remove existed storage $drv on usb_port $1"
      `$STORAGE_DEVICE_SCRIPT remove $drv $1`
    fi
}
get_count_usb_host()
{
    USB_HOST_CNT=`ls "$USB_DEVICES_DIR" | grep -c "usb[1-9]"`
    ulog usb autodetect "$PID USB_HOST_CNT=$USB_HOST_CNT"
}
bind_silex_from_storage()
{
    [ -z "$1" ] && return
    [ ! -d "$USB_STORAGE_DIR" ] && return
    USB_ID=`echo "$1" | awk '{FS="/"}{print $NF}'`
    ulog usb autodetect "$PID bind_silex_from_storage: USB_ID=$USB_ID"
    ls "$USB_STORAGE_DIR" | grep "$USB_ID"
    [ "0" != "$?" ] && return
    echo -n "$USB_ID" > /sys/bus/usb/drivers/usb-storage/unbind
    echo -n "$USB_ID" > /sys/bus/usb/drivers/sxuptp_driver/bind
    ulog usb autodetect "$PID bind_silex_from_storage: DONE"
}
bind_storage_from_silex()
{
    [ -z "$1" ] && return
    [ ! -d "$USB_SILEX_DIR" ] && return
    USB_ID=`echo "$1" | awk '{FS="/"}{print $NF}'`
    ulog usb autodetect "$PID bind_storage_from_silex: USB_ID=$USB_ID"
    ls "$USB_SILEX_DIR" | grep "$USB_ID"
    [ "0" != "$?" ] && return
    echo -n "$USB_ID" > /sys/bus/usb/drivers/sxuptp_driver/unbind
    echo -n "$USB_ID" > /sys/bus/usb/drivers/usb-storage/bind
    ulog usb autodetect "$PID bind_storage_from_silex: DONE"
}
get_removed_usb_device_port()
{
    [ -z "$1" ] && return
    get_count_usb_host
    
    if [ "$USB_HOST_CNT" = "3" -o "$USB_HOST_CNT" = "2" ] ; then
      get_usb_port_from_multiple_host $1
    else
      USB_PORT=`echo "$1" | awk '{FS="/"}{print $NF}' | cut -d ':' -f 1`
      ulog usb autodetect "$PID get_removed_usb_device_port: USB_PORT=$USB_PORT"
      [ -z "$USB_PORT" ] && return
      CUR_USB_PORT=`echo $USB_PORT | cut -d '.' -f 2`
      [ "$USB_PORT" = "$CUR_USB_PORT" ] && USB_port="1" && return
      USB_port=`expr $CUR_USB_PORT - 2`
    fi
    
    ulog usb autodetect "$PID get_removed_usb_device_port: USB_port=$USB_port"
}
get_usb_port_from_single_host()
{
    [ -z "$1" ] && return
    ls "$USB_DEVICES_DIR" | grep -q "[1-9]-[1-9].[1-9]$"
    [ "0" != "$?" ] && USB_port="1" && return
    echo "$1" | grep -q "[1-9]-[1-9].[1-9]$"
    
    if [ "0" = "$?" ] ; then
      USB_ID="$1"
    else
      USB_ID=`echo "$1" | awk -F "/" '{ for (i=1; i<=NF; i++) if ( $i ~ /[1-9]-[1-9].[1-9]$/ ) { print $i } }'`
    fi
    ulog usb autodetect "$PID single_usb_host(USB_ID)=$USB_ID"
    
    CUR_USB_PORT=`echo "$USB_ID" | cut -d '.' -f 2`
    ulog usb autodetect "$PID single_usb_host(CUR_USB_PORT)=$CUR_USB_PORT"
    [ "$CUR_USB_PORT" = "3" ] && USB_port="1" && return
    [ "$CUR_USB_PORT" = "4" ] && USB_port="2" && return
}
get_usb_port_from_multiple_host()
{
    [ -z "$1" ] && return
    USB_PortCount=`syscfg get UsbPortCount`
    if [ "$USB_PortCount" = "2" ] ; then
      echo "$1" | grep -q "$USB1_ROOT_HUB"
      [ "0" = "$?" ] && USB_port="1" && return
      echo "$1" | grep -q "$USB2_ROOT_HUB"
      [ "0" = "$?" ] && USB_port="2" && return
      echo "$1" | grep -q "$USB3_ROOT_HUB"
      [ "0" = "$?" ] && USB_port="2" && return
      echo "$1" | grep -q "$USB_CTRL_1_1"
      [ "0" = "$?" ] && USB_port="1" && return
      echo "$1" | grep -q "$USB_CTRL_1_2"
      [ "0" = "$?" ] && USB_port="2" && return
      echo "$1" | grep -q "$USB_CTRL_2_1"
      [ "0" = "$?" ] && USB_port="1" && return
      echo "$1" | grep -q "$USB_CTRL_3_1"
      [ "0" = "$?" ] && USB_port="1" && return
      echo "$1" | grep -q "$USB_CTRL_3_2"
      [ "0" = "$?" ] && USB_port="2" && return
    else
      USB_port="1"
    fi
}
get_usb_id_from_sysblock()
{
  [ -z "$1" ] && return
  if [ -d "/sys/block/$1" ] ; then
    ulog usb autodetect "$PID /sys/block/$1 is existed"
    USB_ID=`ls -al "/sys/block/$1" | grep "device" | sed -n 's/.*\([1-9]-[1-9]:[0-9].[0-9]\).*/\1/p'`
    if [ -z "$USB_ID" ] ; then
      USB_ID=`ls -al "/sys/block/$1" | grep "device" | sed -n 's/.*\([1-9]-[1-9].[1-9]\).*/\1/p'`
    fi
    ulog usb autodetect "$PID get_usb_id_from_sysblock: USB_ID=$USB_ID"    
  fi
}
get_usb_port_from_storage_drive()
{
  [ -z "$1" ] && return
  BLOCK_DEVICE=`echo "$1" | cut -b 1-3`
  get_usb_id_from_sysblock $BLOCK_DEVICE
  get_count_usb_host
  if [ "$USB_HOST_CNT" = "3" -o "$USB_HOST_CNT" = "2" ] ; then
    get_usb_port_from_multiple_host $USB_ID
  elif [ "$USB_HOST_CNT" = "1" ] ; then
    get_usb_port_from_single_host $USB_ID
  fi
  ulog usb autodetect "$PID get_usb_port_from_storage_drive: USB_ID=$USB_ID"
  ulog usb autodetect "$PID get_usb_port_from_storage_drive: USB_port=$USB_port"
}
is_normal_usb_storage()
{
  [ ! -d "$USB_SILEX_DIR" ] && return 0
  [ -z "$1" ] && return 1
  BLOCK_DEVICE=`echo "$1" | cut -b 1-3`
  get_usb_id_from_sysblock $BLOCK_DEVICE
  [ -z "$USB_ID" ] && return 1
  ulog usb autodetect "$PID is_normal_usb_storage: USB_ID=$USB_ID"
  ls -al "$USB_SILEX_DIR" | grep -q "$USB_ID"
  [ "0" = "$?" ] && return 1
  return 0
}
