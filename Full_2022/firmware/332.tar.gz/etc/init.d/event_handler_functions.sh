source /etc/init.d/event_flags
check_err ()
{
   if [ "${1}" -ne "0" ] ; then
      ulog $SERVICE_NAME status "PID ($$) Error ($1) $2"
      sysevent set ${SERVICE_NAME}-status error
      sysevent set ${SERVICE_NAME}-errinfo "Error ($1) $2"
   fi
}
check_err_exit ()
{
   if [ "${1}" -ne "0" ] ; then
      ulog $SERVICE_NAME status "PID ($$) Error ($1) $2"
      sysevent set ${SERVICE_NAME}-status error
      sysevent set ${SERVICE_NAME}-errinfo "Error ($1) $2"
      exit ${1}
   fi
}
wait_till_end_state ()
{
  LSERVICE=$1
  TRIES=1
   while [ "20" -ge "$TRIES" ] ; do
      LSTATUS=`sysevent get ${LSERVICE}-status`
      if [ "starting" = "$LSTATUS" ] || [ "stopping" = "$LSTATUS" ] ; then
         sleep 1
         TRIES=`expr $TRIES + 1`
         if [ "$TRIES" -eq "19" ] ; then
            logger "wait_till_end_state: problem starting up ${LSERVICE}"
         fi
      else
         logger "wait_till_end_state: ${LSERVICE} - ${LSTATUS}"
         return
      fi
   done
}
fwup_updating()
{
    state=$1
    if [ -z "$state" ]; then
	state=$(sysevent get fwup_state)
    fi
    [ $state -gt 2 ] && return 0
    return 1
}
