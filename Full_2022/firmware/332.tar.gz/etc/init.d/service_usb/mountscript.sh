#!/bin/sh
source /etc/init.d/ulog_functions.sh
source /etc/init.d/usb_functions.sh 
SERVICE_NAME="usb_mountscript"
PID="($$)"
USBINFO="/tmp/.usbinfo"
all_fat="fat32 fat16" 
all_fat_id="4 6 b c e"
all_linux="ext2 ext3 ext4"
all_linux_id="83 8e"
all_ntfs="ntfs"
all_ntfs_id="7 86 87"
macOS_ufsd="hfs hfs+ hfsx"
all_macOS_id="af"
gpt_ufsd="hfs hfs+ hfsx"
all_gpt_id="ee"
moptions="defaults,fmask=0002,dmask=0002"
ufsd_debug="trace=0xffffffff,log=/var/log/ufsd.log"
ufsd_supported_fs="hfs ntfs"
check_fs()
{
   FS_NAME=$1
   PART=$2
   UTIL=/sbin/chk${FS_NAME}
   RET_CODE=
   echo $SERVICE_NAME $PID checking filesystem $FS_NAME on partition $PART
      
   if [ ! -x $UTIL ] ; then
      return 2
   fi
   
   if [ ! -e $PART ]; then
      return 3
   fi
   
   $UTIL -a -f $PART; RET_CODE=$?
   if [[ $RET_CODE -ge 0 && $RET_CODE -lt 5 ]] ; then
      return 0
   elif [ "$RET_CODE" = "4" ] ; then   # Errors found but cannot fix
      ulog usb_mountscript status "$PID found unrecoverable error on $PART"
      sysevent set ${SERVICE_NAME}-status error
      sysevent set ${SERVICE_NAME}-errinfo "Unrecoverable filesystem error"
      return 1
   elif [ "$RET_CODE" = "6" ] ; then
      return 4
   fi
   ulog usb_mountscript status "$PID found Unreconized filesystem error($RETCODE) on $PART"
   sysevent set ${SERVICE_NAME}-status error
   sysevent set ${SERVICE_NAME}-errinfo "Unreconized filesystem error"
   
   return 5
}
check_partition()
{
   PART=$1
   
   echo $SERVICE_NAME $PID checking partition $PART
   
   for fs_name in $ufsd_supported_fs
   do
      check_fs $fs_name $PART; RET_CODE=$?
      if [ ! "$RET_CODE" = "4" ] ; then
         break
      fi
   done
    
   case $RET_CODE in
      0)
         return 0
      ;;
      2)    
         ulog usb_mountscript status "$PID cannot find the chk utility"
      ;;
      3) 
         ulog usb_mountscript status "$PID bad partition $PART"
         return 1
      ;;
      4) 
         ulog usb_mountscript status "$PID unsupported file system on $PART"
         sysevent set ${SERVICE_NAME}-status error
         sysevent set ${SERVICE_NAME}-errinfo "Unsupported filesystem error"
         return 3
      ;;
      *)
      ;;
   esac
   
   return 2 
}
finish_mount_drives()
{
  numPartitions=$2
  partitionCnt=$1
  DRIVE_COUNT=0;
  DEVS=`ls /dev/ | grep -r "sd[a-z]" | uniq`
  if [ "$DEVS" != "" ] ; then
  for d in $DEVS
  do
    if [ -d "/mnt/$d" ] ; then
      mnt_pt_check=`mount | grep /tmp/mnt/$d | wc -l`
      if [ $mnt_pt_check -gt 0 ] ; then
        DRIVE_COUNT=`expr $DRIVE_COUNT + 1`
      fi
    fi
  done
  fi
  echo "DRIVE_COUNT = $DRIVE_COUNT" > /dev/console
  if [ "$numPartitions" == "$partitionCnt" ]; then
    dc=`sysevent get no_usb_drives`
    echo "setting current drive count from $dc to $DRIVE_COUNT" >> /dev/console
    sysevent set no_usb_drives $DRIVE_COUNT
    sysevent set mount_usb_drives "finished"
    sysevent set usb_no_partitions_$devblock ""
    sysevent set usb_curr_partition_cnt_$devblock ""
    usb_mount_drives=`ls "/tmp/mnt/" | grep "$devblock" | wc -l`
    sysevent set usb_mount_cnt_$devblock $usb_mount_drives
  fi
}
get_usb_size()
{
  local ret_string
  total=`df /mnt/$1/ | tail -1 | awk '{print $2}'`
  used=`df /mnt/$1/ | tail -1 | awk '{print $3}'`
  free=`df /mnt/$1/ | tail -1 | awk '{print $4}'`
  percent=`df /mnt/$1/ | tail -1 | awk '{print $5}'`
  ret_string="$total $used $free $percent"
  echo $ret_string  
}
add_sysevent_usb_info()
{
  storage_devices=`sysevent get usb_storage_devices`
  if [ -z "$storage_devices" ] ; then
    sysevent set usb_storage_devices "$1"
  else
    echo "$storage_devices" | grep -q "$1"
    if [ "$?" != "0" ] ; then
      sysevent set usb_storage_devices "$storage_devices $1"
    fi
  fi
  partitions=`sysevent get usb_${1}_partitions`
  if [ -z "$partitions" ] ; then
    sysevent set usb_${1}_partitions "$2"
  else
    sysevent set usb_${1}_partitions "$partitions $2"
  fi
  dlabel=`usblabel $2`
  dsize=`get_usb_size $2`
  sysevent set usb_${2}_status "$3"
  sysevent set usb_${2}_label "$dlabel"
  sysevent set usb_${2}_fstype "$4"
  sysevent set usb_${2}_sizes "$dsize" 
}
del_sysevent_usb_info()
{
  storage_devices=`sysevent get usb_storage_devices`
  
  if [ -n "$storage_devices" ] ; then
    echo "$storage_devices" | grep -q "$1$"
    if [ "$?" = "0" ] ; then
      storage_devices=`echo $storage_devices | sed "s/$1//g"`
    else
      storage_devices=`echo $storage_devices | sed "s/$1 //g"`
    fi
    sysevent set usb_storage_devices "$storage_devices"
  fi
  partitions=`sysevent get usb_${1}_partitions`
  
  if [ -n "$partitions" ] ; then
    echo "$partitions" | grep -q "$2$"
    if [ "$?" = "0" ] ; then
      partitions=`echo $partitions | sed "s/$2//g"`
    else
      partitions=`echo $partitions | sed "s/$2 //g"`
    fi
    sysevent set usb_${1}_partitions "$partitions"
  fi
  sysevent set usb_${1}_info 
  sysevent set usb_${2}_status
  sysevent set usb_${2}_label
  sysevent set usb_${2}_fstype
  sysevent set usb_${2}_sizes
}
del_sysevent_allusb_info()
{
  storage_devices=`sysevent get usb_storage_devices`
  
  if [ -n "$storage_devices" ] ; then
    echo "$storage_devices" | grep -q "$1$"
    if [ "$?" = "0" ] ; then
      storage_devices=`echo $storage_devices | sed "s/$1//g"`
    else
      storage_devices=`echo $storage_devices | sed "s/$1 //g"`
    fi
    sysevent set usb_storage_devices "$storage_devices"
  fi
  partitions=`sysevent get usb_${1}_partitions`
  
  if [ -n "$partitons" ] ; then
    for part in $partitons 
    do
      sysevent set usb_${part}_status
      sysevent set usb_${part}_label
      sysevent set usb_${part}_fstype
      sysevent set usb_${part}_sizes
    done
  fi
  sysevent set usb_${1}_info
  sysevent set usb_${1}_partitions
}
sysevent set ${SERVICE_NAME}-status 
sysevent set ${SERVICE_NAME}-errinfo 
if [ ! -d "/tmp/mnt" ] ; then
  mkdir -p /tmp/mnt
fi
if [ -d "/mnt/cache" ] ; then
  rm -rf /mnt/cache
fi
devblock=`echo "$2" | cut -b 1-3`
if [ "$1" == "add" ] ; then
  numPartitions=`sysevent get usb_no_partitions_"$devblock"`
  currPartition=`sysevent get usb_curr_partition_cnt_"$devblock"`
  if [ "$numPartitions" == "" ] || [ "$numPartitions" == "0" ]; then 
    numPartitions=`ls "/sys/block/$devblock/" | grep "$devblock" | wc -l`
    currPartition="1"
    sysevent set usb_no_partitions_$devblock $numPartitions
    sysevent set usb_curr_partition_cnt_$devblock "1"
  else 
    currPartition=`expr $currPartition + 1`
    sysevent set usb_curr_partition_cnt_$devblock $currPartition
  fi  
  echo "Number of Partitions: $numPartitions" > /dev/console
  echo "Loaded Partition Count: $currPartition" > /dev/console 
  disk=`echo "$2" | tr -cd [0-9]`
  partedOutput=`parted -s "/dev/$devblock" print`
  model=`echo "$partedOutput" | grep "^Model:" | awk '{print $2}'`
  totalSize=`echo "$partedOutput" | grep "^Disk" | awk '{print $3}'`
  partition_type=`echo "$partedOutput" | grep "Partition Table: " | awk '{print $3}'`
  usb_info=`sysevent get usb_${devblock}_info`
  if [ -z "$usb_info" ] ; then
    sysevent set usb_${devblock}_info "$model $totalSize $partition_type"
  fi
  if [ "$partition_type" = "gpt" ]; then 
    if [ "$disk" -ge 10 ] ; then
      partedInfo=`echo "$partedOutput" | grep '^'$disk`
    else
      partedInfo=`echo "$partedOutput" | grep '^ '$disk`
    fi
    disk_partid=`echo "$partedInfo" | awk '{print $5}'`
    disk_name=`echo "$partedInfo" | awk '{print $6}'`
    disk_flag=`echo "$partedInfo" | awk '{print $NF}'`
  
    if [ "$disk_name" = "EFI" ] && [ "$disk_flag" = "boot" ]; then
        finish_mount_drives $currPartition $numPartitions
        return 0
    fi
  elif [ "$partition_type" = "msdos" ]; then
    if [ "$disk" -ge 10 ] ; then
      disk_partid=`echo "$partedOutput" | grep '^'$disk | awk '{print $6}'`
    else
      disk_partid=`echo "$partedOutput" | grep '^ '$disk | awk '{print $6}'`
    fi
  else
    if [ "$disk" -ge 10 ] ; then
      disk_partid=`echo "$partedOutput" | grep '^'$disk | awk '{print $5}'`
    else
      disk_partid=`echo "$partedOutput" | grep '^ '$disk | awk '{print $5}'`
    fi
  fi
  if [ -z "$disk_partid" ] ; then
    disk_fmtid=`fdisk -l | grep "^/dev/$2 " | awk '{print $5}'`
  fi
  
  echo "USB disk $2 id: $disk_fmtid, format: $disk_partid " > /dev/console
fi
	
	
case $1 in
	add)
	echo "[utopia][usb hotplug] mount $1 /tmp/$2" > /dev/console
	ulog usb_mountscript hotplug "mount $1 /tmp/$2" 
	mkdir -p /tmp/$2
  chmod 0775 /tmp/$2
  
  ret_mount="mounted"
  if [ -n "$disk_partid" ] ; then
    is_linux=`echo " $all_linux " | grep -r " $disk_partid " | wc -l`
    is_fat=`echo " $all_fat " | grep -r " $disk_partid " | wc -l`
    is_ntfs=`echo " $all_ntfs " | grep -r " $disk_partid " | wc -l`
    is_macOS=`echo " $macOS_ufsd " | grep -r " $disk_partid " | wc -l`
  elif [ -n "$disk_fmtid" ] ; then
    is_linux=`echo " $all_linux_id " | grep -r " $disk_fmtid " | wc -l`
    is_fat=`echo " $all_fat_id " | grep -r " $disk_fmtid " | wc -l`
    is_ntfs=`echo " $all_ntfs_id " | grep -r " $disk_fmtid " | wc -l`
    is_macOS=`echo " $all_macOS_id " | grep -r " $disk_fmtid " | wc -l`
    is_gpt=`echo " $all_gpt_id " | grep -r " $disk_fmtid " | wc -l`
  fi
  
  if [ $is_ntfs -gt 0 ] ; then
    moptions="$moptions,nls=utf8"
    mount -t ufsd -o $moptions /dev/$2 /tmp/$2 ||
        ( /sbin/chkntfs -f /dev/$2; mount -t ufsd -o $moptions /dev/$2 /tmp/$2 )
    mkdir -p /tmp/mnt/$2; mount -o bind /tmp/$2 /tmp/mnt/$2 
  elif [ $is_macOS -gt 0 ] ; then 
    moptions="rw,nls=utf8"
    mount -t ufsd -o $moptions /dev/$2 /tmp/$2 ||
        (/sbin/chkhfs -f /dev/$2; mount -t ufsd -o $moptions /dev/$2 /tmp/$2)
    mkdir -p /tmp/mnt/$2; mount -o bind /tmp/$2 /tmp/mnt/$2 
    chown -R root:0 /tmp/mnt/$2
  elif [ $is_fat -gt 0 ] ; then 
    moptions="$moptions,utf8"
    mount -t vfat -o $moptions /dev/$2 /tmp/$2 && ( mkdir -p /tmp/mnt/$2; mount -o bind /tmp/$2 /tmp/mnt/$2 )
  elif [ $is_linux -gt 0 ] ; then 
    mount -t $disk_partid /dev/$2 /tmp/$2 && ( mkdir -p /tmp/mnt/$2; mount -o bind /tmp/$2 /tmp/mnt/$2 )
  else
    echo "$2: unsupported partion ($disk_partid): $disk_fmtid" > /dev/console
    ret_mount="unsupported" 
    rmdir /tmp/$2
    echo "removing usb info file $USBINFO/$2.nfo"
    rm -rf "$USBINFO/$2.nfo"
  fi
        if [ ! -d $USBINFO ] ; then
                mkdir -p $USBINFO
        fi
        echo "creating usb info file $USBINFO/$2.nfo"
        echo -e "pname:$2" > "$USBINFO/$2.nfo"
        drv=`echo $2 | sed -r "s/[0-9]//g"`
        echo -e "dname:$drv" >> "$USBINFO/$2.nfo"
        echo -e "label:`/usr/sbin/usblabel $2`" >> "$USBINFO/$2.nfo"
        echo -e "format:$disk_partid" >> "$USBINFO/$2.nfo"
  if [ -f "$USBINFO/$2.nfo" ] ; then
		echo -e "size:`df /tmp/$2 | grep $2 | awk '{print $2}'`"  >> "$USBINFO/$2.nfo"
		PROC_DEV="`udevadm info --query=all --name=$drv| grep PHYSDEVPATH | cut -d'/' -f6`"
		echo -e "manufacturer:`cat /sys/bus/usb/devices/$PROC_DEV/manufacturer`"  >> "$USBINFO/$2.nfo"
		echo -e "product:`cat /sys/bus/usb/devices/$PROC_DEV/product`"  >> "$USBINFO/$2.nfo"
		echo -e "speed:`cat /sys/bus/usb/devices/$PROC_DEV/speed`"  >> "$USBINFO/$2.nfo"
	fi
  
  add_sysevent_usb_info $devblock $2 $ret_mount $disk_partid 
  
  finish_mount_drives $currPartition $numPartitions
	;;
	remove)
	echo "removing usb info file $USBINFO/$2.nfo"
	rm -rf "$USBINFO/$2.nfo"
  if [ ! -z "$2" ] && [ -z "$3" ] ; then
    get_usb_port_from_storage_drive $2
  else
    USB_port="$3"
  fi
  echo "remove: disk = $2, port = $USB_port, devblock = $devblock" > /dev/console
  if [ "$devblock" = "$2" ] ; then
    del_sysevent_allusb_info $devblock $2
  else
    del_sysevent_usb_info $devblock $2
  fi
  ulog usb_mountscript hotplug "unmount $1 /tmp/$2"
  if [ -d "/tmp/$2" ] && [ -d "/tmp/mnt/$2" ] ; then
    echo "remove: unmount /tmp/$2" > /dev/console
    /usr/sbin/usbrmdrive $2
    rm -rf /tmp/$2
    rm -rf /tmp/mnt/$2
  elif [ -d "/tmp/$2" ] ; then
    rm -rf /tmp/$2
  fi
  if [ -d "/mnt/$devblock" ] ; then
    /usr/sbin/usbrmdrive $devblock
    echo "unmount $devblock" >> /dev/console
    umount /mnt/$devblock
    umount /tmp/$devblock
    rm -rf /mnt/$devblock
    rm -rf /tmp/$devblock
  fi
	;;
	
  stale)
	for f in `ls --color=none /tmp`; do
		if [ -z `mount | grep -o $f` ]; then
      echo "removing stale $f" >> /dev/console
			rm -rf /tmp/$f
			echo "removing usb info file $USBINFO/$2.nfo"
			rm -rf "$USBINFO/$2.nfo"
		fi
	done
	;;
	
esac
