#!/bin/sh
source /etc/init.d/ulog_functions.sh
source /etc/init.d/event_handler_functions.sh
SERVICE_NAME="ctf"
CTF_BYPASS_SWITCH=/proc/net/fpbypass_all
CTF_SWITCH=/proc/net/ctf
set_ctf_on ()
{
    echo 1 > $CTF_SWITCH
}
set_ctf_off ()
{
    echo 0 > $CTF_SWITCH
}
set_ctf_enable ()
{
    echo 0 > $CTF_BYPASS_SWITCH
    (sleep 1; /etc/init.d/ctf_build_bypass.sh build_bypass) &
}
set_ctf_disable ()
{
    echo 1 > $CTF_BYPASS_SWITCH
}
check_ctf_bypass ()
{
    if [ -f $CTF_BYPASS_SWITCH ]; then
        CTF_BYPASS_SUPPORTED=1
        CTF_ENABLE_FUNC=set_ctf_enable
        CTF_DISABLE_FUNC=set_ctf_disable
        if [ -f $CTF_SWITCH ]; then
            set_ctf_on
        fi
    else
        CTF_BYPASS_SUPPORTED=0
        CTF_ENABLE_FUNC=set_ctf_on
        CTF_DISABLE_FUNC=set_ctf_off
    fi
}
switch_ctf_on ()
{
    $CTF_ENABLE_FUNC
}
switch_ctf_off ()
{
    $CTF_DISABLE_FUNC
}
service_init ()
{
    eval `utctx_cmd get ctf_enable parental_control_enabled qos_enable User_Accepts_WiFi_Is_Unsecure` 
    qos_enabled=`sysevent get qos_enabled`
    check_ctf_bypass
}
service_start ()
{
    wait_till_end_state ${SERVICE_NAME}
    sysevent set ${SERVICE_NAME}-status "starting"
    ulog ${SERVICE_NAME} status "starting ${SERVICE_NAME} service"
    if [ "$SYSCFG_ctf_enable" != "1" -o \
         "$SYSCFG_User_Accepts_WiFi_Is_Unsecure" != "1" -o \
         "$qos_enabled" = "1" ]; then
        switch_ctf_off
        sysevent set ${SERVICE_NAME}-status "stopped"
        return
    fi
    if [ "$CTF_BYPASS_SUPPORTED" != "1" -a \
         "$SYSCFG_parental_control_enabled" = "1" ]; then
        switch_ctf_off
        sysevent set ${SERVICE_NAME}-status "stopped"
        return
    fi
    switch_ctf_on
    sysevent set ${SERVICE_NAME}-status "started"
}
service_stop () 
{
    wait_till_end_state ${SERVICE_NAME}
    sysevent set ${SERVICE_NAME}-status "stopping"
    ulog ${SERVICE_NAME} status "stopping ${SERVICE_NAME} service"
    switch_ctf_off
    sysevent set ${SERVICE_NAME}-status "stopped"
}
service_restart () 
{
   service_stop
   service_start
}
service_init
case "$1" in
  ${SERVICE_NAME}-start)
     service_start
     ;;
  ${SERVICE_NAME}-stop)
     service_stop
     ;;
  ${SERVICE_NAME}-restart)
     service_restart
     ;;
  qos_enabled)
     service_start
     ;;
  *)
     echo "Usage: $SELF_NAME [${SERVICE_NAME}-start|${SERVICE_NAME}-stop|${SERVICE_NAME}-restart]" >&2
     exit 3
     ;;
esac
