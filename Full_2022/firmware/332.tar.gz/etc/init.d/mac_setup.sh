#!/bin/sh

#------------------------------------------------------------------
# © 2013 Belkin International, Inc. and/or its affiliates. All rights reserved.
#------------------------------------------------------------------
source /etc/init.d/syscfg_api.sh
source /etc/init.d/nvram_api.sh

# This is a utility needed to run on Pinnacle to setup the requireed
# nvram settings if it not there. It is critical for all BCM
# library to work
# This file is unit for each product lemans/esprit/honda/f70/etc...
ET0_MAC="$1"

display_usage()
{
	echo "Please check switch mac address" > /dev/console
	exit
}

processing() {
LAN_MAC=$ET0_MAC
WAN_MAC=$ET0_MAC

#2.4G MAC address = ET0 +1
ETH1_MAC=`apply_mac_inc -m "$WAN_MAC" -i 1`
ETH1_LAST_OCT=`echo $ETH1_MAC | awk -F":" '{print $6}'`
ETH1_SUB_BASE_MAC=`echo $ETH1_MAC | awk -F":" '{print ":"$2":"$3":"$4":"$5":"}'`
ETH1_LAST_OCT_BASE_DEC=`printf '%d' "0x"$ETH1_LAST_OCT`

#CSP 524475
OCT_CHECK=`expr $ETH1_LAST_OCT_BASE_DEC % 16` # 63 % 16 = 15
if [ "$OCT_CHECK" = "15" ]; then
	VAP_OCT=`expr $ETH1_LAST_OCT_BASE_DEC / 16` # 63 / 16 = 3
	VAP_OCT=`expr $VAP_OCT \* 16` # 3 * 16 = 48  
else	
	VAP_OCT=`expr $ETH1_LAST_OCT_BASE_DEC + 1`
fi
WL1_1_LAST_OCT_BASE_DEC=$VAP_OCT
WL1_1_LAST_OCT_BASE_HEX=`printf '%x\n' $WL1_1_LAST_OCT_BASE_DEC`

OCT_CHECK=`expr $WL1_1_LAST_OCT_BASE_DEC % 16` # 63 % 16 = 15
if [ "$OCT_CHECK" = "15" ]; then
	VAP_OCT=`expr $WL1_1_LAST_OCT_BASE_DEC / 16` # 63 / 16 = 3
	VAP_OCT=`expr $VAP_OCT \* 16` # 3 * 16 = 48  
else	
	VAP_OCT=`expr $WL1_1_LAST_OCT_BASE_DEC + 1`
fi
WL1_2_LAST_OCT_BASE_DEC=$VAP_OCT
WL1_2_LAST_OCT_BASE_HEX=`printf '%x\n' $WL1_2_LAST_OCT_BASE_DEC`

#5G MAC address = ET0 +2, we reserved next 2 MAC
ETH2_MAC=`apply_mac_inc -m "$WAN_MAC" -i 2`
ETH2_LAST_OCT=`echo $ETH2_MAC | awk -F":" '{print $6}'`
ETH2_SUB_BASE_MAC=`echo $ETH2_MAC | awk -F":" '{print ":"$2":"$3":"$4":"$5":"}'`
ETH2_LAST_OCT_BASE_DEC=`printf '%d' "0x"$ETH2_LAST_OCT`

OCT_CHECK=`expr $ETH2_LAST_OCT_BASE_DEC % 16` # 63 % 16 = 15
if [ "$OCT_CHECK" = "15" ]; then
	VAP_OCT=`expr $ETH2_LAST_OCT_BASE_DEC / 16` # 63 / 16 = 3
	VAP_OCT=`expr $VAP_OCT \* 16` # 3 * 16 = 48  
else	
	VAP_OCT=`expr $ETH2_LAST_OCT_BASE_DEC + 1`
fi
WL2_1_LAST_OCT_BASE_DEC=$VAP_OCT
WL2_1_LAST_OCT_BASE_HEX=`printf '%x\n' $WL2_1_LAST_OCT_BASE_DEC`


#CSP #550396
FIRST_OCT=`echo $WAN_MAC | awk -F":" '{print $1}'`
MAC_ADMIN_LOCAL=`printf '%d' "0x"$FIRST_OCT`
MAC_ADMIN_LOCAL=`awk -v value=$MAC_ADMIN_LOCAL 'BEGIN{ s=or(2,value);print s}'`
MAC_ADMIN_LOCAL=`printf '%02x\n' $MAC_ADMIN_LOCAL`
MAC_ADMIN_LOCAL=`echo $MAC_ADMIN_LOCAL | tr '[a-z]' '[A-Z]'`

WL1_1_MAC="$MAC_ADMIN_LOCAL""$ETH1_SUB_BASE_MAC""$WL1_1_LAST_OCT_BASE_HEX"
WL1_2_MAC="$MAC_ADMIN_LOCAL""$ETH1_SUB_BASE_MAC""$WL1_2_LAST_OCT_BASE_HEX"
WL2_1_MAC="$MAC_ADMIN_LOCAL""$ETH2_SUB_BASE_MAC""$WL2_1_LAST_OCT_BASE_HEX"

LAN_MAC=`echo $LAN_MAC | tr '[a-z]' '[A-Z]'`
WAN_MAC=`echo $WAN_MAC | tr '[a-z]' '[A-Z]'`
WL0_MAC=`echo $ETH1_MAC | tr '[a-z]' '[A-Z]'`
WL1_MAC=`echo $ETH2_MAC | tr '[a-z]' '[A-Z]'`
WL1_1_MAC=`echo $WL1_1_MAC | tr '[a-z]' '[A-Z]'`
WL1_2_MAC=`echo $WL1_2_MAC | tr '[a-z]' '[A-Z]'`
WL2_1_MAC=`echo $WL2_1_MAC | tr '[a-z]' '[A-Z]'`

#This is common for all platforms -- Hardwaer MAC policy
syscfg_set lan_mac_addr $LAN_MAC
syscfg_set wan_mac_addr $WAN_MAC
syscfg_set wl0_mac_addr $WL0_MAC
syscfg_set wl1_mac_addr $WL1_MAC
syscfg_set wl0.1_mac_addr $WL1_1_MAC
syscfg_set wl0.2_mac_addr $WL1_2_MAC
syscfg_set wl1.1_mac_addr $WL2_1_MAC

#This is native to the platform, depending to platform
#the nvram wl0/1 has different meaning for 2.4/5G
nvram_set lan_hwaddr $LAN_MAC
nvram_set et0macaddr $LAN_MAC
nvram_set hw_mac_addr $WAN_MAC
nvram_set wl0_hwaddr $WL0_MAC
nvram_set wl1_hwaddr $WL1_MAC
nvram_set wl0.1_hwaddr $WL1_1_MAC
nvram_set wl0.2_hwaddr $WL1_2_MAC
nvram_set wl1.1_hwaddr $WL2_1_MAC

#Customize for each platform
nvram_set lan_ifname br0
nvram_set br0_ifnames "vlan1 eth1 eth2 wl0.2"
nvram_set lan_ifnames "vlan1 eth1 eth2 wl0.2"
nvram_set vlan1_ifname br0
nvram_set wl0_ifname eth1
nvram_set wl1_ifname eth2
nvram_set lan1_ifname br1
nvram_set wl0.1_ifname wl0.1
nvram_set wl0.2_ifname wl0.2
nvram_set wl1.1_ifname wl1.1
nvram_set lan1_ifnames wl0.1

# these are already set to default by set_nvram_defaults
# and could be overwritten by switch_config based on syscfg
#nvram_set wan_ifnames vlan2
#nvram_set wan_ifname vlan2

#do NOT control the LED by WPS daemon
nvram_unset gpio8
}

default_wifi_network() {
	DEFAULT_SSID=`syscfg get device::default_ssid`
	DEFAULT_PASSPHRASE=`syscfg get device::default_passphrase`
	syscfg_set wl0_ssid "$DEFAULT_SSID"
	syscfg_set wl0_passphrase "$DEFAULT_PASSPHRASE"
	syscfg_set wl1_ssid "${DEFAULT_SSID}_5GHz"
	syscfg_set wl1_passphrase "$DEFAULT_PASSPHRASE"
}

if [ -z "$ET0_MAC" ]; then
	display_usage
else
	processing
	VALIDATED=`syscfg get wl_params_validated`
	if [ "true" != "$VALIDATED" ]; then
		default_wifi_network
		syscfg_set wl_params_validated true
	fi
	syscfg_commit
	nvram_commit
fi

exit 0
