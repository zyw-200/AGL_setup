#!/bin/sh
source /etc/init.d/addr_functions.sh
LOCKFILE=/tmp/ctf_build_bypass.lock
lock()
{
    lockfile=$1
    lockwait=${2:-5}
    for i in `seq 1 "$lockwait"`; do
        if (set -o noclobber; echo "$$" > "$lockfile") 2> /dev/null; then
            trap 'rm -f "$lockfile"; exit $?' INT TERM EXIT;
            return 0;
        fi
        sleep 1
    done
    return 1
}
unlock()
{
    lockfile=$1
    rm -f "$lockfile"
    trap - INT TERM EXIT
}
build_bypass_for_parental_control()
{
    pmax=`syscfg get parental_control_policy_count`
    for pidx in `seq 1 "$pmax"`; do
        policy=`syscfg get parental_control_policy_$pidx`
        dmax=`syscfg get $policy::blocked_device_count`
        for didx in `seq 1 "$dmax"`; do
            mac=`syscfg get $policy::blocked_device_$didx`
            addr_get_ipv4_from_mac $mac
            if [ ! -z "$ADDR_IPV4" ]; then
                echo $ADDR_IPV4 > /proc/net/fpbypass_ipv4_add
            fi
        done
    done
}
rebuild_bypass_list()
{
    lock $LOCKFILE
    if [ "$?" -eq 0 ]; then
        eval `utctx_cmd get ctf_enable parental_control_enabled`
        if [ "$SYSCFG_ctf_enable" -eq 1 ]; then
            echo 1 > /proc/net/fpbypass_ipv4_clear
            if [ "$SYSCFG_parental_control_enabled" -eq "1" ]; then
                build_bypass_for_parental_control
            fi
        fi
        unlock $LOCKFILE
    fi
}
set_lan_net()
{
    if [ -f /proc/net/fpbypass_ipv4_set_lan ]; then
        lan_ipaddr=`syscfg get lan_ipaddr`
        lan_netmask=`syscfg get lan_netmask`
        echo "$lan_ipaddr $lan_netmask" > /proc/net/fpbypass_ipv4_set_lan
    fi
}
unset_lan_net()
{
    if [ -f /proc/net/fpbypass_ipv4_set_lan ]; then
        echo "0.0.0.0 0.0.0.0" > /proc/net/fpbypass_ipv4_set_lan
    fi
}
set_wan_ip()
{
    if [ -f /proc/net/fpbypass_ipv4_set_wan ]; then
        wan_ip=`sysevent get ipv4_wan_ipaddr`
        echo "$wan_ip" > /proc/net/fpbypass_ipv4_set_wan
    fi
}
unset_wan_ip()
{
    if [ -f /proc/net/fpbypass_ipv4_set_wan ]; then
        echo "0.0.0.0" > /proc/net/fpbypass_ipv4_set_wan
    fi
}
if [ ! -f /proc/net/fpbypass_all ]; then
    exit 0
fi
case "$1" in
    lan_dhcp_client_change)
        rebuild_bypass_list
        ;;
    lan_device_detected)
        rebuild_bypass_list
        ;;
    lan_arpdevice_detected)
        rebuild_bypass_list
        ;;
    lan_nbtdevice_detected)
        rebuild_bypass_list
        ;;
    lan-started)
        set_lan_net
        ;;
    lan-stopped)
        unset_lan_net
        ;;
    ipv4_wan_ipaddr)
        set_wan_ip
        ;;
    wan-stopped)
        unset_wan_ip
        ;;
    build_bypass)
        rebuild_bypass_list
        ;;
esac
