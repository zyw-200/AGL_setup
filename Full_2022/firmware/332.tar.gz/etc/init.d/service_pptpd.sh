#!/bin/sh

#------------------------------------------------------------------
# © 2013 Belkin International, Inc. and/or its affiliates. All rights reserved.
#------------------------------------------------------------------


#------------------------------------------------------------------
#             handler_template.sh 
#------------------------------------------------------------------

source /etc/init.d/ulog_functions.sh
source /etc/init.d/event_handler_functions.sh

#------------------------------------------------------------------
# name of this service
# This name MUST correspond to the registration of this service.
# Usually the registration occurs in /etc/registration.
# The registration code will refer to the path/name of this handler
# to be activated upon default events (and other events)
#------------------------------------------------------------------
SERVICE_NAME="pptpd"


CONF_FILE="/tmp/etc/pptpd.conf"
OPTS_FILE="/etc/ppp/pptpd-options"
AUTH_FILE="/etc/ppp/chap-secrets"


#-----------------------------------------------------------------
# SYSCFG VALUES USED
#
# pptpd::enabled
# pptpd::debug
# pptpd::localip
# pptpd::remoteip
# pptpd::mdnsip
# pptpd::user_#_name
# pptpd::user_#_pass
# pptpd::use_mppe
# pptpd::use_netbios
#-----------------------------------------------------------------
#-----------------------------------------------------------------
# PPTPD DEFAULT VALUES
#
# dfc_enabled="0"
dfc_debug="0"
dfc_localip="10.0.0.1"
dfc_remoteip="10.0.0.200"
dfc_mdnsip="10.0.0.1"
dfc_username="hansolo"
dfc_password="chewbacca"
dfc_use_mppe="1"
dfc_use_netbios="1"
#-----------------------------------------------------------------


get_net_ip_range() {
	echo -n "$1" | cut -d '.' -f1,2,3
}

get_last_octet() {
	echo -n "$1" | cut -d '.' -f4
}


#-----------------------------------------------------------------
# create_conf_file
#
# These are examples of how a configuration file can be created
# They are just here as a guideline
#-----------------------------------------------------------------
create_conf_file () {
	mkdir -p `dirname "$CONF_FILE"`
	LOCAL_IP="`syscfg get pptpd::localip`"
	if [ ! "$LOCAL_IP" ] ; then
		LOCAL_IP="$dfc_localip"
		echo "$SERVICE_NAME using default localip $LOCAL_IP"
		syscfg set pptpd::localip "$LOCAL_IP"
	fi
	echo "localip $LOCAL_IP" > $CONF_FILE
	echo "" >> $CONF_FILE
	
	REMOTE_IP="`syscfg get pptpd::remoteip`"
	if [ ! "$REMOTE_IP" ] ; then
		REMOTE_IP="$dfc_remoteip"
		echo "$SERVICE_NAME using default remoteip $REMOTE_IP"
		LAST_OCTET=$(get_last_octet $REMOTE_IP)
		END_RANGE="`expr $LAST_OCTET + 10`"
		if [ "$END_RANGE" -gt "254" ] ; then
			END_RANGE="254"
		fi
		syscfg set pptpd::remoteip "${REMOTE_IP}"
	fi
	echo "remoteip ${REMOTE_IP}-${END_RANGE}" >> $CONF_FILE
	# echo "$SERVICE_NAME conf file created" >> /dev/console
}

create_opts_file () {
	mkdir -p `dirname "$OPTS_FILE"`
	MDNS_IP="`syscfg get pptpd::mdnsip`"
	if [ ! "$MDNS_IP" ] ; then
		MDNS_IP="$dfc_mdnsip"
		echo "$SERVICE_NAME using default mdnsip $MDNS_IP"
		syscfg set pptpd::mdnsip "$MDNS_IP"
	fi
	CFG_DEBUG="`syscfg get pptpd::debug`"
	if [ ! "$CFG_DEBUG" ] ; then
		CFG_DEBUG="$dfc_debug"
		syscfg set pptpd::debug "$CFG_DEBUG"
	fi
	echo ""  > $OPTS_FILE
	echo "lock" >> $OPTS_FILE
	if [ "`syscfg get pptpd::debug`" == "1" ] ; then
		echo "debug" >> $OPTS_FILE
	fi
	echo "name PPTPD" >> $OPTS_FILE
	# echo "remotename PPTPD" >> $OPTS_FILE
	echo "proxyarp" >> $OPTS_FILE
	echo "asyncmap 0" >> $OPTS_FILE
	echo "-chap" >> $OPTS_FILE
	echo "-mschap" >> $OPTS_FILE
	echo "+mschap-v2" >> $OPTS_FILE
	USE_MPPE="`syscfg get pptpd::use_mppe`"
	if [ ! "$USE_MPPE" ] ; then
		USE_MPPE="$dfc_use_mppe"
		syscfg set pptpd::use_mppe "$USE_MPPE"
	fi
	if [ "$USE_MPPE" == "1" ] ; then
		echo "require-mppe-128" >> $OPTS_FILE
		# echo "require-mppe" >> $OPTS_FILE
	fi
	echo "lcp-echo-failure 30" >> $OPTS_FILE
	echo "lcp-echo-interval 5" >> $OPTS_FILE
	echo "ipcp-accept-local" >> $OPTS_FILE
	echo "ipcp-accept-remote" >> $OPTS_FILE
# 	echo "" >> $OPTS_FILE
# 	echo "" >> $OPTS_FILE
#	echo "$SERVICE_NAME opts file created" >> /dev/console
}

create_auth_file () {
	mkdir -p `dirname "$AUTH_FILE"`
	echo "" > "$AUTH_FILE"
	
	DEFAULT_USER="1"
	for i in `seq 1 10`
	do
		USER="`syscfg get pptpd::user_${i}_name`"
		if [ "$USER" != "" ] ; then
			DEFAULT_USER="0"
			VPN_PASSWORD="`syscfg get pptpd::user_${i}_pass`"
			echo -e "$USER\tPPTPD\t$VPN_PASSWORD\t*\n" >> $AUTH_FILE
		fi
	done
	if [ "$DEFAULT_USER" == "1" ] ; then
		VPN_USER="$dfc_username"
		echo "$SERVICE_NAME using default vpn user $VPN_USER"
		VPN_PASSWORD="$dfc_password"
		echo "$SERVICE_NAME using default vpn password $VPN_PASSWORD"
		echo -e "$VPN_USER\tPPTPD\t$VPN_PASSWORD\t*\n" > $AUTH_FILE
  fi
  sed -i '/^$/d' $AUTH_FILE
  # echo "$SERVICE_NAME auth file created" >> /dev/console
}


#----------------------------------------------------------------------------------------
#                     Default Event Handlers
#
# Each service has three default events that it should handle
#    ${SERVICE_NAME}-start
#    ${SERVICE_NAME}-stop
#    ${SERVICE_NAME}-restart
#
# For each case:
#   - Clear the service's errinfo
#   - Set the service's status 
#   - Do the work
#   - Check the error code (check_err will set service's status and service's errinfo upon error)
#   - If no error then set the service's status
#----------------------------------------------------------------------------------------

#-------------------------------------------------------------------------------------------
#  function   : service_init
#  - optional procedure to retrieve syscfg configuration data using utctx_cmd
#    this is a protected way of accessing syscfg
#-------------------------------------------------------------------------------------------
service_init ()
{
	echo "$SERVICE_NAME service_init"
	ena="`syscfg get pptpd::enabled`"
	if [ "$ena" == "1" ] ; then
		echo "$SERVICE_NAME running $1"
	else
		if [ "$ena" == "" ] ; then
				echo "$SERVICE_NAME not enabled in syscfg" >> /dev/console
				exit 1
		fi
	fi
	
}

#-------------------------------------------------------------------------------------------
#  function   : service_start
#  - Set service-status to starting
#  - Add code to read normalized configuration data from syscfg and/or sysevent 
#  - Create configuration files for the service
#  - Start any service processes 
#  - Set service-status to started
#
#  check_err will check for a non zero return code of the last called function
#  set the service-status to error, and set the service-errinfo, and then exit
#-------------------------------------------------------------------------------------------
service_start ()
{
    if [ "`syscfg get pptpd::enabled`" != "1" ] ; then
        return
    fi
  # wait_till_end_state will wait a reasonable amount of time waiting for ${SERVICE_NAME}
  # to finish transitional states (stopping | starting)
  wait_till_end_state ${SERVICE_NAME}
   
  if [ "`sysevent get ${SERVICE_NAME}-delay_start`" == "" ] ; then
		# echo "delay start of pptpd VPN until settled" >> /dev/console
		sleep 15
		sysevent set ${SERVICE_NAME}-delay_start done
  fi
	service_init
	STATUS=`sysevent get ${SERVICE_NAME}-status`
	if [ "started" != "$STATUS" ] ; then
		sysevent set ${SERVICE_NAME}-errinfo 
		sysevent set ${SERVICE_NAME}-status starting
		create_conf_file
		create_opts_file
		create_auth_file
		#insmod /lib/modules/3.2.27/ppp_mppe.ko
		modprobe ppp_mppe
		/usr/local/sbin/pptpd -c $CONF_FILE -o $OPTS_FILE -d
		USE_NETBIOS="`syscfg get pptpd::use_netbios`"
		if [ ! "$USE_NETBIOS" ] ; then
			USE_NETBIOS="$dfc_use_netbios"
			syscfg set pptpd::use_netbios "$USE_NETBIOS"
		fi
		check_err $? "Couldnt handle start"
		sysevent set ${SERVICE_NAME}-status started
	fi
	
	if [ -f "/usr/local/sbin/VPNconf.cgi" ] ; then
		if [ ! -f "/tmp/www/VPNconf.cgi" ] ; then
			echo "creating dev link for VPN web configuration..."
			mkdir -p /tmp/www
			cp /usr/local/sbin/VPNconf.cgi /tmp/www/VPNconf.cgi
		fi
	fi
}

#-------------------------------------------------------------------------------------------
#  function   : service_stop
#  - Set service-status to stopping
#  - Stop any service processes 
#  - Delete configuration files for the service
#  - Set service-status to stopped
#
#  check_err will check for a non zero return code of the last called function
#  set the service-status to error, and set the service-errinfo, and then exit
#-------------------------------------------------------------------------------------------
service_stop ()
{
   # wait_till_end_state will wait a reasonable amount of time waiting for ${SERVICE_NAME}
   # to finish transitional states (stopping | starting)
   wait_till_end_state ${SERVICE_NAME}

   STATUS=`sysevent get ${SERVICE_NAME}-status`
   if [ "stopped" != "$STATUS" ] ; then
      sysevent set ${SERVICE_NAME}-errinfo 
      sysevent set ${SERVICE_NAME}-status stopping
      killall -9 pptpd
      rmmod ppp_mppe
      USE_NETBIOS="`syscfg get pptpd::use_netbios`"
# 			if [ "$USE_NETBIOS" == "1" ] ; then
# 				brctl delif br0 ppp0
# 			fi
      check_err $? "Couldnt handle stop"
      sysevent set ${SERVICE_NAME}-status stopped
   fi
#   if [ -f "/tmp/www/VPNconf.cgi" ] ; then
# 		rm -rf /tmp/www/VPNconf.cgi
# 	fi
}

#-------------------------------------------------------------------------------------------
# Entry
# The first parameter $1 is the name of the event that caused this handler to be activated
# The second parameter $2 is the value of the event or "NULL" if there is no value
# The other parameters are given if parameters passing was defined in the sysevent async call
#-------------------------------------------------------------------------------------------



case "$1" in
   ${SERVICE_NAME}-start) 
      service_start
      ;;
   ${SERVICE_NAME}-stop)
      service_stop
      ;;
   ${SERVICE_NAME}-restart)
      service_stop
      service_start
      ;;
   #----------------------------------------------------------------------------------
   # Add other event entry points here
   #----------------------------------------------------------------------------------
	 lan-status)
		  if [ "$2" == "started" ]; then
         service_start
      elif [ "$2" == "stopped" ]; then
         service_stop
      fi
			;;
   *)
      echo "Usage: $SERVICE_NAME [ ${SERVICE_NAME}-start | ${SERVICE_NAME}-stop | ${SERVICE_NAME}-restart]" > /dev/console
      exit 3
      ;;
esac
