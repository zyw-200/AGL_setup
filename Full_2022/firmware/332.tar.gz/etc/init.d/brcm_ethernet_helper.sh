get_ethernet_port ()
{
   if [ "$1" = "0" ] ; then
      PORT=0x10
   elif [ "$1" = "1" ] ; then
      PORT=0x12
   elif [ "$1" = "2" ] ; then
      PORT=0x14
   elif [ "$1" = "3" ] ; then
      PORT=0x16
   elif [ "$1" = "4" ] ; then
      PORT=0x18
   elif [ "$1" = "5" ] ; then
      PORT=0x1A
   elif [ "$1" = "6" ] ; then
      PORT=0x1C
   elif [ "$1" = "7" ] ; then
      PORT=0x1E
   elif [ "$1" = "8" ] ; then
      PORT=0x20
   else
      PORT=0 
   fi
}
enable_vlan_mode_on_ethernet_switch ()
{
   CURRENT=`et robord 0x34 0x00`
   HIGHBITS=`echo "$CURRENT" | awk '{print substr($0,3,2)}'`
   LOWBITS=`echo "$CURRENT" | awk '{print substr($0,6,1)}'`
   et robowr 0x34 0x00 0x${HIGHBITS}e${LOWBITS}
}
disable_vlan_mode_on_ethernet_switch ()
{
   CURRENT=`et robord 0x34 0x00`
   HIGHBITS=`echo "$CURRENT" | awk '{print substr($0,3,2)}'`
   LOWBITS=`echo "$CURRENT" | awk '{print substr($0,6,1)}'`
   et robowr 0x34 0x00 0x${HIGHBITS}0${LOWBITS}
}
enable_port_qos_on_ethernet_switch ()
{
   et robowr 0x30 0x62 0xFA50
   et robowr 0x30 0x80 0x00
   et robowr 0x30 0x81 0x06
   et robowr 0x30 0x82 0x0C
   et robowr 0x30 0x83 0x18
   et robowr 0x30 0x84 0x30
   CURRENT=`et robord 0x30 0x00`
   HIGHBITS=`echo "$CURRENT" | awk '{print substr($0,3,2)}'`
   LOWBITS=`echo "$CURRENT" | awk '{print substr($0,6,1)}'`
   et robowr 0x30 0x00 0x${HIGHBITS}4${LOWBITS}
}
disable_port_qos_on_ethernet_switch ()
{
   CURRENT=`et robord 0x30 0x00`
   HIGHBITS=`echo "$CURRENT" | awk '{print substr($0,3,2)}'`
   LOWBITS=`echo "$CURRENT" | awk '{print substr($0,6,1)}'`
   et robowr 0x30 0x00 0x${HIGHBITS}0${LOWBITS}
   et robowr 0x30 0x80 0x00
   et robowr 0x30 0x62 0x0000
   et robowr 0x30 0x81 0x01
   et robowr 0x30 0x82 0x02
   et robowr 0x30 0x83 0x04
   et robowr 0x30 0x84 0x08
}
set_vlan_on_ethernet_port ()
{
   get_ethernet_port $1
   if [ "0" = "$PORT" ] ; then
      return 0
   fi
   TAG=`et robord 0x34 $PORT`
   PRIO=`echo "$TAG" | awk '{print substr($0,3,1)}'`
   et robowr 0x34 $PORT 0x${PRIO}`printf "%03x" $2`
}
set_prio_on_ethernet_port ()
{
   get_ethernet_port $1
   if [ "0" = "$PORT" ] ; then
      return 0
   fi
   TAG=`et robord 0x34 $PORT`
   VLAN=`echo "$TAG" | awk '{print substr($0,4,4)}'`
   et robowr 0x34 $PORT 0x`printf "%01x" $2`${VLAN}
}
vendor_block_dos_land_attack ()
{
    et robowr 0x36 0x00 0x0003
    et robowr 0x36 0x10 0x01
}
