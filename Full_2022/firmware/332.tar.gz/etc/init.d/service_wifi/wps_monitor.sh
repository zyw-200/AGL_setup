#!/bin/sh
CLIENT_MAC=""
INTERFACE=""
TIMEOUT="true"
IS_WPS_RUNNING=`sysevent get user_trigger_wps`
if [ "1" != "$IS_WPS_RUNNING" ]; then
	return
fi
MAXWAIT=120
CNT=0;
echo "Start wps_monitor.sh" > /dev/console
sysevent set wl_wps_progress $CNT
sysevent set wps_cancelled 0 
while [ $CNT -lt $MAXWAIT ]
do
	STATE=`nvram get wps_proc_status`
	if [ "2" = "$STATE" ]; then
		sysevent set wl_wps_status "success"
		sysevent set wps-success
		echo "WPS done successful" > /dev/console
		TIMEOUT="false"
		break;
	fi
	sleep 2;
	CNT=`expr $CNT + 2`
	sysevent set wl_wps_progress $CNT
	CANCELLED=`sysevent get wps_cancelled`
	if [ "1" = "$CANCELLED" ]; then
		break;
	fi
done
if [ "true" = "$TIMEOUT" ]; then
	sysevent set wl_wps_status "false"
	sysevent set wps-failed
	echo "WPS timeout. Checking status STATE=$STATE" > /dev/console
fi
echo "WPS run in $CNT second(s)" > /dev/console
sysevent set user_trigger_wps 0
