source /etc/init.d/syscfg_api.sh
PHYSICAL_SETTINGS="state channel radio_band sideband network_mode security_mode wmm_ps stbc emf_wmf cts_protection_mode transmission_rate n_transmission_rate transmission_power grn_field_pre ht_dup_mcs32 beacon_interval dtim_interval fragmentation_threshold rts_threshold wl_wmm_support wl_no_acknowledgement txbf_enabled 256qam_enabled" 
VIRTUAL_SETTINGS="key_0 key_1 key_2 key_3 wps_user_setting tc_vap_enabled wl_access_restriction wl_mac_filter ssid encryption passphrase radius_port shared tx_key ap_isolation frame_burst radius_server ssid_broadcast guest_lan_ipaddr guest_lan_netmask guest_enabled guest_ssid wl1_guest_ssid guest_ssid_broadcast wl1_guest_ssid_broadcast guest_password wl1_guest_password"
NOT_INTERFACE_SPECIFIC="wps_user_setting wl_access_restriction wl_mac_filter emf_wmf wl_wmm_support tc_vap_enabled wl_no_acknowledgement guest_lan_ipaddr guest_lan_netmask guest_enabled guest_ssid wl1_guest_ssid guest_ssid_broadcast wl1_guest_ssid_broadcast guest_password wl1_guest_password"
PHYSICAL_IF_LIST=`syscfg get lan_wl_physical_ifnames`
PHYSICAL_ACTION="wifi_physical_action"
VIRTUAL_ACTION="wifi_virtual_action"
WIFI_USER="wifi_user"
WIFI_WL0_GUEST="wifi_guest"
WIFI_WL1_GUEST="wifi_wl1_guest"
WIFI_SIMPLETAP="wifi_simpletap"
USER_VIR_IF_INDEX=0
GUEST_VIR_IF_INDEX=1
TC_VIR_IF_INDEX=2
WL_MACFILTER_ENABLED=`syscfg get wl_access_restriction`
get_syscfg_interface_name()
{
	WL_NAME=`syscfg get "$1"_syscfg_index`
	echo "$WL_NAME"
}
syscfg_nvram_map()
{
	TRANS_INDEX=$1
	NEED_MAP=`syscfg get eth1_syscfg_index`
	if [ "wl0" = "$TRANS_INDEX" ] && [ "wl1" = "$NEED_MAP" ]; then
		TRANS_INDEX="wl1"
	elif [ "wl1" = "$TRANS_INDEX" ] && [ "wl1" = "$NEED_MAP" ]; then
		TRANS_INDEX="wl0"
	fi
	echo "$TRANS_INDEX"
}
get_mac()
{
   OUR_MAC=`ip link show $1 | grep link | awk '{print $2}'`
   echo $OUR_MAC
}
incr_mac() 
{
	COUNTER=$2
	LAST_BYTE=`echo $1 | awk 'BEGIN { FS = ":" } ; { printf ("%d", "0x"$6) }'`
	while [ $COUNTER -gt 0 ]
	do
	T_BYTE=`expr $LAST_BYTE + 1`  
	if [ "255" = "$T_BYTE" ] ; then
		T_BYTE=00
	fi
	LAST_BYTE=$T_BYTE
	COUNTER=`expr $COUNTER - 1`
	done
	INCREMENTED_BYTE=`echo $LAST_BYTE | awk '{printf ("%02X", $1) }'`
	TRUNCATED_MAC=`echo $1 | awk 'BEGIN { FS = ":" } ; { printf ("%02X:%02X:%02X:%02X:%02X:", "0x"$1, "0x"$2, "0x"$3, "0x"$4, "0x"$5) }'`
	REPLACED_MAC="$TRUNCATED_MAC""$INCREMENTED_BYTE"
	echo "$REPLACED_MAC"
}
increment_MAC() 
{
	IS_MAC_ADMIN=$1
	BASE_PHY_MACADDR=$2
	INCREMENT=$3
	if [ "$IS_MAC_ADMIN" = "true" ] || [ "$IS_MAC_ADMIN" = "TRUE" ]; then
		FIRST_BYTE=`echo $BASE_PHY_MACADDR | awk -F":" '{print $1}'`
		MIDDLE_BYTES=`echo $BASE_PHY_MACADDR | awk -F":" '{print $2":"$3":"$4":"$5}'`
		LAST_BYTE=`echo $BASE_PHY_MACADDR | awk -F":" '{print $6}'`
		LAST_BYTE_HEX=`printf '%d' "0x"$LAST_BYTE`
		MAC_ADMIN_LOCAL=`printf '%d' "0x"$FIRST_BYTE`
		MAC_ADMIN_LOCAL=`awk -v value=$MAC_ADMIN_LOCAL 'BEGIN{ s=or(2,value);print s}'`
		MAC_ADMIN_LOCAL=`printf '%02x\n' $MAC_ADMIN_LOCAL`
		MAC_ADMIN_LOCAL=`echo $MAC_ADMIN_LOCAL | tr '[a-z]' '[A-Z]'`
		BYTE_CHECK=`expr $LAST_BYTE_HEX % 16` # 63 % 16 = 15  
		if [ "$BYTE_CHECK" = "15" ]; then
			LAST_BYTE_INC=`expr $LAST_BYTE_HEX / 16` # 63 / 16 = 3
			LAST_BYTE_INC=`expr $LAST_BYTE_INC \* 16` # 3 * 16 = 48  
		else	
			LAST_BYTE_INC=`expr $LAST_BYTE_HEX + $INCREMENT`
		fi	
		LAST_BYTE_INC_HEX=`printf '%02x\n' $LAST_BYTE_INC`
		LAST_BYTE_INC_HEX=`echo $LAST_BYTE_INC_HEX | tr '[a-z]' '[A-Z]'`
		newMAC="$MAC_ADMIN_LOCAL"":$MIDDLE_BYTES"":$LAST_BYTE_INC_HEX"
	else
		newMAC=`incr_mac "$BASE_PHY_MACADDR" "$INCREMENT"`
		newMAC=`echo $newMAC | tr '[a-z]' '[A-Z]'`
	fi
	echo "$newMAC"
}
convert_v4_2_v6() 
{
   V6=`echo $1 | awk 'BEGIN { FS = "." } ; { printf ("%02x%02x:%02x%02x", $1, $2, $3, $4) }'`
   echo "$V6"
}
add_interface_to_bridge()
{
	VAP=$1
	BRIDGE=$2
	if [ -z "$BRIDGE" ]; then	 
		ulog wlan status "${SERVICE_NAME}, add_interface_to_bridge(), bridge name is empty"
		return 1
	fi
	TEMP=`brctl show | grep ${BRIDGE} | awk '{print $1}'`
	if [ "$BRIDGE" = "$TEMP" ]; then
		MAC_1=`get_mac ${VAP}`
		if [ ! -z "$MAC_1" ]; then	 
			ip link set $VAP allmulticast on
			ip link set $VAP up
			MAC_2=`brctl showmacs ${BRIDGE} | grep ${MAC_1} | awk '{print $2}'`
			if [ "${MAC_1}" = "${MAC_2}" ]; then
				brctl delif $BRIDGE $VAP
			fi
			brctl addif $BRIDGE $VAP
		fi
	fi 
}
delete_interface_from_bridge()
{
	VAP=$1
	BRIDGE=$2
	ip link set $VAP allmulticast off
	ip link set $VAP down	
	if [ -z "$BRIDGE" ]; then	 
		ulog wlan status "${SERVICE_NAME}, delete_interface_to_bridge(), bridge name is empty"
		return 1
	fi
	TEMP=`brctl show | grep ${BRIDGE} | awk '{print $1}'`
	if [ "$BRIDGE" = "$TEMP" ]; then 
		MAC_1=`get_mac ${VAP}`
		if [ ! -z "$MAC_1" ]; then	 
			MAC_2=`brctl showmacs ${BRIDGE} | grep ${MAC_1} | awk '{print $2}'`
			if [ "${MAC_1}" = "${MAC_2}" ]; then
				brctl delif $BRIDGE $VAP
			fi
		fi
	fi 
}
restart_required ()
{
	MODE=$1
	WL=$2
	RESTART=0
	FILENAME=/tmp/wifi_"$MODE"_settings.conf
	CHANGED_FILE=/tmp/wifi_changed_settings.conf
	if [ ! -f $FILENAME ]; then
		create_files
		return 1
	fi
	if [ "physical" = "$MODE" ]; then
		INFO_NEEDED=$PHYSICAL_SETTINGS
	elif [	"virtual" = "$MODE" ]; then
		INFO_NEEDED=$VIRTUAL_SETTINGS
	fi
	if [ -f $FILENAME ]; then
		for FIELD in $INFO_NEEDED; do
			VARIABLE="$WL"_"$FIELD"
			for TEMP in $NOT_INTERFACE_SPECIFIC; do
				if [ "$FIELD" = "$TEMP" ]; then
					VARIABLE="$FIELD"
					break;
				fi
			done
			INFO=`syscfg get ${VARIABLE}`
			FIELD_DATA="$VARIABLE":" $INFO"
			FROM_FILE=`cat ${FILENAME} | grep ${VARIABLE} -m 1`
			if [ "$FROM_FILE" != "$FIELD_DATA" ] ; then
				RESTART=1
				echo "$VARIABLE" >> $CHANGED_FILE
			fi
		done
		
		echo "restart_required(MODE=$MODE, WL=$WL) returns $RESTART" > /dev/null
		return $RESTART
	fi
}
create_files ()
{
	for MODE in physical virtual
	do
		FILENAME=/tmp/wifi_"$MODE"_settings.conf
		if [ "physical" = "$MODE" ]; then
			INFO_NEEDED=$PHYSICAL_SETTINGS
		elif [ "virtual" = "$MODE" ]; then
			INFO_NEEDED=$VIRTUAL_SETTINGS
		fi
		for WL in wl0 wl1; do
			for FIELD in $INFO_NEEDED; do
				VARIABLE="$WL"_"$FIELD"
				for TEMP in $NOT_INTERFACE_SPECIFIC; do
					if [ "$FIELD" = "$TEMP" ]; then
						VARIABLE="$FIELD"
						break;
					fi
				done
				INFO=`syscfg get ${VARIABLE}`
				FIELD_DATA="$VARIABLE":" $INFO"
				echo "$FIELD_DATA" >> $FILENAME
			done
		done
	done
}
update_wifi_cache ()
{
	MODE=$1
	WL_LIST=$2
	if [ "physical" != "$MODE" ] && [ "virtual" != "$MODE" ] ; then
		echo "Fatal error, the settings will not be saved" > /dev/console
		return 0
	fi
	FILENAME=/tmp/wifi_"$MODE"_settings.conf
	if [ ! -f $FILENAME ]; then
		create_files
		return
	fi
	if [ "physical" = "$MODE" ]; then
		INFO_NEEDED=$PHYSICAL_SETTINGS
	elif [ "virtual" = "$MODE" ]; then
		INFO_NEEDED=$VIRTUAL_SETTINGS
		WL_LIST=`syscfg get configurable_wl_ifs`
	fi
	for WL in $WL_LIST
	do
		for FIELD in $INFO_NEEDED
		do
			VARIABLE="$WL"_"$FIELD"
			for TEMP in $NOT_INTERFACE_SPECIFIC; do
				if [ "$FIELD" = "$TEMP" ]; then
					VARIABLE="$FIELD"
					break;
				fi
			done
			INFO=`syscfg get ${VARIABLE}`
			FIELD_DATA="$VARIABLE":" $INFO"
			sed -i 's/'"$VARIABLE"':.*/'"$FIELD_DATA"'/g' $FILENAME
		done
	done
}
get_syscfg_network_mode() 
{
	NETWORK_MODE=`syscfg get "$1"_network_mode`	
	SECURITY_MODE=`syscfg get "$1"_security_mode`
	if [ "wep" = "$SECURITY_MODE" ] || [ "wpa-personal" = "$SECURITY_MODE" ] || [ "wpa-enterprise" = "$SECURITY_MODE" ]; then
		if [ "11a 11n" = "$NETWORK_MODE" ] || [ "11a 11n 11ac" = "$NETWORK_MODE" ]; then
			NETWORK_MODE="11a"
		fi
		if [ "11b 11g 11n" = "$NETWORK_MODE" ]; then
			NETWORK_MODE="11b 11g"
		fi
	fi
	echo "$NETWORK_MODE"
}
get_vendor_channel() 
{
	SYSCFG_CHANNEL=`syscfg get "$1"_channel`
	VENDOR_CHANNEL=0  #For auto
	if [ "auto" != "$SYSCFG_CHANNEL" ]; then
		VENDOR_CHANNEL=$SYSCFG_CHANNEL
	fi	
	echo "$VENDOR_CHANNEL"
}
get_vendor_bandwidth() 
{
	WL_SYSCFG=$1
	
	SYSCFG_BANDWIDTH=`syscfg get "$WL_SYSCFG"_radio_band`
	if [ "standard" = "$SYSCFG_BANDWIDTH" ]; then
		VENDOR_BANDWIDTH="20"
	elif [ "wide" = "$SYSCFG_BANDWIDTH" ]; then
		VENDOR_BANDWIDTH="40"
	elif [ "wide80" = "$SYSCFG_BANDWIDTH" ]; then
		VENDOR_BANDWIDTH="80"
	else
		AC_SUPPORTED=`is_11ac_supported $WL_SYSCFG`
		if [ "$AC_SUPPORTED" = "1" ]; then
			VENDOR_BANDWIDTH="80"
		else
			VENDOR_BANDWIDTH="40"
		fi
	fi
	NETWORK_MODE=`get_syscfg_network_mode $WL_SYSCFG`
	if [ "11a" = "$NETWORK_MODE" ] || [ "11b 11g" = "$NETWORK_MODE" ] || [ "11b" = "$NETWORK_MODE" ] || [ "11g" = "$NETWORK_MODE" ]; then
		VENDOR_BANDWIDTH="20"
	elif [ "11ac" != "$NETWORK_MODE" ] && [ "11a 11n 11ac" != "$NETWORK_MODE" ] && [ "80" = "$VENDOR_BANDWIDTH" ]; then
		VENDOR_BANDWIDTH="40"
	fi
	CHANNEL=`syscfg get ${WL_SYSCFG}_channel`
	if [ "165" = "$CHANNEL" ]; then
		VENDOR_BANDWIDTH="20"
	fi
	echo "$VENDOR_BANDWIDTH"
}
get_vendor_trans_rate() 
{
	if [ -n "$1" ] && [ "auto" = "$1" ]; then
		RATE=-1
	elif [ "$1" = "5500000" ]; then
		RATE=5.5
	else
		RATE=`expr $1 / 1000000`
	fi
	if [ $RATE -gt 54 ]; then
		RATE=-1
	fi
	echo "$RATE"
}
get_vendor_n_trans_rate() 
{
	RATE=-1
	if [ -n "$1" ]; then
		if [ "auto" = "$1" ]; then
			RATE=-1
		elif [ $1 -ge 0 ] && [ $1 -le 15 ]; then
			RATE=$1
		else
			ulog wlan status "invalid n_transmission_rate: $1"
		fi
	fi
	echo "$RATE"
}
get_vendor_beacon_interval() 
{
	if [ -n "$1" ] && [ $1 -ge 20 ] && [ $1 -le 1000 ]; then
		BCN_INTERVAL=$1
	else
		BCN_INTERVAL=100
	fi
	echo "$BCN_INTERVAL"
}
get_vendor_rts_threshold() 
{
	RTS=2347
	if [ -n "$1" ] && [ $1 -ge 0 ] && [ $1 -le 2347 ]; then
		RTS=$1
	fi
	echo "$RTS"
}
get_vendor_cts_protection() 
{
	MODE=-1 #default to 'auto'
	if [ -n "$1" ] && [ "$1" = "disabled" ]; then
		MODE=0
	fi
	echo "$MODE"
}
get_vendor_dtim_interval() 
{
	DTIM=1
	if [ -n "$1" ] && [ $1 -ge 1 ] && [ $1 -le 255 ]; then
		DTIM=$1
	fi
	echo "$DTIM"
}
get_vendor_fragthresh() 
{
	FRAG=2346
	if [ -n "$1" ] && [ $1 -ge 256 ] && [ $1 -le 2346 ]; then
		FRAG=$1
	fi  
	echo "$FRAG"
}
get_vendor_txpower()
{
	TX_POWER=100
	if [ -n "$1" ]; then
		if [ "high" = "$1" ]; then
			TX_POWER=100
		elif [ "medium" = "$1" ]; then
			TX_POWER=60
		elif [ "low" = "$1" ]; then
			TX_POWER=30
		else
			DEBUG echo "invalid n_transmission_power: $1"
		fi
	fi
	echo "$TX_POWER"
}
is_nmode()
{
	if [ "11n" = "$1" -o "11b 11g 11n" = "$1" -o "11a 11n" = "$1" -o "11a 11n 11ac" = "$1" ]; then
		N_MODE=1
	else
		N_MODE=0
	fi
	echo "$N_MODE"
}
get_passphrase()
{
	SYSCFG_PASSPHRASE=`syscfg get $1_passphrase`
	echo "$SYSCFG_PASSPHRASE"
}
get_ssid_broadcast() 
{
	WL=$1
	SSID_BROADCAST=`syscfg get ${WL}_ssid_broadcast`
	if [ -z "$SSID_BROADCAST" ]; then
		SSID_BROADCAST=1
	fi
	echo "$SSID_BROADCAST"
}
set_channel_list()
{
	syscfg_set wl_region_table "/etc/regccode"	
	
	for PHY_IF in $PHYSICAL_IF_LIST; do
		WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`
		USER_VAP=`syscfg get ${WL_SYSCFG}_user_vap`
		CHAN_TABLE=`get_driver_chan_info ${USER_VAP}`
		CHAN_LIST=""
		FILENAME=/tmp/chan_info_${WL_SYSCFG}.tbl
		echo "$CHAN_TABLE" >> $FILENAME
		while read CHAN_LINE; do
			CHAN_NUM=`echo ${CHAN_LINE} | awk '{print $2}'`
			if [ -z "${CHAN_LIST}" ]; then
				CHAN_LIST=${CHAN_NUM}
			else
				CHAN_LIST=`echo "${CHAN_LIST},${CHAN_NUM}"`
			fi
		done < ${FILENAME}
		syscfg_set ${WL_SYSCFG}_available_channels ${CHAN_LIST}
	done
	return
}
get_physical_interface_state() 
{
	IFNAME=$1
	STATE=`ifconfig $IFNAME | grep MTU | awk '/UP/ {print $1}'`
	if [ ! -z "$STATE" ] && [ "$STATE" = "UP" ]; then
		STATE="UP"
	else
		STATE="DOWN"
	fi
	echo "$STATE"
}
is_physical_interface_valid() 
{
	VALID="0"
	for PHY_IF in $PHYSICAL_IF_LIST; do
		if [ "$PHY_IF" = "$1" ]; then
			VALID="1"
			break;
		fi
	done
	echo "$VALID"
}
get_wep_keysize()
{
	WL_SYSCFG=$1
	ENCRYPTION_MODE=""
	SEC_MODE=`syscfg get "$WL_SYSCFG"_security_mode`
	if [ "wep" = "$SEC_MODE" ] || [ "wep-auto" = "$SEC_MODE" ] || [ "wep-open" = "$SEC_MODE" ] || [ "wep-shared" = "$SEC_MODE" ]; then
		TX_KEY=`syscfg get "$WL_SYSCFG"_tx_key`
		INDEX_KEY=`expr $TX_KEY - 1`
		CURRENT_KEY=`syscfg get "$WL_SYSCFG"_key_"$INDEX_KEY"`
		CURRENT_KL=`echo $CURRENT_KEY | wc -c`
		if [ 11 = `expr $CURRENT_KL` ] || [ 6 = `expr $CURRENT_KL` ]; then
			ENCRYPTION_MODE="64-bits"
		elif [ 27 = `expr $CURRENT_KL` ] || [ 14 = `expr $CURRENT_KL` ]; then
			ENCRYPTION_MODE="128-bits"
		fi
	fi
	echo "$ENCRYPTION_MODE"	
}
is_11ac_supported() 
{
	WL_SYSCFG=$1
	RET_CODE="0"
	CHIP_TYPE=`syscfg get "$WL_SYSCFG"_chip`
	if [ "$CHIP_TYPE" = "11ac" ]; then
		RET_CODE="1"
	elif [ "$CHIP_TYPE" = "4360" ]; then
		RET_CODE="1"
	fi
	echo "$RET_CODE"
}
mrvl_mac_filter_enable () {
	IF_NAME=$1
	CUR_SET=`syscfg get wl_access_restriction`
	MAC_ENTRIES=`syscfg get wl_mac_filter`
	if [ "$CUR_SET" = "allow" ] || [ "$CUR_SET" = "deny" ]; then
		if [ "$CUR_SET" = "allow" ]; then
			iwpriv $IF_NAME filter 1
		else
			iwpriv $IF_NAME filter 2
		fi
		for mac in $MAC_ENTRIES; do
			macstring=`echo $mac | awk -F":" '{print $1$2$3$4$5$6}'`
			iwpriv $IF_NAME filtermac "add $macstring"
		done
	else
		iwpriv $IF_NAME filter 0
		iwpriv $IF_NAME filtermac "deleteall"
	fi
	return 0
}
mrvl_mac_filter_disabled() {
	IF_NAME=$1
	iwpriv $IF_NAME filter 0
	iwpriv $IF_NAME filtermac "deleteall"
}
add_guest_vlan_to_backhaul()
{
	VID=$SYSCFG_guest_vlan_id
	for intf in $SYSCFG_backhaul_ifname_list; do
		vconfig set_name_type DEV_PLUS_VID_NO_PAD
		vconfig add $intf $VID
		add_interface_to_bridge $intf.$VID $SYSCFG_guest_lan_ifname
		ebtables -t broute -I BROUTING -i $intf -p 802.1Q --vlan-id $VID -j DROP
	done
}
delete_guest_vlan_from_backhaul()
{
	VID=$SYSCFG_guest_vlan_id
	for intf in $SYSCFG_backhaul_ifname_list; do
		vconfig rem $intf.$VID
		ebtables -t broute -D BROUTING -i $intf -p 802.1Q --vlan-id $VID -j DROP
	done
}
