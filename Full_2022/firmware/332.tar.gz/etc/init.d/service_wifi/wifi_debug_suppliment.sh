PHYSICAL_IF_LIST=`syscfg get lan_wl_physical_ifnames`
CCODE="`nvram show | grep ccode`"
REGREV="`nvram show | grep regrev`"
echo "========================== WiFi General Information =========================="
echo "Driver version	        : `wl ver`"
echo "NVRAM Info:"
echo "	"$CCODE
echo "	"$REGREV
echo "-----MAC address-----"
for PHY_IF in $PHYSICAL_IF_LIST; do
	WL_SYSCFG=`syscfg get ${PHY_IF}_syscfg_index`
	if [ "${WL_SYSCFG}" = "wl0" ]; then
		echo "${PHY_IF} Mac Address (2.4G)       : `syscfg get ${WL_SYSCFG}_mac_addr`"
		echo "Guest Mac Address (2.4G)      : `syscfg get ${WL_SYSCFG}.1_mac_addr`"
		echo "SimpleTap Mac Address (2.4G)  : `syscfg get ${WL_SYSCFG}.2_mac_addr`"
	else
		echo "${PHY_IF} Mac Address (5G)         : `syscfg get ${WL_SYSCFG}_mac_addr`"
	fi
done
for PHY_IF in $PHYSICAL_IF_LIST; do
	WL_SYSCFG=`syscfg get ${PHY_IF}_syscfg_index`
	if [ "${WL_SYSCFG}" = "wl0" ]; then
		IF_FRIENDLY_NAME="2.4GHz"
	else
		IF_FRIENDLY_NAME="5GHz"
	fi
	
	echo ""
	echo "-----${IF_FRIENDLY_NAME} Wireless-----"
	echo "Physical IF                  : `wl -i ${PHY_IF} isup` (0=down/1=up) "
	echo "Virtual IF                   : `wl -i ${PHY_IF} bss -C 0`"
	echo "Channel                      : `wl -i ${PHY_IF} chanspec|awk '{print $1}'`"
	echo "Country                      : `wl -i ${PHY_IF} country`"
	echo "MCS                          : `wl -i ${PHY_IF} nrate`"
	echo "Rate                         : `wl -i ${PHY_IF} rate`"
	echo ""
	echo "wl -i ${PHY_IF} status:"
	echo "`wl -i ${PHY_IF} status`"
	echo ""
done
WLLIST="/tmp/wliflist"
ifconfig | grep wl | awk '{print $1}' > "$WLLIST"
while read line
do
	wl -i $line status
done < "$WLLIST"
rm -rf "$WLLIST"
