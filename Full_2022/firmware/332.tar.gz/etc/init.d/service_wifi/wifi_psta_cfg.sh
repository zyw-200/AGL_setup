#!/bin/sh
source /etc/init.d/service_wifi/wifi_sta_utils.sh
RADIO=""
SSID=""
PASSPHRASE=""
INPUT_CHECK=0
STATUS=""
IF=""
SECURITY_TYPE=""
print_help()
{
	echo "Usage: command -r [5G | 2G] -s <SSID> -p <Passphrase>"
	echo "Return failed if SSID not exist, otherwise the security type"
	exit
}
if [ $# -lt 4 ]; then
	print_help
fi
while [ $# -gt 0 ]; do
	case "$1" in
		"-r")
			echo "Radio is" $2
			RADIO=$2
			INPUT_CHECK=1
			;;
		"-s")
			echo "SSID is" $2
			SSID=$2
			INPUT_CHECK=1
			;;
		"-p")
			echo "Passphrase is" $2
			PASSPHRASE=$2
			INPUT_CHECK=1
			;;
		*)
			INPUT_CHECK=0
			break
			;;
	esac
	shift	
	shift	
done
if [ "1" != "$INPUT_CHECK" ] || [ -z "$RADIO" ] || [ -z "$SSID" ]; then
	STATUS="failed"
	echo $STATUS
	print_help
fi
SECURITY_TYPE=`/etc/init.d/service_wifi/wifi_ap_security_detect.sh -r $RADIO -s $SSID`
if [ "wpa-personal" = "$SECURITY_TYPE" ] || [ "wpa2-personal" = "$SECURITY_TYPE" ]; then
	if [ -z "$PASSPHRASE" ]; then
		STATUS="failed"
		echo $STATUS
		print_help
	fi
fi
IF=`radio_to_brcm_physical_ifname $RADIO`
if [ -z "$IF" ]; then
	STATUS="failed"
	echo $STATUS
	print_help
fi
if [ "eth1" != "$IF" ] && [ "eth2" != "$IF" ]; then
	STATUS="failed"
	echo $STATUS
	print_help
fi
if [ "1" = "`syscfg get wifi_sta_enabled`" ] ; then
	sysevent set PSTA_REBOOT 0
else
	sysevent set PSTA_REBOOT 1
fi
syscfg set bridge_mode 1
syscfg set wifi_sta_enabled 1
syscfg set wifi_sta_radio `echo $RADIO | tr [:upper:] [:lower:]`
syscfg set wifi_sta_ssid $SSID
syscfg unset wifi_sta_user_vap
sysevent set physical-one-time-setting FALSE
sysevent set system_state-heartbeat
if [ "wpa-personal" = "$SECURITY_TYPE" ] || [ "wpa2-personal" = "$SECURITY_TYPE" ]; then
	syscfg set wifi_sta_security_mode $SECURITY_TYPE
	syscfg set wifi_sta_passphrase $PASSPHRASE
else
	syscfg set wifi_sta_security_mode disabled
fi
syscfg commit
if [ "1" = "`sysevent get PSTA_REBOOT`" ] ; then
	reboot
else
	sysevent set bridge-restart
fi
echo $STATUS
