get_deviceid_from_ifname()
{
	IF=$1
	CHIPNUM=""
	CHIPNUM=`wl -i $IF revinfo | grep deviceid | sed 's/deviceid 0x//g'`
	echo $CHIPNUM
}
get_nmode_from_ifname()
{
	IF=$1
	NMODE=""
	CHIPNUM=`get_deviceid_from_ifname $IF`
	case "`echo $CHIPNUM | tr [:upper:] [:lower:]`" in
		"43a2" | "4332")
			NMODE=3
			;;
		"43a9" | "43b3")
			NMODE=2	
			;;
	esac
	echo $NMODE
}
radio_to_brcm_physical_ifname()
{
	RADIO=$1
	IFNAME=""
	INDEX=""
	case "`echo $RADIO | tr [:upper:] [:lower:]`" in
		"2g")
		INDEX=0
		;;
		"5g")
		INDEX=1
		;;
	esac
	
	IFNAME=`syscfg get wl"$INDEX"_physical_ifname`
	echo "$IFNAME"
}
radio_to_brcm_wl_index()
{
	RADIO=$1
	INDEX=""
	IF=`radio_to_brcm_physical_ifname $RADIO`
	TOKEN=`nvram get wl0_ifname | awk -F"=" '{print $1}'`
	if [ "`echo $IF | tr [:upper:] [:lower:]`" = "`echo $TOKEN | tr [:upper:] [:lower:]`" ]; then
		INDEX=0
	else
		INDEX=1
	fi
	echo $INDEX
}
akm_type_detect()
{
	INTERFACE=$1
	SSID=$2
	AP_SCAN_FILE=/tmp/ap_scan.txt
	RSN=""
	WPA=""
	RETURN=""
	
	wl -i $INTERFACE up
	wl -i $INTERFACE scan $SSID
	sleep 2
	wl -i $INTERFACE scanresults > $AP_SCAN_FILE
	RSN=`cat $AP_SCAN_FILE | grep "RSN:"`
	WPA=`cat $AP_SCAN_FILE | grep "WPA:"`
	FILESIZE=`stat -c %s $AP_SCAN_FILE`
	if [ $FILESIZE -eq 0 ]; then
		echo "failed"
		return
	fi
	if [ -z "$RSN" ] && [ -z "$WPA" ]; then
		RETURN="open"
	else
		if [ -n "$RSN" ]; then
			RETURN="wpa2-personal"
		else
			RETURN="wpa-personal"
		fi
	fi
	echo "$RETURN"
}
wifi_sta_join()
{
	INTERFACE=$1
	SYSCFG_SECURITY=`syscfg get wifi_sta_security_mode`
	SELECTED_SSID=`syscfg get wifi_sta_ssid`
	SELECTED_AMODE=""
	SELECTED_ENCRYPTION=""
	SUPPLICANT=""
	case "$SYSCFG_SECURITY" in
		"wpa2-personal")
			SELECTED_SECURITY=0x80
			SELECTED_AMODE="wpa2psk"
			SELECTED_ENCRYPTION=4
			SUPPLICANT=1
			;;
		"wpa-personal")
			SELECTED_SECURITY=0x4
			SELECTED_AMODE="wpapsk"
			SELECTED_ENCRYPTION=6
			SUPPLICANT=1
			;;
		*)
			SELECTED_SECURITY=0x0
			SELECTED_AMODE="open"
			SELECTED_ENCRYPTION=0x0
			SUPPLICANT=0
			;;
	esac
	SELECTED_PASSPHRASE=`syscfg get wifi_sta_passphrase`
	wl -i $INTERFACE up
	wl -i $INTERFACE wpa_auth "$SELECTED_SECURITY"
	wl -i $INTERFACE wsec "$SELECTED_ENCRYPTION"
	if [ "open" != "$SELECTED_AMODE" ]; then
		wl -i $INTERFACE set_pmk "$SELECTED_PASSPHRASE"
		sleep 2
		wl -i $INTERFACE sup_wpa "$SUPPLICANT"
	fi
	wl -i $INTERFACE join $SELECTED_SSID amode $SELECTED_AMODE
	DEBUG echo "Interface $INTERFACE connected" > /dev/console
}
