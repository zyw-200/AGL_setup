#!/bin/sh
source /etc/init.d/service_wifi/wifi_utils.sh
source /etc/init.d/syscfg_api.sh
source /etc/init.d/ulog_functions.sh
source /etc/init.d/event_handler_functions.sh
start_simpletap()
{
	PHY_IF=`syscfg get wl0_physical_ifname`
	TC="tc_vap"
	TC_VAP=`syscfg get ${TC}_user_vap`
	USER_VAP=`syscfg get wl0_user_vap`
	if [ "started" != "`sysevent get ${WIFI_USER}-status`" ] ; then
		ulog wlan status "${SERVICE_NAME}, user vap is not started, do not start wifi guest"
		return 1
	fi
	if [ "down" = "`syscfg get wl0_state`" ] ; then	
		ulog wlan status "${SERVICE_NAME}, user vap state is down, do not start tap & connect"
		return 1
	fi
	UVAP_DISABLED=`syscfg get wl0_uvap_disabled`
	if [ -n "$UVAP_DISABLED" ] && [ "1" = "$UVAP_DISABLED" ] ; then
		ulog wlan status "${SERVICE_NAME}, user vap is disabled, do not start tap & connect"
		return 1
	fi
	if [ -z $TC_VAP ]; then
		ulog wlan status "${SERVICE_NAME}, tc_vap name is not defined, do not start tap & connect"
		return 1
	fi
	TC_VAP_SSID=`syscfg get ${TC}_ssid`
	if [ -z $TC_VAP_SSID ]; then 
		ulog wlan status "${SERVICE_NAME}, tc_vap ssid is not defined, do not start tap & connect"
		return 1
	fi
	TC_ENABLED=`syscfg get ${TC}_enabled`
	if [ "$TC_ENABLED" = "1" ]; then
		is_mbss_enabled ${PHY_IF}
		if [ "$?" = "0" ]; then
			echo "${SERVICE_NAME}, enabling MBSS requires a wifi-restart"
			sysevent set wifi-restart
			return 1
		else
			bring_vir_if_up ${PHY_IF} 2
		fi
	else
		return 1
	fi
	configure_simpletap $TC_VAP
	BRIDGE=`syscfg get ${TC}_lan_ifname`
	add_interface_to_bridge $TC_VAP $BRIDGE
	bring_phy_if_up $TC_VAP
	sysevent set ${TC}_state "up"
	echo "${SERVICE_NAME}, Tap Connect is up"
	
	ulog wlan status "${SERVICE_NAME}, Tap Connect is up"
	return 0
}
stop_simpletap()
{
	TC="tc_vap"
	PHY_IF=`syscfg get wl0_physical_ifname`
	WL_SYSCFG=`get_syscfg_interface_name ${PHY_IF}`
	TC_VAP=`syscfg get ${TC}_user_vap`
	USER_VAP=`syscfg get wl0_user_vap`
	if [ -z $TC_VAP ]; then
		ulog wlan status "${SERVICE_NAME}, ${TC} name is not defined, do not start tap & connect"
		return 1
	fi
	PID=`ps | grep -e eapd -e nas | awk "/$TC_VAP/"' {print $1}'`
	if [ ! -z "$PID" ] ; then
		kill $PID > /dev/null 2>&1
		DEBUG ulog wlan status "Stopped 1x Authentication agent on $TC_VAP"
	fi
	sysevent set ${WIFI_SIMPLETAP}-status stopping
	bring_vir_if_down $PHY_IF 2
	BRIDGE=`syscfg get ${TC}_lan_ifname`
	delete_interface_from_bridge $TC_VAP $BRIDGE
	is_mbss_needed ${PHY_IF}
	if [ "$?" = "0" ]; then 
		is_mbss_enabled ${PHY_IF}
		if [ "$?" = "1" ]; then
			echo "${SERVICE_NAME}, disabling MBSS, wifi restart is required"
			sysevent set wifi-restart
		fi
	fi
	echo "${SERVICE_NAME}, Tap Connect is down"
	sysevent set ${TC}_state "down"
	ulog wlan status "${SERVICE_NAME}, Tap Connect is down"
	return 0
}
wifi_simpletap_start ()
{
	wait_till_end_state ${WIFI_SIMPLETAP}
	TAP_CONNECT_ENABLED=`syscfg get tc_vap_enabled`
	if [ "$TAP_CONNECT_ENABLED" = "0" ]; then
		ulog wlan status "${SERVICE_NAME}, simpletap vap is disabled, do not start wifi simpletap"
		return 1
	fi
	if [ "2g" = "`syscfg get wifi_sta_radio`" ] && [ "1" = "`syscfg get wifi_sta_enabled`" ]; then
		ulog wlan status "${SERVICE_NAME}, PSTA mode, do not start wifi simpletap"
		return 1
	fi
	STATUS=`sysevent get ${WIFI_SIMPLETAP}-status`
	if [ "started" = "$STATUS" ] || [ "starting" = "$STATUS" ]; then
		ulog wlan status "${SERVICE_NAME}, ${WIFI_SIMPLETAP} is starting/started, ignore the request"
		return 1
	fi
	ulog wlan status "${SERVICE_NAME}, wifi_simpletap_start()"
	sysevent set ${WIFI_SIMPLETAP}-status starting
	start_simpletap
	if [ "$?" = "0" ]; then
		sysevent set ${WIFI_SIMPLETAP}-status started
		return 0
	else	#return 1 means MBSS needs to be created, simpletap is not started yet
		sysevent set ${WIFI_SIMPLETAP}-status stopped
		return 1
	fi
}
wifi_simpletap_stop ()
{
	wait_till_end_state ${WIFI_SIMPLETAP}
	STATUS=`sysevent get ${WIFI_SIMPLETAP}-status`
	if [ "stopped" = "$STATUS" ] || [ "stopping" = "$STATUS" ] || [ -z "$STATUS" ]; then
		ulog wlan status "${SERVICE_NAME}, ${WIFI_SIMPLETAP} is already stopping/stopped, ignore the request"
		return 0
	fi
	ulog wlan status "${SERVICE_NAME}, wifi_simpletap_stop()"
	sysevent set ${WIFI_SIMPLETAP}-status stopping
	stop_simpletap
	sysevent set ${WIFI_SIMPLETAP}-status stopped
	return 0
}
wifi_simpletap_restart()
{
	ulog wlan status "${SERVICE_NAME}, wifi_simpletap_restart()"
	wifi_simpletap_stop
	wifi_simpletap_start
	return 0
}
