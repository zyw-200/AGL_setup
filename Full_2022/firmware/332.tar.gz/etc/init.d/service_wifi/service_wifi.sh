#!/bin/sh
source /etc/init.d/ulog_functions.sh
source /etc/init.d/event_handler_functions.sh
source /etc/init.d/service_wifi/wifi_utils.sh
source /etc/init.d/nvram_api.sh
source /etc/init.d/service_wifi/wifi_physical_action.sh
source /etc/init.d/service_wifi/wifi_virtual_action.sh
source /etc/init.d/service_wifi/wifi_guest.sh
source /etc/init.d/service_wifi/wifi_wl1_guest.sh
source /etc/init.d/service_wifi/wifi_simpletap.sh
source /etc/init.d/service_wifi/wifi_platform_specific_setting.sh
SERVICE_NAME="wifi"
WIFI_DEBUG_SETTING=`syscfg get ${SERVICE_NAME}_debug`
DEBUG() 
{
    [ "$WIFI_DEBUG_SETTING" = "1" ] && $@
}
DEBUG set -x
echo "${SERVICE_NAME}, sysevent received: $1"
service_init()
{
	ulog wlan status "${SERVICE_NAME}, service_init()"
	SYSCFG_FAILED='false'
	FOO=`utctx_cmd get device::deviceType wl_wmm_support lan_ifname lan_wl_physical_ifnames wl0_ssid wl1_ssid wl0_state wl0_guest_vap wl0_guest_enabled guest_enabled guest_lan_ifname guest_wifi_phy_ifname guest_ssid_suffix guest_ssid guest_ssid_broadcast guest_lan_ipaddr guest_lan_netmask guest_vlan_id backhaul_ifname_list extender_radio_mode wl1_guest_vap wl1_guest_enabled wl1_guest_ssid wl1_guest_ssid_broadcast`
	eval $FOO
	if [ $SYSCFG_FAILED = 'true' ] ; then
		ulog wlan status "${SERVICE_NAME}, $PID utctx failed to get some configuration data required by service-forwarding"
		DEBUG echo "[utopia] THE SYSTEM IS NOT SANE" > /dev/console
		sysevent set ${SERVICE_NAME}-status error
		sysevent set ${SERVICE_NAME}-errinfo "Unable to get crucial information from syscfg"
		return 0
	fi
}
service_start()
{
	wait_till_end_state ${SERVICE_NAME}
	ulog wlan status "${SERVICE_NAME}, service_start()"
	STATUS=`sysevent get ${SERVICE_NAME}-status`
	if [ "started" = "$STATUS" ] || [ "starting" = "$STATUS" ]; then
		ulog wlan status "${SERVICE_NAME} is starting/started, ignore the request"
		return 0
	fi
	if [ "0" = "`syscfg get bridge_mode`" ] && [ "started" != "`sysevent get lan-status`" ] ; then
		ulog wlan status "${SERVICE_NAME}, LAN is not started,ignore the request"
		return 0
	fi
	if [ "0" != "`syscfg get bridge_mode`" ] && [ -f /etc/init.d/service_wifi/wifi_sta_setup.sh ] ; then
		/etc/init.d/service_wifi/wifi_sta_setup.sh
	fi
	source /etc/init.d/service_wifi/wifi_utils.sh
	echo "${SERVICE_NAME}, service_start()"
	sysevent set WIFI_START_NEED "1"
	wifi_config_changed_handler
}
service_stop()
{
	wait_till_end_state ${SERVICE_NAME}
	ulog wlan status "${SERVICE_NAME}, service_stop()"
	STATUS=`sysevent get ${SERVICE_NAME}-status`
	if [ "stopped" = "$STATUS" ] || [ "stopping" = "$STATUS" ] || [ -z "$STATUS" ]; then
		ulog wlan status "${SERVICE_NAME} is stopping/stopped, ignore the request"
		return 0
	fi
	
	echo "${SERVICE_NAME}, service_stop()"
	sysevent set ${SERVICE_NAME}-status stopping
	sysevent set wifi_infra_phy-status stopping # backwards compatible
	wifi_virtual_action_stop
	for j in $PHYSICAL_IF_LIST; do
		wifi_physical_action_stop $j
	done
	
	sysevent set ${SERVICE_NAME}-status stopped
	sysevent set wifi_infra_phy-status stopped # backwards compatible
}
service_restart()
{
	ulog wlan status "${SERVICE_NAME}, service_restart()"
	service_stop
	service_start
}
wifi_config_changed_handler()
{
	wait_till_end_state ${SERVICE_NAME}
	ulog wlan status "${SERVICE_NAME}, wifi_config_changed_handler()"
	if [ "0" = "`syscfg get bridge_mode`" ] && [ "started" != "`sysevent get lan-status`" ] ; then
		ulog wlan status "${SERVICE_NAME}, LAN is not started,ignore the request"
		return 0
	fi
	sysevent set ${SERVICE_NAME}-status starting
	sysevent set wifi_infra_phy-status starting # backwards compatible
	CHANGED_FILE=/tmp/wifi_changed_settings.conf
	rm -f $CHANGED_FILE
	PHY_RESTART_LIST=""
	if [ "1" = "`sysevent get WIFI_START_NEED`" ]; then
		PHY_RESTART_LIST=$PHYSICAL_IF_LIST
		sysevent set WIFI_START_NEED "0"
	else
		for j in $PHYSICAL_IF_LIST; do
			IF_NAME=`get_syscfg_interface_name $j`
			restart_required "physical" ${IF_NAME}
			if [ "1" = "$?" ] ; then
				ulog wlan status "${SERVICE_NAME}, physical config change detected: $j"
				PHY_RESTART_LIST=`echo "$PHY_RESTART_LIST $j"`
			fi
		done
	fi
	if [ ! -z "$PHY_RESTART_LIST" ] ; then
		wifi_virtual_action_stop
		for j in $PHY_RESTART_LIST; do
			wifi_physical_action_stop $j
		done
		ulog wlan status "${SERVICE_NAME}, starting physical action"
		wifi_physical_onetime_setting
		for j in $PHY_RESTART_LIST; do
			wifi_physical_pre_setting $j
			wifi_physical_action_start $j
			wifi_physical_post_setting $j
		done
		wifi_virtual_onetime_setting
		wifi_virtual_action_start
	else
		VIR_RESTART="0"
		for j in $PHYSICAL_IF_LIST; do
			IF_NAME=`get_syscfg_interface_name $j`
			restart_required "virtual" ${IF_NAME}
			if [ "1" = "$?" ] ; then
				VIR_RESTART="1"
			fi
		done
		
		if [ "1" = "$VIR_RESTART" ] ; then
			if [ -f $CHANGED_FILE ] ; then
				if [ "`wc -l $CHANGED_FILE | awk '{ print $1 }'`" = "2" ] ; then
					if [ "`grep "guest_enabled" $CHANGED_FILE | wc -l`" = "2" ] ; then
						echo "wifi, master guest_enabled setting changed"
						wifi_wl0_guest_restart
						wifi_wl1_guest_restart
						GUEST_RESTART=1
					else
						if [ "`grep "wl0_guest_enabled" $CHANGED_FILE | wc -l`" = "2" ] ; then
							echo "wifi, wl0_guest_enabled setting changed"
							wifi_wl0_guest_restart
							WL0_GUEST_RESTART=1
						fi
						if [ "`grep "wl1_guest_enabled" $CHANGED_FILE | wc -l`" = "2" ] ; then
							echo "wifi, wl1_guest_enabled setting changed"
							wifi_wl1_guest_restart
							WL1_GUEST_RESTART=1
						fi
					fi
					if [ "$GUEST_RESTART" = "1" ] || [ "$WL0_GUEST_RESTART" = "1" ] || [ "$WL1_GUEST_RESTART" = "1" ] ; then
						update_wifi_cache "virtual"
						set_driver_mac_filter
					
						sysevent set ${SERVICE_NAME}-status started
						sysevent set wifi_infra_phy-status started # backwards compatible
						return
					fi
					if [ "`grep "tc_vap_enabled" $CHANGED_FILE | wc -l`" = "2" ] ; then
						echo "wifi, only tc_vap_enabled setting changed"
						echo "wifi, wifi_tc_vap_restart"
						wifi_simpletap_stop
						stop_eapd_wps_nas 
						start_eapd_wps_nas
						wifi_simpletap_start
						set_driver_mac_filter
						update_wifi_cache "virtual"
					
						sysevent set ${SERVICE_NAME}-status started
						sysevent set wifi_infra_phy-status started # backwards compatible
						return
					fi
				fi
			fi
			ulog wlan status "${SERVICE_NAME}, virtual config change detected"
			wifi_virtual_onetime_setting
			wifi_virtual_action_restart
		fi
	fi
	
	sysevent set ${SERVICE_NAME}-status started
	sysevent set wifi_infra_phy-status started # backwards compatible
}
ER_config_changed_handler()
{
	ulog wlan status "${SERVICE_NAME}, ER_config_changed_handler()"
	ER_CONFIG_CHANGED=`sysevent get wifi_nvram_setting`
	if [ "changed" = "$ER_CONFIG_CHANGED" ]; then
		save_wps_settings_to_syscfg
		set_wl0_guest_ssid
		set_wl1_guest_ssid
		wifi_config_changed_handler
		sysevent set wifi_nvram_setting ""
	fi
}
ulog wlan status "${SERVICE_NAME}, sysevent received: $1"
service_init 
case "$1" in
	wifi-start)
		service_start
		;;
	wifi-stop)
		service_stop
		;;
	wifi-restart)
		service_restart
		;;
	wifi_config_changed)
		wifi_config_changed_handler
		;;
	lan-started)
		service_start
		;;
	mac_filter_changed)
		wifi_config_changed_handler
		;;
	wifi_nvram_setting)
		ER_config_changed_handler
		;;
	wifi_infra_phy-start)
		service_start
		;;
	wifi_infra_phy-stop)
		service_stop
		;;
	wifi_infra_phy-restart)
		wifi_config_changed_handler
		;;	
	wifi_user-start)
		service_start
		;;
	wifi_user-stop)
		service_stop
		;;
	wifi_user-restart)
		wifi_config_changed_handler
		;;
	guest_lan-restart)
		wifi_config_changed_handler
		;;	
	*)
	echo "Usage: service-${SERVICE_NAME} [ ${SERVICE_NAME}-start | ${SERVICE_NAME}-stop | ${SERVICE_NAME}-restart]" > /dev/console
		exit 3
		;;
esac
nvram_commit
syscfg_commit
