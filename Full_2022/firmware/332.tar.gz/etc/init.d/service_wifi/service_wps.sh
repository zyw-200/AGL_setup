#!/bin/sh
source /etc/init.d/ulog_functions.sh
brcm_start_wps () {
	PHY=$1
   	VAP=$2
	RET=1
	LOOP=1
	while [ $LOOP = 1 ]
	do
		LOOP=0
		echo "WSP start" > /dev/console
		RET=0
	done
	return $RET
}
brcm_stop_wps () {
   	VAP=$1
	RET=1
	LOOP=1
	while [ $LOOP = 1 ]
	do
		LOOP=0
		echo "WSP stop" > /dev/console
		RET=0
	done
	return $RET
}
