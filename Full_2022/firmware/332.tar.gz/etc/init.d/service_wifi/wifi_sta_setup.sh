#!/bin/sh
source /etc/init.d/service_wifi/wifi_sta_utils.sh
source /etc/init.d/service_wifi/wifi_platform_specific_setting.sh
SERVICE_NAME="wifi_sta_setup"
WIFI_DEBUG_SETTING=`syscfg get ${SERVICE_NAME}_debug`
DEBUG() 
{
    [ "$WIFI_DEBUG_SETTING" = "1" ] && $@
}
DEBUG set -x
FALSE=0
TRUE=1
SELECTED_STA_IF=`syscfg get wifi_sta_user_vap`
HOSTNAME=`hostname`
BRIDGE_NAME=`syscfg get lan_ifname`
SELECTED_SSID=`syscfg get wifi_sta_ssid`
SELECTED_RADIO=`syscfg get wifi_sta_radio`
wifi_sta_prepare()
{
	STA_NAME="$SELECTED_STA_IF"
	SSID=`syscfg get wifi_sta_ssid`
	if [ "eth1" = "$STA_NAME" ] || [ "eth2" = "$STA_NAME" ]; then
		return
	fi
	STATUS=$FALSE
	STA_IF=""
	STA_IF=`radio_to_brcm_physical_ifname $SELECTED_RADIO`
	STA_NVRAM_IF=wl`radio_to_brcm_wl_index $SELECTED_RADIO`
	ORG_IFS="eth1 eth2"
	NEW_IFS=`echo $ORG_IFS | sed 's/'"${STA_IF}"'//g'`
	syscfg set lan_wl_physical_ifnames "$NEW_IFS"
	syscfg set wifi_sta_user_vap $STA_IF
	syscfg set wifi_sta_nvram_ifname $STA_NVRAM_IF
	WSEC=`get_wsec wifi_sta`
	WPA_AUTH=`get_wpa_auth wifi_sta`
	syscfg set wifi_sta_wpa_auth $WPA_AUTH
 	if [ -n "$WSEC" ]; then
		syscfg set wifi_sta_wsec $WSEC
	fi
	syscfg set wifi_sta_key_renewal 3600
	syscfg commit
	SELECTED_STA_IF="$STA_IF"
	return $TRUE
}
wifi_sta_init()
{
	brctl addif $BRIDGE_NAME $SELECTED_STA_IF
	BF_ENABLED=false
	BW=2g
	CAP=3
	BAND=b
	if [ "5g" = "`echo $SELECTED_RADIO | tr [:upper:] [:lower:]`" ]; then
		if [ "1" = "`syscfg get wl1_txbf_enabled`" ]; then
			BF_ENABLED=true
		fi
		BW=5g
		CAP=7
		BAND=a
	fi
	ifconfig $SELECTED_STA_IF up
	wl -i $SELECTED_STA_IF down
	wl -i $SELECTED_STA_IF band $BAND
	wl -i $SELECTED_STA_IF ap 0
	wl -i $SELECTED_STA_IF apsta 0
	wl -i $SELECTED_STA_IF infra 1
	wl -i $SELECTED_STA_IF psta 1
	wl -i $SELECTED_STA_IF amsdu 0
	wl -i $SELECTED_STA_IF rx_amsdu_in_ampdu 0
	if [ "a" = "$BAND" ]; then
		wl -i $SELECTED_STA_IF vhtmode 1
	fi
	if [ "2g" = "`syscfg get wifi_sta_radio`" ] ; then
		if [ "1" = "`syscfg get wl0_256qam_enabled`" ] ; then
			wl -i $SELECTED_STA_IF vhtmode 1
			wl -i $SELECTED_STA_IF frameburst 1
			wl -i $SELECTED_STA_IF ampdu_mpdu 64
			wl -i $SELECTED_STA_IF ack_ratio 4
			wl -i $SELECTED_STA_IF vht_features 1
		else
			wl -i $SELECTED_STA_IF ampdu_mpdu -1
			wl -i $SELECTED_STA_IF ack_ratio 2
			wl -i $SELECTED_STA_IF vht_features 0
		fi
	fi
	wl -i $SELECTED_STA_IF bw_cap $BW $CAP
	wl -i $SELECTED_STA_IF nmode `get_nmode_from_ifname $SELECTED_STA_IF`
	wl -i $SELECTED_STA_IF sta_retry_time 5
	wl -i $SELECTED_STA_IF assoc_retry_max 3
	wl -i $SELECTED_STA_IF mcast_regen_bss_enable 1
	if [ "true" = "$BF_ENABLED" ]; then
		wl -i $SELECTED_STA_IF txbf_bfr_cap 1
		wl -i $SELECTED_STA_IF txbf_bfe_cap 1
	fi
	wl -i $SELECTED_STA_IF up
}
wifi_sta_connect()
{
	wifi_sta_join $SELECTED_STA_IF
	sysevent set wifi_sta_up 1
}
wifi_sta_post_connect()
{
	STA_NVRAM_IF=`syscfg get wifi_sta_nvram_ifname`
	VIRTUAL_INT="$STA_NVRAM_IF"."$1"
	COUNTER=20
	TOKEN=""
	while [ $COUNTER -gt 0 ]
	do
		TOKEN=`ifconfig -a | grep "$VIRTUAL_INT"`
		if [ -n "$TOKEN" ]; then
			break
		fi
		sleep 2
		COUNTER=`expr $COUNTER - 2`
	done
	if [ -z "$TOKEN" ]; then
		return
	fi
	wifi_sta_join "$VIRTUAL_INT"
	COUNTER=10
	while [ $COUNTER -gt 0 ]
	do
		TOKEN=`wl -i "$VIRTUAL_INT" status | grep "$SELECTED_SSID"`
		if [ -n "$TOKEN" ]; then
			break
		fi
		sleep 2
		COUNTER=`expr $COUNTER - 2`
	done
}
BRIDGE_MODE=`syscfg get bridge_mode`
if [ "1" = "$BRIDGE_MODE" ] || [ "2" = "$BRIDGE_MODE" ]; then
		WIFI_STA_ENABLED=`syscfg get wifi_sta_enabled`
		if [ "1" = "$WIFI_STA_ENABLED" ]; then
			STA_UP=`sysevent get wifi_sta_up`
			if [ "1" != "$STA_UP" ]; then
				wifi_sta_prepare
				wifi_sta_init
				wifi_sta_connect
				sysevent set dhcp_client-renew
			fi
		fi
fi
exit
