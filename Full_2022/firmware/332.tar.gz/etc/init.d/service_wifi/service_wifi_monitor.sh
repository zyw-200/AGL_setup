#!/bin/sh
source /etc/init.d/event_handler_functions.sh
source /etc/init.d/service_wifi/wifi_utils.sh
for ifs in $PHYSICAL_IF_LIST
do
    VIR_IFNAME=`get_syscfg_interface_name $ifs`	
    wl_state=`syscfg get ${VIR_IFNAME}_state`
    if [ "down" = "$wl_state" ]; then
	continue
    fi
    WIFI_STATUS=`sysevent get wifi-status`
    if [ "started" != "$WIFI_STATUS" ] && [ "stopped" != "$WIFI_STATUS" ] ; then
        continue
    fi
    retry=0
    while [ $retry -lt 3 ]
    do
	isup1=`wl -i $ifs isup`
	if [ $isup1 = 1 ]; then
	    break
	fi
	
	logger -p local7.error -t WIFI "$ifs is down"
	/etc/init.d/service_wifi/service_wifi.sh wifi-restart
	retry=`expr $retry + 1`	  
	    
	isup2=`wl -i $ifs isup`
	if [ $isup2 = 0 ]; then
	    logger -p local7.error -t WIFI "$ifs is down after wifi service restarted, retry=$retry"
	else
	    if [ $isup1 = 0 ]; then
		logger -p local7.notice -t WIFI "$ifs is up after retry=$retry"
	    fi
	    break
	fi
    done
done
