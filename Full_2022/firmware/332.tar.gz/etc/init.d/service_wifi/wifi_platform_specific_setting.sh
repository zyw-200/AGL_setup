#!/bin/sh
source /etc/init.d/service_wifi/wifi_utils.sh
source /etc/init.d/ulog_functions.sh
source /etc/init.d/event_handler_functions.sh
source /etc/init.d/nvram_api.sh
source /etc/init.d/syscfg_api.sh
WIFI_SYSTEM_BOOT_INIT_SCRIPT=/etc/init.d/service_wifi/wifi_system_boot_init.sh
MBSS_PRIMARY=0
MBSS_GUEST=1
MBSS_SIMPLETAP=2
is_mbss_enabled()
{
	PHY_IF=$1
	MBSS_ENABLED=`wl -i $PHY_IF mbss`
	return ${MBSS_ENABLED}
}
is_mbss_needed()
{
	PHY_IF=$1
	RET_CODE="0"
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`
	USER_VAP_STATE=`syscfg get ${WL_SYSCFG}_state`
	GUEST_ENABLED=`syscfg get guest_enabled`
	if [ ${WL_SYSCFG} = "wl0" ] && [ "$USER_VAP_STATE" = "up" ]; then
		WL0_GUEST_ENABLED=`syscfg get wl0_guest_enabled`
		if [ "${GUEST_ENABLED}" = "1" ] && [ "${WL0_GUEST_ENABLED}" = "1" ]; then
			RET_CODE="1"
		fi
		TC_ENABLED=`syscfg get tc_vap_enabled`
		if [ "${TC_ENABLED}" = "1" ]; then
			RET_CODE="1"
		fi
	fi
	if [ ${WL_SYSCFG} = "wl1" ] && [ "$USER_VAP_STATE" = "up" ]; then
		WL1_GUEST_ENABLED=`syscfg get wl1_guest_enabled`
		if [ "${GUEST_ENABLED}" = "1" ] && [ "${WL1_GUEST_ENABLED}" = "1" ]; then
			RET_CODE="1"
		fi
	fi
	if [ "2g" = "`syscfg get wifi_sta_radio`" ] && [ "1" = "`syscfg get wifi_sta_enabled`" ]; then
		ulog wlan status "${SERVICE_NAME}, PSTA mode, do not need MBSS"
		RET_CODE="0"
	fi
	return ${RET_CODE}
}
enable_mbss()
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`
	MBSS_ENABLED=`wl -i $PHY_IF mbss`
	if [ "${MBSS_ENABLED}" = "0" ]; then 
		wl -i ${PHY_IF} mbss 1
		wl -i ${PHY_IF} ssid -C $MBSS_PRIMARY "" > /dev/null
		wl -i ${PHY_IF} ssid -C $MBSS_GUEST "" > /dev/null
		if [ ${WL_SYSCFG} = "wl0" ]; then
			wl -i ${PHY_IF} ssid -C $MBSS_SIMPLETAP "" > /dev/null
		fi
		set_driver_guest_mac ${PHY_IF}
		if [ ${WL_SYSCFG} = "wl0" ]; then
			set_driver_tc_mac ${PHY_IF}	
		fi
		ulog wlan status "${SERVICE_NAME}, enable mbss: $PHY_IF"	
	else
		ulog wlan status "${SERVICE_NAME}, Warning: can not add mbss to $PHY_IF, mbss already existed"
		return 1
	fi
	return 0
}
disable_mbss()
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`
	MBSS_ENABLED=`wl -i $PHY_IF mbss`
	if [ "${MBSS_ENABLED}" = "1" ]; then 
		wl -i $PHY_IF mbss 0
		wl -i $PHY_IF bss -C $MBSS_PRIMARY down
		wl -i $PHY_IF bss -C $MBSS_GUEST down
		if [ ${WL_SYSCFG} = "wl0" ]; then
			wl -i $PHY_IF bss -C $MBSS_SIMPLETAP down
		fi
		ulog wlan status "${SERVICE_NAME}, disable mbss: $PHY_IF"
	else
		ulog wlan status "${SERVICE_NAME}, Warning: can not delete mbss from $PHY_IF, mbss did not exist"
		return 1
	fi
	return 0
}
configure_mbss()
{
	PHY_IF=$1
		is_mbss_needed ${PHY_IF}
		if [ "$?" = "1" ]; then 
			enable_mbss ${PHY_IF}
		fi
}
unconfigure_mbss()
{
	PHY_IF=$1
		is_mbss_needed ${PHY_IF}
		if [ "$?" = "0" ]; then 
			disable_mbss ${PHY_IF}
		fi
}
get_driver_chan_info()
{
	IFNAME=$1
	CHAN_TABLE=`wl -i ${IFNAME} chan_info`
	echo "$CHAN_TABLE"
}
set_driver_broadcast_disable()
{
	for PHY_IF in $PHYSICAL_IF_LIST; do
		WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`	
		USER_VAP_STATE=`syscfg get ${WL_SYSCFG}_state`
		USER_VAP=`syscfg get ${WL_SYSCFG}_user_vap`
		if [ "down" = "$USER_VAP_STATE" ]; then
			if [ -z "$USER_VAP" ]; then
				continue
			fi
			wl -i $USER_VAP ssid "" > /dev/null
			wl -i $USER_VAP down
		else #else bring vap up
			if [ -z "$USER_VAP" ]; then
				continue
			fi
			wl -i $USER_VAP up
		fi
	done
}
set_driver_wep_security()
{
	USER_VAP=$1
	WL_SYSCFG=`get_syscfg_interface_name $USER_VAP`	
	
	ENC_TYPE=`get_wep_keysize ${WL_SYSCFG}` #64-bits or 128-bits
	if [ "$ENC_TYPE" = "64-bits" ] || [ "$ENC_TYPE" = "128-bits" ]; then
		WEP_KEY_1=`syscfg get "$WL_SYSCFG"_key_0`
		WEP_KEY_2=`syscfg get "$WL_SYSCFG"_key_1`
		WEP_KEY_3=`syscfg get "$WL_SYSCFG"_key_2`
		WEP_KEY_4=`syscfg get "$WL_SYSCFG"_key_3`
		TX_KEY=`syscfg get "$WL_SYSCFG"_tx_key`
		if [ -z "$TX_KEY" ] || [ "0" = "$TX_KEY" ]; then
			TX_KEY=1 #Default if user for get to set
		fi
		
		KL_1=`echo $WEP_KEY_1 | wc -c`
		KL_2=`echo $WEP_KEY_2 | wc -c`
		KL_3=`echo $WEP_KEY_3 | wc -c`
		KL_4=`echo $WEP_KEY_4 | wc -c`
	
		for index in 0 1 2 3
		do
			wl -i $USER_VAP rmwep $index
		done
		
		wl -i $USER_VAP nmode 0
		wl -i $USER_VAP wsec 1
		wl -i $USER_VAP wsec_restrict 1
		wl -i $USER_VAP wpa_auth 0
		wl -i $USER_VAP eap 0
		wl -i $USER_VAP auth 0
		if [ "$ENC_TYPE" = "64-bits" ]; then
			if [ 11 = `expr $KL_1` ]; then
				wl -i $USER_VAP addwep 0 $WEP_KEY_1
			elif [ 6 = `expr $KL_1` ]; then
				wl -i $USER_VAP addwep 0 $WEP_KEY_1
			fi
			if [ 11 = `expr $KL_2` ]; then
				wl -i $USER_VAP addwep 1 $WEP_KEY_2
			elif [ 6 = `expr $KL_2` ]; then
				wl -i $USER_VAP addwep 1 $WEP_KEY_2
			fi
		
			if [ 11 = `expr $KL_3` ]; then
				wl -i $USER_VAP addwep 2 $WEP_KEY_3
			elif [ 6 = `expr $KL_3` ]; then
				wl -i $USER_VAP addwep 2 $WEP_KEY_3
			fi
			if [ 11 = `expr $KL_4` ]; then
				wl -i $USER_VAP addwep 3 $WEP_KEY_4
			elif [ 6 = `expr $KL_4` ]; then
				wl -i $USER_VAP addwep 3 $WEP_KEY_4
			fi
		elif [ "$ENC_TYPE" = "128-bits" ]; then
			if [ 27 = `expr $KL_1` ]; then
				wl -i $USER_VAP addwep 0 $WEP_KEY_1
			elif [ 14 = `expr $KL_1` ]; then
				wl -i $USER_VAP addwep 0 $WEP_KEY_1
			fi
			if [ 27 = `expr $KL_2` ]; then
				wl -i $USER_VAP addwep 1 $WEP_KEY_2
			elif [ 14 = `expr $KL_2` ]; then
				wl -i $USER_VAP addwep 1 $WEP_KEY_2
			fi
		
			if [ 27 = `expr $KL_3` ]; then
				wl -i $USER_VAP addwep 2 $WEP_KEY_3
			elif [ 14 = `expr $KL_3` ]; then
				wl -i $USER_VAP addwep 2 $WEP_KEY_3
			fi
			if [ 27 = `expr $KL_4` ]; then
				wl -i $USER_VAP addwep 3 $WEP_KEY_4
			elif [ 14 = `expr $KL_4` ]; then
				wl -i $USER_VAP addwep 3 $WEP_KEY_4
			fi
		fi
		DRV_TX_KEY_INDEX=`expr $TX_KEY - 1`
		wl -i $USER_VAP primary_key $DRV_TX_KEY_INDEX
	fi
	RET=$?
}
set_driver_extra_virtual_settings()
{
	USER_VAP=$1
	WL_SYSCFG=`get_syscfg_interface_name $USER_VAP`
	SSID_BROADCAST=`get_ssid_broadcast $WL_SYSCFG`
	if [ "1" = $SSID_BROADCAST ]; then
		wl -i $USER_VAP closed 0
	else
		wl -i $USER_VAP closed 1
	fi
	SEC_ENABLED="false"
	SEC_MODE=`syscfg get $WL_SYSCFG"_security_mode"`
	if [ "wpa-personal" = "$SEC_MODE" ] || [ "wpa2-personal" = "$SEC_MODE" ] || [ "wpa-mixed" = "$SEC_MODE" ]; then
		SEC_ENABLED="true"
	fi
	if [ "true" = "$SEC_ENABLED" ]; then
		REKEY_TIME=`syscfg get $WL_SYSCFG"_key_renewal"`
	fi
	AP_ISOLATION=`syscfg get $WL_SYSCFG"_ap_isolation"`
	if [ "enabled" = "$AP_ISOLATION" ]; then
		INTRABSS=1
	else
		INTRABSS=0
	fi
	wl -i $USER_VAP ap_isolate $INTRABSS
	FRAME_BURST=`syscfg get $WL_SYSCFG"_frame_burst"`
	if [ "enabled" = "$FRAME_BURST" ]; then
		OPTLEVEL=1
	else
		OPTLEVEL=0
	fi
	wl -i $USER_VAP frameburst $OPTLEVEL
	return
}
set_driver_mac_filter() 
{
	CURRENT_SETTING=`syscfg get wl_access_restriction`
	MAC_ENTRIES=`syscfg get wl_mac_filter`
	IF_LIST=$PHYSICAL_IF_LIST
	GUEST_ENABLED=`syscfg get guest_enabled`
	for j in $IF_LIST;	do
		WL_SYSCFG=`get_syscfg_interface_name $j`
		if [ $WL_SYSCFG = "wl0" ]; then
			WL0_GUEST_IFNAME=`syscfg get wl0_guest_vap`
			WL0_TC_IFNAME=`syscfg get tc_vap_user_vap`
			if [ "$GUEST_ENABLED" = "1" ] && [ "1" = "`syscfg get wl0_guest_enabled`" ] && [ "started" = "`sysevent get wifi_guest-status`" ] ; then
				IF_LIST=`echo "$IF_LIST $WL0_GUEST_IFNAME"`
			fi
			if [ "1" = "`syscfg get tc_vap_enabled`" ] && [ "started" = "`sysevent get wifi_simpletap-status`" ] ; then
				IF_LIST=`echo "$IF_LIST $WL0_TC_IFNAME"`
			fi
		fi
		if [ $WL_SYSCFG = "wl1" ]; then
			WL1_GUEST_IFNAME=`syscfg get wl1_guest_vap`
			if [ "$GUEST_ENABLED" = "1" ] && [ "1" = "`syscfg get wl1_guest_enabled`" ] && [ "started" = "`sysevent get wifi_wl1_guest-status`" ] ; then
				IF_LIST=`echo "$IF_LIST $WL1_GUEST_IFNAME"`
			fi
		fi
	done
	if [ "$CURRENT_SETTING" = "allow" ] || [ "$CURRENT_SETTING" = "deny" ]; then
		for if_name in $IF_LIST; do
			wl -i $if_name macmode 0
	 		wl -i $if_name mac none
	 		if [ -n "$MAC_ENTRIES" ]; then
				wl -i $if_name mac $MAC_ENTRIES
			fi
			if [ "$CURRENT_SETTING" = "allow" ]; then
				wl -i $if_name macmode 2
			else
				wl -i $if_name macmode 1
			fi
		done
		sysevent set wl_mac_filter-errinfo "Successful add MAC filter entries"
		sysevent set wl_mac_filter-status "started"
	else
		for if_name in $IF_LIST; do
			wl -i $if_name macmode 0
			wl -i $if_name mac none
		done
		sysevent set wl_mac_filter-errinfo "MAC filter is disabled"
		sysevent set wl_mac_filter-status "started"
	fi
}
set_driver_bi()
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`		 	
	SYSCFG_BCN_INTERVAL=`syscfg get "$WL_SYSCFG"_beacon_interval`
	BCN_INTERVAL=`get_vendor_beacon_interval "$SYSCFG_BCN_INTERVAL"`
	wl -i $PHY_IF bi $BCN_INTERVAL
}
set_driver_rtsthresh()
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`		 	
	SYSCFG_RTS_THRESH=`syscfg get "$WL_SYSCFG"_rts_threshold` 	
	RTS_THRESH=`get_vendor_rts_threshold "$SYSCFG_RTS_THRESH"`	
	wl -i $PHY_IF rtsthresh $RTS_THRESH
}
set_driver_gmode_protection_override()
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`		 	
	SYSCFG_CTS_PROTECTION=`syscfg get "$WL_SYSCFG"_cts_protection_mode` 
	CTS_PROTECTION=`get_vendor_cts_protection "$SYSCFG_CTS_PROTECTION"`
	if [ "wl0" = "$WL_SYSCFG" ]; then
		wl -i $PHY_IF gmode_protection_override $CTS_PROTECTION
	fi
}
set_driver_dtim()
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`		 	
	SYSCFG_DTIM=`syscfg get "$WL_SYSCFG"_dtim_interval`
	DTIM=`get_vendor_dtim_interval "$SYSCFG_DTIM"`
	wl -i $PHY_IF dtim $DTIM
}
set_driver_fragthresh()
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`		 	
	SYSCFG_FRAGTHRESH=`syscfg get "$WL_SYSCFG"_fragmentation_threshold`
	FRAGTHRESH=`get_vendor_fragthresh "$SYSCFG_FRAGTHRESH"`
	wl -i $PHY_IF fragthresh $FRAGTHRESH
}
set_driver_pwr_percent()
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`		 	
	SYSCFG_TXPOWER=`syscfg get "$WL_SYSCFG"_transmission_power`
	TXPOWER=`get_vendor_txpower "$SYSCFG_TXPOWER"`
	wl -i $PHY_IF pwr_percent $TXPOWER
}
set_driver_rate_nrate()
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`		 	
	NETWORK_MODE=`get_syscfg_network_mode $WL_SYSCFG`
	SYSCFG_N_TRANS_RATE=`syscfg get "$WL_SYSCFG"_n_transmission_rate`
	N_TRANS_RATE=`get_vendor_n_trans_rate "$SYSCFG_N_TRANS_RATE"`
	SYSCFG_TRANS_RATE=`syscfg get "$WL_SYSCFG"_transmission_rate`
	TRANS_RATE=`get_vendor_trans_rate "$SYSCFG_TRANS_RATE"`
	IS_NMODE=`is_nmode "$NETWORK_MODE"`
	if [ $IS_NMODE = 1 -a  "-1" = "$N_TRANS_RATE" ]; then 
		wl -i $PHY_IF rate -1
	fi
	if [ "wl0" = "$WL_SYSCFG" ]; then
		wl -i $PHY_IF bg_rate $TRANS_RATE
	elif [ "wl1" = "$WL_SYSCFG" ]; then
		wl -i $PHY_IF a_rate $TRANS_RATE
	fi
	if [ $IS_NMODE = 1 -a  "-1" != "$N_TRANS_RATE" ]; then 
		wl -i $PHY_IF nrate -m $N_TRANS_RATE
	fi
}
set_driver_wmf_bss_enable()
{
	PHY_IF=$1
	EMF_WMF=`syscfg get emf_wmf`
	if [ "disable" != "$EMF_WMF" ]; then
		wl -i $PHY_IF wmf_bss_enable 1
	else
		wl -i $PHY_IF wmf_bss_enable 0
	fi
}
set_driver_mimo_preamble()
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`
	AC_SUPPORTED=`is_11ac_supported $WL_SYSCFG`
	if [ "$AC_SUPPORTED" = "0" ]; then
		MIMO_PREAMBLE=`syscfg get "$WL_SYSCFG"_grn_field_pre`
		if [ "enabled" = "$MIMO_PREAMBLE" ]; then
			wl -i $PHY_IF mimo_preamble 1
		else 
			wl -i $PHY_IF mimo_preamble 0
		fi
	fi
}
set_driver_filter_war()
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`
		
	AC_SUPPORTED=`is_11ac_supported $WL_SYSCFG`
}
set_driver_vht_capability()
{
	PHY_IF=$1
	MODEL_NAME=`syscfg get device::model_base`
	if [ -z "$MODEL_NAME" ] ; then
		MODEL_NAME=`syscfg get device::modelNumber`
	fi
	if [ "`get_syscfg_interface_name $PHY_IF`" = "wl0" ] && [ "$MODEL_NAME" = "EA6900" ]; then
		VHT_MODE=`wl -i $PHY_IF vhtmode`
		N_MODE=`wl -i $PHY_IF nmode`
		if [ "1" = "`syscfg get wl0_256qam_enabled`" ] ; then
			wl -i $PHY_IF vht_features 1
		else
			wl -i $PHY_IF vht_features 0
		fi
		wl -i $PHY_IF vhtmode $VHT_MODE
		wl -i $PHY_IF nmode $N_MODE
	fi
}
set_driver_stbc_tx()
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`		 	
	STBC=`syscfg get "$WL_SYSCFG"_stbc`
	if [ "enabled" != "$STBC" ]; then
		wl -i $PHY_IF stbc_tx 0
	else
		wl -i $PHY_IF stbc_tx -1
	fi
}
set_driver_nrate()
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`		 	
	MCS32=`syscfg get "$WL_SYSCFG"_ht_dup_mcs32`
	if [ "enabled" = "$MCS32" ]; then
		wl -i $PHY_IF nrate -m 32
	fi
}
set_driver_wme_apsd()
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`		 	
	WMM=`syscfg get "$WL_SYSCFG"_wmm_ps`
	if [ "disabled" = "$WMM" ]; then
		wl -i $PHY_IF wme_apsd 0
	else
		wl -i $PHY_IF wme_apsd 1
	fi
}
set_driver_chanim_mode()
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`
	AUTO_CHANNEL=`syscfg get "$WL_SYSCFG"_channel`
		wl -i $PHY_IF chanim_mode 2 
}
set_driver_txbf_enable()
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF` 	
	STBC=`syscfg get "$WL_SYSCFG"_stbc`
	TXBF=`syscfg get "$WL_SYSCFG"_txbf_enabled`
	if [ -z "$TXBF" ] ; then
		sysevent set "${WL_SYSCFG}"_txbf_status "2"
	elif [ "1" = "$TXBF" ] && [ "enabled" != "$STBC" ] ; then
		wl -i $PHY_IF txbf_bfr_cap 1
		wl -i $PHY_IF txbf_bfe_cap 1
		wl -i $PHY_IF stbc_tx 0
		wl -i $PHY_IF txbf 1
		sysevent set "${WL_SYSCFG}"_txbf_status "1"
	else
		wl -i $PHY_IF txbf_bfr_cap 0
		wl -i $PHY_IF txbf_bfe_cap 0
		wl -i $PHY_IF txbf 0
		sysevent set "${WL_SYSCFG}"_txbf_status "0"
	fi
}
set_driver_chanspec()
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`		 	
	CHANNEL=`get_vendor_channel $WL_SYSCFG`	#0 for auto, otherwise number
	BANDWIDTH=`get_vendor_bandwidth $WL_SYSCFG`		#0 for auto, 20/40
	NETWORK_MODE=`get_syscfg_network_mode $WL_SYSCFG`       
	CHANSPEC_STR=`get_chanspec_setting $PHY_IF $CHANNEL $BANDWIDTH "$NETWORK_MODE"`
}
set_driver_network_mode() 
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`
	NVRAM_WL=`syscfg_nvram_map $WL_SYSCFG`
	WL_NETWORK_MODE=`get_syscfg_network_mode $WL_SYSCFG`
	wmm_s=`syscfg get wl_wmm_support`
	if [ "disabled" = "$wmm_s" ]; then
		wl -i $PHY_IF nmode 0
		wl -i $PHY_IF wme 0
	elif [ "enabled" = "$wmm_s" ]; then
		wl -i $PHY_IF nmode -1
		wl -i $PHY_IF wme 1     # set it On (1). was Auto (-1) initially.
	else
		wl -i $PHY_IF wme -1
	fi
	wl -i $PHY_IF mode_reqd 0
	MODEL=`syscfg get device::model_base`
	if [ -z "$MODEL" ] ; then
		MODEL=`syscfg get device::modelNumber`
	fi
	if [ "$MODEL" = "EA6900" ] ; then
		wl -i $PHY_IF vhtmode 0
	fi
	case "$WL_NETWORK_MODE" in
	"11n")
		if [ "$WL_SYSCFG" = "wl0" ]; then
			wl -i $PHY_IF band b 
			wl -i $PHY_IF nmode -1
			wl -i $PHY_IF mode_reqd 2
			if [ "$MODEL" = "EA6900" ] ; then
				wl -i $PHY_IF vhtmode 1
			fi
		elif [ "$WL_SYSCFG" = "wl1" ]; then
			wl -i $PHY_IF band a 
			wl -i $PHY_IF vhtmode 0 #turn off 11 ac mode
			wl -i $PHY_IF nmode -1 #turn on 11n mode. 
			wl -i $PHY_IF mode_reqd 2 #11n client is required
		fi
		;;
	"11b 11g 11n")
		wl -i $PHY_IF band b
		wl -i $PHY_IF nmode -1
		if [ "$MODEL" = "EA6900" ] ; then
			wl -i $PHY_IF vhtmode 1
		fi
		;;
	"11a")
		wl -i $PHY_IF band a
		wl -i $PHY_IF vhtmode 0
		wl -i $PHY_IF nmode 0
		;;
	"11b 11g")
		wl -i $PHY_IF band b
		wl -i $PHY_IF nmode 0
		wl -i $PHY_IF gmode 1   # g-only which also covers 11b XXX
		;;
	"11a 11n 11ac")
		wl -i $PHY_IF band a
		wl -i $PHY_IF vhtmode 1 
		wl -i $PHY_IF nmode -1  # by default
		;;
	"11ac")
		wl -i $PHY_IF band a
		wl -i $PHY_IF vhtmode 1 
		wl -i $PHY_IF mode_reqd 3 #11ac client only
		;;
	"11a 11n")
		wl -i $PHY_IF band a
		wl -i $PHY_IF vhtmode 0 #turn off 11 ac mode
		wl -i $PHY_IF nmode -1   #turn on 11n mode. 
		;;
	"11b")
		wl -i $PHY_IF band b
		wl -i $PHY_IF nmode 0
		wl -i $PHY_IF gmode 0   
		;;
	"11g")
		wl -i $PHY_IF band b
		wl -i $PHY_IF nmode 0
		wl -i $PHY_IF gmode 1
		wl -i $PHY_IF mode_reqd 1 #11g client only
		;;
	*)
		;;
	esac
	if [ "$WL_NETWORK_MODE" != "11g" ] && [ "$WL_NETWORK_MODE" != "11b" ] && [ "$WL_NETWORK_MODE" != "11a" ] && [ "$WL_NETWORK_MODE" != "11b 11g" ]; then
		wl -i $PHY_IF rx_amsdu_in_ampdu 0
		wl -i $PHY_IF amsdu 0
	fi
	if [ "`is_nmode "$WL_NETWORK_MODE"`" = "1" ]; then
		nvram_set ${NVRAM_WL}_nmode "-1"
	else
		nvram_set ${NVRAM_WL}_nmode 0
	fi
   	nvram_set wl_nmode "-1"
}
set_driver_country_code()
{
	if [ "`syscfg get device::modelNumber`" = "EA6500" ] && [ "`syscfg get device::hw_revision`" = "1" ] ; then
		ccode=`syscfg get device::ccode`
		regrev=`syscfg get device::regrev`
		if [ -z "$ccode" ] || [ -z "$regrev" ] ; then
			regioncode="Q2/13"	#default to US
		else
			regioncode="$ccode/$regrev"
		fi
		for PHY_IF in $PHYSICAL_IF_LIST; do
			wl -i $PHY_IF country $regioncode
			echo "wifi, carrera $PHY_IF country code set $regioncode" #for debugging
		done
	fi
}
enable_radios()
{
	nvram_set wl_radio 1
	nvram_set wl0_radio 1
	nvram_set wl1_radio 1
}
set_macs()
{
	LAN_HWADDR=`ifconfig eth0 | grep HWaddr | awk '{print $5}'`
	LAN_MAC=`syscfg get lan_mac_addr`
	if [ ! -z "$LAN_MAC" ] && [ "$LAN_MAC" != "$LAN_HWADDR" ]; then
		ifconfig eth0 down
		ifconfig eth0 hw ether $LAN_MAC
		ifconfig eth0 up
	fi
	WL0_PHY_IF=`syscfg get wl0_physical_ifname`
	WL0_HWADDR=`ifconfig ${WL0_PHY_IF} | grep HWaddr | awk '{print $5}'`
	WL0_MAC=`syscfg get wl0_mac_addr`
	if [ ! -z "$WL0_MAC" ] && [ "$WL0_MAC" != "$WL0_HWADDR" ]; then
		ifconfig $WL0_PHY_IF down
		ifconfig $WL0_PHY_IF hw ether $WL0_MAC
		ifconfig $WL0_PHY_IF up
	fi
	WL1_PHY_IF=`syscfg get wl1_physical_ifname`
	WL1_HWADDR=`ifconfig ${WL1_PHY_IF} | grep HWaddr | awk '{print $5}'`
	WL1_MAC=`syscfg get wl1_mac_addr`
	if [ ! -z "$WL1_MAC" ] && [ "$WL1_MAC" != "$WL1_HWADDR" ]; then
		ifconfig $WL1_PHY_IF down
		ifconfig $WL1_PHY_IF hw ether $WL1_MAC
		ifconfig $WL1_PHY_IF up
	fi
}
set_driver_guest_mac()
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`
	if [ "$WL_SYSCFG" = "wl0" ]; then
		WL0_GUEST_IFNAME=`syscfg get wl0_guest_vap`
		WL0_GUEST_MAC=`syscfg get "$WL_SYSCFG".1_mac_addr`
		ifconfig $PHY_IF down
		wl -i $WL0_GUEST_IFNAME down
		wl -i $WL0_GUEST_IFNAME cur_etheraddr $WL0_GUEST_MAC
		ifconfig $WL0_GUEST_IFNAME down
		ifconfig $WL0_GUEST_IFNAME hw ether $WL0_GUEST_MAC
		ulog wlan status "Guest VAP interface $WL0_GUEST_IFNAME is enabled with MAC Address $WL0_GUEST_MAC"
		ifconfig $PHY_IF up
	fi
	if [ "$WL_SYSCFG" = "wl1" ]; then
		WL1_GUEST_IFNAME=`syscfg get wl1_guest_vap`
		WL1_GUEST_MAC=`syscfg get "$WL_SYSCFG".1_mac_addr`
		ifconfig $PHY_IF down
		wl -i $WL1_GUEST_IFNAME down
		wl -i $WL1_GUEST_IFNAME cur_etheraddr $WL1_GUEST_MAC
		ifconfig $WL1_GUEST_IFNAME down
		ifconfig $WL1_GUEST_IFNAME hw ether $WL1_GUEST_MAC
		ulog wlan status "Guest VAP interface $WL1_GUEST_IFNAME is enabled with MAC Address $WL1_GUEST_MAC"
		ifconfig $PHY_IF up
	fi
}
set_driver_tc_mac()
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`
	if [ "$WL_SYSCFG" = "wl0" ]; then
		WL0_TC_IFNAME=`syscfg get tc_vap_user_vap`
		WL0_TC_MAC=`syscfg get "$WL_SYSCFG".2_mac_addr`
		ifconfig $PHY_IF down
		wl -i $WL0_TC_IFNAME down
		wl -i $WL0_TC_IFNAME cur_etheraddr $WL0_TC_MAC
		ifconfig $WL0_TC_IFNAME down
		ifconfig $WL0_TC_IFNAME hw ether $WL0_TC_MAC
		ulog wlan status "T&C VAP interface $WL0_TC_IFNAME is enabled with MAC Address $WL0_TC_MAC"
		ifconfig $PHY_IF up
	fi
}
start_driver_wps_process()
{
	/usr/sbin/wps_monitor &
	DEBUG echo "" > /dev/console
}
stop_driver_wps_process()
{
	killall -q wps_monitor
	rm -f /tmp/wps_monitor.pid
}
stop_auto_channel_process()
{
	PID=`ps | awk "/acs_cli/"' {print $1}'`
	kill $PID > /dev/null 2>&1
	PID=`ps | awk "/chanspecfix.sh/"' {print $1}'`
	kill $PID > /dev/null 2>&1
	nvram unset acs_ifnames
	killall -q acsd
}
bring_phy_if_down()
{
	PHY_IF=$1
	ulog wlan status "${SERVICE_NAME}, bring ${PHY_IF} down"
	wl -i ${PHY_IF} ssid "" > /dev/null
	wl -i ${PHY_IF} down
}
bring_phy_if_up()
{
	PHY_IF=$1
	ulog wlan status "${SERVICE_NAME}, bring $1 up"
	wl -i ${PHY_IF} up
}
bring_vir_if_down()
{
	PHY_IF=$1
	VIR_IF=$2
	
	ulog wlan status "${SERVICE_NAME}, bring $PHY_IF:$VIR_IF down"
	wl -i ${PHY_IF} bss -C ${VIR_IF} down
}
bring_vir_if_up()
{
	PHY_IF=$1
	VIR_IF=$2
	
	ulog wlan status "${SERVICE_NAME}, bring $PHY_IF:$VIR_IF up"
	wl -i ${PHY_IF} bss -C ${VIR_IF} up
}
set_syscfg_trans_rate() 
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`
	if [ "wl0" = "$WL_SYSCFG" ]; then
		myrate=`wl -i $PHY_IF bg_rate`	
	elif [ "wl1" = "$WL_SYSCFG" ]; then
		myrate=`wl -i $PHY_IF a_rate`	
	fi
	if [ "$myrate" = "auto" ]; then
		rate="auto"
	else
		rate=`echo $myrate | grep Mbps | awk '/ / {print $PHY_IF}'`
		if [ -z $rate ]; then 
			rate=`echo $myrate | grep Kbps | awk '/ / {print $PHY_IF}'`
			if [ -z $rate ]; then 
				"Error missing rate information: $myrate" > /dev/console
			else
				rate=`expr $rate / 1000`
			fi
		fi
		rate=`expr $rate \* 1000000`
	fi
	sysevent set "$WL_SYSCFG"_transmission_rate $rate
}
set_syscfg_n_trans_rate() 
{
	PHY_IF=$1
	rate=`wl -i $PHY_IF nrate`
	case $rate in
	*auto*) 
		rate="auto";;
	*fixed*)
		rate=`echo $rate | grep -rin "mcs" | awk -F" " '{print $3}'`;;
	*)
		ERROR="incorrect mode for rate: %rate"
		echo $ERROR > /dev/console
		rate="auto";;
	esac   
    
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`
	sysevent set "$WL_SYSCFG"_n_transmission_rate $rate
}
get_chanspec_setting ()
{
	PHY_IF=$1
	CHANNEL=$2
	BANDWIDTH=$3
	WL_NETWORK_MODE=$4
	CHANSPEC="$CHANNEL"
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`
	NVRAM_WL=`syscfg_nvram_map $WL_SYSCFG`
	OBSS_COEX=2 #invalid value as default
	if [ "20" != "$BANDWIDTH" ]; then
		OBSS_COEX=1
	fi
	
	if [ "20" = "$BANDWIDTH" ]; then
		if [ "$WL_SYSCFG" = "wl0" ]; then
			wl -i $PHY_IF bw_cap 2g 1 # 2.4 GHZ
		else 
			wl -i $PHY_IF bw_cap 5g 1 # 5 GHZ
		fi
		if [ "11g" != "$WL_NETWORK_MODE" ] && [ "11b 11g" != "$WL_NETWORK_MODE" ] && [ "11a" != "$WL_NETWORK_MODE" ] ; then
			OBSS_COEX=0
		fi
		CHANSPEC="$CHANNEL"
	elif [ "40" = "$BANDWIDTH" ]; then	# 40MHz for 5G, or Auto bandwidth for 2G
		if [ "$WL_SYSCFG" = "wl0" ]; then 		
			wl -i $PHY_IF bw_cap 2g 3 # 2.4 GHZ
		else
			wl -i $PHY_IF bw_cap 5g 3 # 5 GHZ
		fi
		is_nmode=`is_nmode "$WL_NETWORK_MODE"`
		if [ $is_nmode = 1 ]; then
			OBSS_COEX=0            # force it to be 40.  
		fi
		ic=`expr $CHANNEL`
		if [ "wl0" = "$WL_SYSCFG" ]; then
			if [ "11n" != "$WL_NETWORK_MODE" ]; then
				OBSS_COEX=1 #auto
			fi
			REGION_CODE=`syscfg get device::ccode`
			MIX_CHANNEL=7
			if [ "EU" = "$REGION_CODE" ]; then
				MIX_CHANNEL=9
			fi
			if [ $ic -lt 5 ]; then
				SIDEBAND="l"
			elif [ $ic -gt $MIX_CHANNEL ]; then
				SIDEBAND="u"
			elif [ $ic -ge 5 ] || [ $ic -le $MIX_CHANNEL ]; then
				sideband=`syscfg get "$WL_SYSCFG"_sideband`
				SIDEBAND="u"
				if [ "lower" = "$sideband" ]; then
					SIDEBAND="l"
				fi
			fi	    
		else
			if [ 36 = $ic -o 44 = $ic -o 52 = $ic -o 60 = $ic -o 149 = $ic -o 157 = $ic ]; then
				SIDEBAND="l"
			elif [ 40 = $ic -o 48 = $ic -o 56 = $ic -o 64 = $ic -o 153 = $ic -o 161 = $ic ]; then
				SIDEBAND="u"
			else
				SIDEBAND=""
			fi
		fi
		CHANSPEC="$CHANNEL$SIDEBAND"
	elif [ "80" = "$BANDWIDTH" ]; then	# 80MHz for 5G
		wl -i $PHY_IF bw_cap 5g 7
		CHANSPEC="$CHANNEL/80"
	else
		echo "Fatal error: $PHY_IF bandwidth[$BANDWIDTH] incorrect" > /dev/console
	fi
	ulog wlan status "$PHY_IF: $BANDWIDTH MHz bandwidth (0 for auto) with sideband=$SIDEBAND " > /dev/console
	if [ "0" != "$CHANNEL" ]; then
		nvram_set ${NVRAM_WL}_chanspec $CHANSPEC
		wl -i $PHY_IF chanspec $CHANSPEC		
	else
		nvram_set ${NVRAM_WL}_chanspec 0
	fi
	if [ "2" != "$OBSS_COEX" ]; then
		wl -i $PHY_IF obss_coex $OBSS_COEX
	fi
	echo "$CHANSPEC"
}
set_driver_pspretend_threadhold()
{
	PHY_IF=$1
	VALID_SETTING=10
	BAND=`wl -i $PHY_IF band`
	if [ "a" != "$BAND" ]; then
		return
	fi
	wl -i $PHY_IF pspretend_threshold $VALID_SETTING
}
set_driver_24VHT()
{
	PHY_IF=$1
	if [ "1" = "`syscfg get wl0_256qam_enabled`" ] ; then
		echo "${SERVICE_NAME}, set VHT mode on 2.4 g radio"
		wl -i $PHY_IF ampdu_mpdu 64
		wl -i $PHY_IF mpc 1
		wl -i $PHY_IF ack_ratio 4
	else
		wl -i $PHY_IF ampdu_mpdu -1
		wl -i $PHY_IF mpc 0
		wl -i $PHY_IF ack_ratio 2
	fi
}
configure_user()
{
	USER_VAP=$1
	WL_SYSCFG=`get_syscfg_interface_name $USER_VAP`
	USER_SSID=`syscfg get "$WL_SYSCFG"_ssid`
	WPA_AUTH=`get_wpa_auth "$WL_SYSCFG"`
	WSEC=`get_wsec "$WL_SYSCFG"`
	wl -i $USER_VAP wpa_auth 0
	wl -i $USER_VAP wsec 0
	wl -i $USER_VAP eap 0
	wl -i $USER_VAP auth 0
	wl -i $USER_VAP ssid -C $MBSS_PRIMARY "$USER_SSID" > /dev/null
	case "$WPA_AUTH" in
	"0")
		wl -i $USER_VAP wsec_restrict 0
		RET=$?
		;;
	"1")
		set_driver_wep_security ${USER_VAP}
		RET=0
		;;
	*)
		wl -i $USER_VAP wsec $WSEC
		wl -i $USER_VAP wsec_restrict 1
		wl -i $USER_VAP wpa_auth $WPA_AUTH
		wl -i $USER_VAP eap 1
		wl -i $USER_VAP auth 0
		RET=0
		;;
	esac
	syscfg_set "$WL_SYSCFG"_wpa_auth $WPA_AUTH
 	if [ -n "$WSEC" ]; then
		syscfg_set "$WL_SYSCFG"_wsec $WSEC
	fi
	return $RET
}
configure_guest() 
{
	PHY_IF=$1
	WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`
	USER_VAP=`syscfg get ${WL_SYSCFG}_user_vap`
	GUEST_VAP=`syscfg get ${WL_SYSCFG}_guest_vap`
	if [ ${WL_SYSCFG} = "wl0" ]; then
		GUEST_SSID=`syscfg get guest_ssid`
		GUEST_SSID_BROADCAST=`syscfg get guest_ssid_broadcast`
	else
		GUEST_SSID=`syscfg get wl1_guest_ssid`
		GUEST_SSID_BROADCAST=`syscfg get wl1_guest_ssid_broadcast`
	fi
	wl -i $USER_VAP ssid -C $MBSS_GUEST "$GUEST_SSID" > /dev/null   # remove echoing from wl
	wl -i $GUEST_VAP wsec 0
	wl -i $GUEST_VAP wsec_restrict 1
	wl -i $GUEST_VAP eap 0
	wl -i $GUEST_VAP auth 0
	if [ "0" = $GUEST_SSID_BROADCAST ] ; then
		HIDE_SSID=1
	else
		HIDE_SSID=0 
	fi
	wl -i $GUEST_VAP closed $HIDE_SSID
	return 0
}
configure_simpletap()
{
	TC_VAP=$1
	
	TC="tc_vap"
	TC_VAP_SSID=`syscfg get ${TC}_ssid`
	WPA_AUTH=`syscfg get ${TC}_wpa_auth`
	WSEC=`syscfg get ${TC}_wsec`
	if [ "0" = `syscfg get ${TC}_ssid_broadcast` ] ; then
		HIDE_SSID=1
	else
		HIDE_SSID=0 
	fi
	wl -i $TC_VAP closed $HIDE_SSID
	wl -i $TC_VAP ssid "$TC_VAP_SSID" > /dev/null	# remove echoing from wl
	wl -i $TC_VAP wsec $WSEC
	wl -i $TC_VAP wsec_restrict 1
	wl -i $TC_VAP eap 1
	wl -i $TC_VAP auth 0
	nvram_set ${TC_VAP}_ssid "$TC_VAP_SSID"
	return 0
}
clean_settings()
{
	PHY_IF=$1
	if [ "0" != "`wl -i ${PHY_IF} obss_coex`" ]; then 		
		wl -i ${PHY_IF} obss_coex 0
	fi
}
platform_physical_pre_setting()
{
	ulog wlan status "wifi, platform_physical_pre_setting()"
}
platform_physical_post_setting()
{
	ulog wlan status "$SERVICE_NAME, platform_physical_post_setting()"
}
platform_physical_onetime_setting()
{
	CHECK_STATUS=`sysevent get wifi_system_boot_init`
	if [ "1" != "$CHECK_STATUS" ]; then
		echo "wifi, system_boot_init"
		. $WIFI_SYSTEM_BOOT_INIT_SCRIPT
	fi
	ONE_TIME=`sysevent get physical-one-time-setting`
	if [ "$ONE_TIME" != "TRUE" ] ; then
		ulog wlan status "wifi, platform_physical_onetime_setting()"
		enable_radios
		set_driver_country_code
		set_macs
		set_channel_list
		nvram_set acs_2g_ch_no_restrict 1
		nvram_set acs_2g_ch_no_ovlp 1
		for PHY_IF in $PHYSICAL_IF_LIST; do
			bring_phy_if_down $PHY_IF
			wl -i $PHY_IF ap 1
			wl -i $PHY_IF spect 0
			wl -i $PHY_IF mpc 0
		done
		sysevent set physical-one-time-setting "TRUE"
	fi
}
platform_virtual_onetime_setting()
{
	ONE_TIME=`sysevent get virtual-one-time-setting`
	if [ "$ONE_TIME" != "TRUE" ] ; then
		echo "wifi, platform_virtual_onetime_setting()"
		ulog wlan status "wifi, platform_virtual_onetime_setting()"
		GUEST_ENABLED=`syscfg get guest_enabled`
		WL0_GUEST_ENABLED=`syscfg get wl0_guest_enabled`
		WL1_GUEST_ENABLED=`syscfg get wl1_guest_enabled`
		SIMPLETAP=`syscfg get tc_vap_enabled`
		if [ "$GUEST_ENABLED" = "1" ] && [ "$WL0_GUEST_ENABLED" = "1" ]; then
			WL0_PHY_IF=`syscfg get wl0_user_vap`
			WL_SYSCFG=`get_syscfg_interface_name $WL0_PHY_IF`
			GUEST_VAP=`syscfg get ${WL_SYSCFG}_guest_vap`
			wl -i $GUEST_VAP wpa_auth 0
		fi
		if [ "$SIMPLETAP" = "1" ] ; then
			TC="tc_vap"
			TC_VAP=`syscfg get ${TC}_user_vap`
			WPA_AUTH=`syscfg get ${TC}_wpa_auth`
			wl -i $TC_VAP wpa_auth $WPA_AUTH
		fi
		if [ "$GUEST_ENABLED" = "1" ] && [ "$WL1_GUEST_ENABLED" = "1" ] ; then
			WL1_PHY_IF=`syscfg get wl1_user_vap`
			WL_SYSCFG=`get_syscfg_interface_name $WL1_PHY_IF`
			WL1_GUEST_VAP=`syscfg get ${WL_SYSCFG}_guest_vap`
			wl -i $WL1_GUEST_VAP wpa_auth 0
		fi
		sysevent set virtual-one-time-setting "TRUE"
	fi
}
set_wps_state()
{
	for PHY_IF in $PHYSICAL_IF_LIST; do
		WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`
		wps_state="unconfigured"
		ssid_broadcast=`get_ssid_broadcast $WL_SYSCFG`
		WL_MACFILTER_ENABLED=`syscfg get wl_access_restriction`
		sec_mode=`get_wpa_auth $WL_SYSCFG`
		WL_VAP_STATE=`syscfg get ${WL_SYSCFG}_state`
		if [ "$WL_VAP_STATE" = "down" ] || [ 1 = $sec_mode ] || [ 2 = $sec_mode ] || [ 4 = $sec_mode ] || 
			[ 8 = $sec_mode ] || [ 64 = $sec_mode ] || [ 66 = $sec_mode ] || [ 0 = $ssid_broadcast ]; then
			wps_state="disabled"
		fi
		if [ "disabled" != "$wps_state" ]; then
			ssid=`syscfg get ${WL_SYSCFG}_ssid`
			if [ "$ssid" != "`syscfg get ${WL_SYSCFG}_default_ssid`" ] && [ "$ssid" != "`syscfg get wl_default_ssid`" ] ; then
				wps_state="configured"
			else
				if [ 0 != $sec_mode ]; then
					wps_state="configured"
				fi
			fi
		fi	
		if [ "$WL_MACFILTER_ENABLED" = "allow" ] || [ "$WL_MACFILTER_ENABLED" = "deny" ]; then
			wps_state="disabled"
		fi
		WPS_USER_SETTING=`syscfg get wps_user_setting`
		if [ "disabled" = "$WPS_USER_SETTING" ]; then
			wps_state="disabled"
		fi
		sys_wps_state=`syscfg get ${WL_SYSCFG}_wps_state`
		if [ "$sys_wps_state" != "$wps_state" ]; then
			syscfg_set ${WL_SYSCFG}_wps_state $wps_state
		fi
		sysevent set ${WL_SYSCFG}_wps_status $wps_state
		NVRAM_WL=`syscfg_nvram_map $WL_SYSCFG`
		if [ "disabled" = "$wps_state" ]; then
			nvram_set ${NVRAM_WL}_wps_mode disabled
		else
			nvram_set ${NVRAM_WL}_wps_mode enabled
			wps_set_nvram_params
		fi
	done
	
}
start_eapd_wps_nas()
{
	NAS_EAPD_IF_LIST=""
	WPS_EAPD_IF_LIST=""
	WL0_WPS_STATE=""
	WL1_WPS_STATE=""
	STATE_24=`syscfg get wl0_state`
	STATE_5=`syscfg get wl1_state`
	VAP_24=`syscfg get wl0_user_vap`
	VAP_5=`syscfg get wl1_user_vap`
	VAP_TC=`syscfg get tc_vap_user_vap`
	SECURITY_24=`syscfg get wl0_security_mode`
	SECURITY_5=`syscfg get wl1_security_mode`
	WIFI_STA=`syscfg get wifi_sta_user_vap`
	if [ "1" = "`sysevent get wifi_sta_up`" ]; then
		if [ "$WIFI_STA" = "$VAP_24" ] ; then
			STATE_24="down"
		elif [ "$WIFI_STA" = "$VAP_5" ] ; then
			STATE_5="down"
		fi
	fi
	set_wps_state
	final_wps_state_check
	if [ "up" = "$STATE_24" ] || [ "up" = "$STATE_5" ]; then
		if [ "up" = "$STATE_24" ] && [ "wep" != "$SECURITY_24" ]; then
			NAS_EAPD_IF_LIST="$VAP_24"
		fi
		if [ "up" = "$STATE_5" ] && [ "wep" != "$SECURITY_5" ]; then
			NAS_EAPD_IF_LIST=`echo "$NAS_EAPD_IF_LIST $VAP_5"`
		fi
		if [ "1" = "`syscfg get tc_vap_enabled`" ] && [ "up" = "$STATE_24" ]; then
			NAS_EAPD_IF_LIST=`echo "$NAS_EAPD_IF_LIST $VAP_TC"`
		fi
		if [ "1" = "`sysevent get wifi_sta_up`" ]; then
			NAS_EAPD_IF_LIST=`echo "$NAS_EAPD_IF_LIST $WIFI_STA"`
		fi
		/usr/sbin/nas_wrapper
	fi
	for PHY_IF in $PHYSICAL_IF_LIST; do
		WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`
		if [ "wl0" = "$WL_SYSCFG" ]; then
			WL0_WPS_STATE=`sysevent get "$WL_SYSCFG"_wps_status`
		elif [ "wl1" = "$WL_SYSCFG" ]; then
			WL1_WPS_STATE=`sysevent get "$WL_SYSCFG"_wps_status`
		fi
		DEF_SSID=`syscfg get wl_default_ssid`
		if [ "unconfigured" = "$WL0_WPS_STATE" ] || [ "unconfigured" = "$WL1_WPS_STATE" ]; then
			nvram_set wps_device_name "$DEF_SSID "AP
			nvram_set lan_wps_oob enabled
			nvram_unset wps_pinfail_state
			nvram_unset wps_sta_devname
			nvram_unset wps_sta_mac
		elif [ "configured" = "$WL0_WPS_STATE" ] || [ "configured" = "$WL1_WPS_STATE" ]; then
			USR_SSID=`syscfg get wl0_ssid`
			if [ -z "$USR_SSID" ]; then
				USR_SSID=`syscfg get wl1_ssid`
			fi
			nvram_set wps_device_name "$USR_SSID "AP
			nvram_set lan_wps_oob disabled
		else
			nvram_set wps_device_name "$DEF_SSID "AP
		fi
	done
	
	if [ "disabled" != "$WL0_WPS_STATE" ] || [ "disabled" != "$WL1_WPS_STATE" ]; then
		initialize_wps
		if [ "disabled" != "$WL0_WPS_STATE" ] && [ "up" = "$STATE_24" ]; then
			VAP_24=`syscfg get wl0_user_vap`
			WPS_EAPD_IF_LIST="$VAP_24"
		fi
		if [ "disabled" != "$WL1_WPS_STATE" ] && [ "up" = "$STATE_5" ]; then
			VAP_5=`syscfg get wl1_user_vap`
			WPS_EAPD_IF_LIST=`echo "$WPS_EAPD_IF_LIST $VAP_5"`
		fi
		/bin/eapd -nas $NAS_EAPD_IF_LIST -wps $WPS_EAPD_IF_LIST
		configure_wps "$WPS_EAPD_IF_LIST"
	else
		/bin/eapd -nas $NAS_EAPD_IF_LIST
	fi
}
final_wps_state_check()
{
	WL0_WPS_STATE=`syscfg get wl0_wps_state`
	WL1_WPS_STATE=`syscfg get wl1_wps_state`
	if [ "$WL0_WPS_STATE" = "configured" ] || [ "$WL1_WPS_STATE" = "configured" ]; then
		if [ "$WL1_WPS_STATE" = "unconfigured" ]; then
			NVRAM_WL=`syscfg_nvram_map "wl1"`
			syscfg_set wl1_wps_state configured
			sysevent set wl1_wps_status configured
			nvram_set ${NVRAM_WL}_wps_mode enabled
		fi
		if [ "$WL0_WPS_STATE" = "unconfigured" ]; then
			NVRAM_WL=`syscfg_nvram_map "wl0"`
			syscfg_set wl0_wps_state configured
			sysevent set wl0_wps_status configured
			nvram_set ${NVRAM_WL}_wps_mode enabled
		fi
	fi
}
wps_set_nvram_params()
{
	MANUFACTURER=`syscfg get device::manufacturer`
	nvram_set wps_mfstring "$MANUFACTURER"
	MODELNUM=`syscfg get device::modelNumber`
	nvram_set wps_modelnum "$MODELNUM"
}
initialize_wps() 
{
	NVRAM_LIST="wps_seed wps_config_state wps_addER wps_pbc_force \
	wps_proc_mac wps_currentband \
	wps_event wps_enr_mode wps_enr_ifname wps_enr_ssid wps_enr_bssid \
	wps_enr_wsec wps_unit"
	for ITEM in $NVRAM_LIST; do
		nvram_unset $ITEM
	done
}
configure_wps()
{
	WPS_IF_LIST="$1"
	for i in $WPS_IF_LIST; do
		WL_SYSCFG=`get_syscfg_interface_name $i`	
		NVRAM_WL=`syscfg_nvram_map $WL_SYSCFG`
		SSID=`syscfg get $WL_SYSCFG"_ssid"`
		PASSPHRASE=`syscfg get $WL_SYSCFG"_passphrase"`
		CRYPTO=`syscfg get $WL_SYSCFG"_encryption"`
		WPA_AUTH=`get_wpa_auth $WL_SYSCFG`
		if [ "0" = "$WPA_AUTH" ]; then
			PASSPHRASE=""
			CRYPTO=""
		fi
		case $WPA_AUTH in
			"4")
				AKM="psk "
				;;
			"128")
				AKM="psk2 "
				;;
			"132")
				AKM="psk psk2 "
				;;
			*)
				AKM=""
				;;
		esac
		nvram_set $NVRAM_WL"_ssid" "$SSID"
		nvram_set $NVRAM_WL"_akm" "$AKM"
		nvram_set $NVRAM_WL"_crypto" "$CRYPTO"
		nvram_set $NVRAM_WL"_wpa_psk" "$PASSPHRASE"
	done
	nvram_set wps_status 0
	nvram_set wps_method 1
	nvram_set wps_config_command 0
	nvram_set wps_proc_mac ""
	WPS_RESTART=`nvram get wps_restart`
	if [ "1" = "WPS_RESTART" ]; then
		nvram_set wps_restart 0
	else
		nvram_set wps_restart 0
		nvram_set wps_proc_status 0
	fi
	nvram_set wps_sta_pin "00000000"
	nvram_set wps_currentband ""
	start_driver_wps_process
	return 0
}
save_wps_settings_to_syscfg() 
{
	WL_SYSCFG_0=`get_syscfg_interface_name eth1`
	WL_SYSCFG_1=`get_syscfg_interface_name eth2`
	USR_SSID_0=`syscfg get ${WL_SYSCFG_1}_ssid`
	NEW_SSID_0=`nvram get wl1_ssid`
	USR_SSID_1=`syscfg get ${WL_SYSCFG_0}_ssid`
	NEW_SSID_1=`nvram get wl0_ssid`
	if [ "$USR_SSID_0" != "$NEW_SSID_0" ] ; then
		NEW_SSID=`nvram get wl1_ssid`
		NEW_WPA_PSK=`nvram get wl1_wpa_psk`
		NEW_CRYPTO=`nvram get wl1_crypto`
		NEW_AKM=`nvram get wl1_akm`
	elif [ "$USR_SSID_1" != "$NEW_SSID_1" ] ; then
		NEW_SSID=`nvram get wl0_ssid`
		NEW_WPA_PSK=`nvram get wl0_wpa_psk`
		NEW_CRYPTO=`nvram get wl0_crypto`
		NEW_AKM=`nvram get wl0_akm`
	else
		echo "no new settings" > /dev/console
		return 0
	fi
	for PHY_IF in $PHYSICAL_IF_LIST; do
		WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`
		syscfg_set $WL_SYSCFG"_ssid" "$NEW_SSID"
		syscfg_set $WL_SYSCFG"_passphrase" "$NEW_WPA_PSK"
		syscfg_set $WL_SYSCFG"_encryption" "$NEW_CRYPTO"
		case "$NEW_AKM" in
			"psk ")
				syscfg_set $WL_SYSCFG"_security_mode" "wpa-personal"
			;;
			"psk2 ")
				syscfg_set $WL_SYSCFG"_security_mode" "wpa2-personal"
			;;
			"psk psk2 ")
				syscfg_set $WL_SYSCFG"_security_mode" "wpa-mixed"
			;;
		*)
			echo "Invalid security mode from nvram" > /dev/console
			syscfg_set $WL_SYSCFG"_security_mode" "disabled"
			;;
		esac
	done
}
platform_runtime_setting()
{
	ulog wlan status "wifi, platform_runtime_setting(interface=$1)"
	EMF_WMF=`syscfg get emf_wmf`	
	if [ "disable" != "$EMF_WMF" ]; then
		nvram_set emf_enable 1
		emf start br0
	else
		emf stop br0
		nvram_unset emf_enable
	fi
	
	PHY_IF=$1
	bring_phy_if_down $PHY_IF
	set_driver_wmf_bss_enable $PHY_IF
	set_driver_mimo_preamble $PHY_IF
	set_driver_filter_war $PHY_IF	
	set_driver_stbc_tx $PHY_IF
	set_driver_nrate $PHY_IF
	set_driver_wme_apsd $PHY_IF
	set_driver_network_mode $PHY_IF
	set_driver_chanspec $PHY_IF
	set_driver_chanim_mode $PHY_IF
	set_driver_bi $PHY_IF
	set_driver_rtsthresh $PHY_IF
	set_driver_gmode_protection_override $PHY_IF
	set_driver_dtim $PHY_IF
	set_driver_fragthresh $PHY_IF
	set_driver_pwr_percent $PHY_IF
	set_driver_rate_nrate $PHY_IF
	set_driver_txbf_enable $PHY_IF
	set_syscfg_trans_rate $PHY_IF
	set_syscfg_n_trans_rate $PHY_IF
	set_driver_vht_capability $PHY_IF	
}
stop_eapd_wps_nas()
{
	for PHY_IF in $PHYSICAL_IF_LIST; do
		WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`
		USER_VAP=`syscfg get "${WL_SYSCFG}"_user_vap`
		if [ ! -z "$USER_VAP" ]; then
			PID=`ps | grep -e eapd -e nas | awk "/$USER_VAP/"' {print $1}'`
			kill $PID > /dev/null 2>&1
			DEBUG ulog wlan status "${SERVICE_NAME}, Stopped 1x Authentication agent on $USER_VAP"
		fi
	done
	PID=`ps | awk "/nas/"' {print $1}'`
	kill $PID > /dev/null 2>&1
	stop_driver_wps_process
	stop_auto_channel_process
}
get_wpa_auth()
{
	WPA_AUTH=""
	SYSCFG_SECURITY_MODE=`syscfg get $1_security_mode`
	case "$SYSCFG_SECURITY_MODE" in
	"disabled")
		WPA_AUTH="0"
		;;
	"wep")
		WPA_AUTH="1"
		;;
	"wpa-personal")
		WPA_AUTH="4"
		;;
	"wpa2-personal")
		WPA_AUTH="128"
		;;
	"wpa-mixed")
		WPA_AUTH="132"
		;;
	"wpa-enterprise")
		WPA_AUTH="2"
		;;
	"wpa2-enterprise")
		WPA_AUTH="64"
		;;
	"wpa-enterprise-mixed")
		WPA_AUTH="66"
		;;
	*)
		WPA_AUTH="0"
		;;
	esac
	echo "$WPA_AUTH"	
}
get_wsec() {
	WSEC="0"
	ENC_MODE=`syscfg get $1_encryption`
	SEC_TYPE=`syscfg get $1_security_mode`
	if [ -z "$ENC_MODE" ]; then
		case "$SEC_TYPE" in 
			"wpa-mixed")
				WSEC="6"
				;;
			"wpa2-personal")
				WSEC="4"
				;;
			"wpa-personal")
				WSEC="6"
				;;
		esac
	elif [ "disabled" != "$SEC_TYPE" ]; then
		case "$ENC_MODE" in
			"aes")
				WSEC="4"
				;;
			"tkip")
				WSEC="2"
				;;
			"tkip+aes")
				WSEC="6"
				;;
			"wep")
				WSEC="1"
				;;
			"wep-auto")
				WSEC="1"
				;;
			"wep-open")
				WSEC="1"
				;;
			"wep-shared")
				WSEC="1"
				;;
		esac
	fi
	echo "$WSEC"	
}
