#!/bin/sh
WL0_WPS_STATE=`sysevent get wl0_wps_status`
WL1_WPS_STATE=`sysevent get wl1_wps_status`
display_usage() {
	echo "start_brcm_wps wps_pbc or wps_pin with station pin" > /dev/console
	exit
}
if [ "configured" = "$WL0_WPS_STATE" ] || [ "unconfigured" = "$WL0_WPS_STATE" ] || [ "configured" = "$WL1_WPS_STATE" ] || [ "unconfigured" = "$WL1_WPS_STATE" ]; then
	sysevent set wps_process incomplete
	if [ "wps_pbc" = "$1" ]; then
		/usr/sbin/start_brcm_wps wps_pbc
		sysevent set user_trigger_wps 1 
	elif [ "wps_pin" = "$1" ]; then
		if [ -z "$2" ]; then
			display_usage
		else
			sysevent set user_trigger_wps 1 
			/usr/sbin/start_brcm_wps wps_pin $2
		fi
	else
		display_usage
	fi
	sysevent set wps-running
else
	sysevent set wps-failed
fi
