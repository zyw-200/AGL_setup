#!/bin/sh
source /etc/init.d/service_wifi/wifi_utils.sh
source /etc/init.d/syscfg_api.sh
source /etc/init.d/ulog_functions.sh
source /etc/init.d/event_handler_functions.sh
set_driver_post_virtual_settings()
{
	set_driver_pspretend_threadhold $1
}
start_user()
{
	for PHY_IF in $PHYSICAL_IF_LIST; do
		bring_vir_if_down ${PHY_IF} 0
		bring_phy_if_down ${PHY_IF}
		WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`
		USER_VAP=`syscfg get "${WL_SYSCFG}"_user_vap`
		USER_VAP_STATE=`syscfg get ${WL_SYSCFG}_state`
		if [ "down" = "$USER_VAP_STATE" ]; then
			ulog wlan status "${SERVICE_NAME}, $USER_VAP is disable"
			continue
		fi
		if [ -z "$USER_VAP" ]; then
			ulog wlan status "${SERVICE_NAME}, something wrong, user vap name is empty"
			continue
		fi
		USER_SSID=`syscfg get "${WL_SYSCFG}"_ssid`
		if [ -z "$USER_SSID" ]; then 
			DEBUG wlan status "User VAP ssid  $WL_SYSCFG is empty"
			continue
		fi
		configure_user $USER_VAP
		set_driver_extra_virtual_settings $USER_VAP
		LAN_IFNAME=`syscfg get lan_ifname`
		add_interface_to_bridge $USER_VAP $LAN_IFNAME
	done
	return 0
}
stop_user()
{
	for PHY_IF in $PHYSICAL_IF_LIST; do
		WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`
		USER_VAP=`syscfg get "${WL_SYSCFG}"_user_vap`
		if [ -z "$USER_VAP" ]; then
			continue
		fi
		bring_vir_if_down ${PHY_IF} 0
		bring_phy_if_down $USER_VAP
		LAN_IFNAME=`syscfg get lan_ifname`
		delete_interface_from_bridge $USER_VAP $LAN_IFNAME
		ulog wlan status "${SERVICE_NAME}, user vap $USER_VAP is down"
		echo "${SERVICE_NAME}, user vap $USER_VAP is down"
	done
	return 0
}
wifi_user_start ()
{
	wait_till_end_state ${WIFI_USER}
	STATUS=`sysevent get ${WIFI_USER}-status`
	if [ "started" = "$STATUS" ] ; then
		ulog wlan status "${SERVICE_NAME}, ${WIFI_USER} is starting/started, ignore the request"
		return 1
	fi
	ulog wlan status "${SERVICE_NAME}, wifi_user_start()"
	sysevent set ${WIFI_USER}-status starting
	start_user
	sysevent set ${WIFI_USER}-status started
	return 0
}
wifi_user_stop ()
{
	wait_till_end_state ${WIFI_USER}
	STATUS=`sysevent get ${WIFI_USER}-status`
	if [ "stopped" = "$STATUS" ] || [ -z "$STATUS" ]; then
		ulog wlan status "${SERVICE_NAME}, ${WIFI_USER} is already stopping/stopped, ignore the request"
		return 0
	fi
	ulog wlan status "${SERVICE_NAME}, wifi_user_stop()"
	sysevent set ${WIFI_USER}-status stopping
	stop_user
	sysevent set ${WIFI_USER}-status stopped
	return 0
}
