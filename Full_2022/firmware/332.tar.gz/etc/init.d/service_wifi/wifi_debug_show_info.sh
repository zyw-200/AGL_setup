#!/bin/sh
ASSOC_FILE=/tmp/connected_list
INTF_LIST=`syscfg get lan_wl_physical_ifnames`
echo ""
echo "========================== WiFi Detail Information =========================="
echo -e "Driver Revision Info:\n`wl revinfo`"
for INTF in $INTF_LIST; do
	VIR_IFNAME=`syscfg get ${INTF}_syscfg_index`
	if [ "$VIR_IFNAME" = "wl0" ]; then
		IF_FRIENDLY_NAME="2.4GHz"
	else
		IF_FRIENDLY_NAME="5GHz"
	fi
	echo ""
	echo "---------- wifi: ${IF_FRIENDLY_NAME} driver configuration ----------" 			
	echo "Radio chip    	: `wl -i $INTF revinfo | grep chipnum | awk -F" " '{print $2}'`"
	echo "Country Regulation: `wl -i $INTF country`"
	echo "Available channels: `wl -i $INTF chan_info`"
	echo "Radio is on/off	: `wl -i $INTF radio`"
	echo "mbss          	: `wl -i $INTF mbss` (0=disable/1=enable)"
	echo "Phy IF        	: `wl -i $INTF isup` (0=down/1=up)"
	echo "User ap       	: `wl -i $INTF bss -C 0`"
	if [ "$VIR_IFNAME" = "wl0" ]; then
		echo "Guest ap     	: `wl -i $INTF bss -C 1`"
		echo "SimpleTap ap	:`wl -i $INTF bss -C 2`"
	fi
	echo "Physical type 	: `wl -i $INTF phytype`"
	echo "Chanspec $INTF	: `wl -i $INTF chanspec`"
	echo "nmode         	: `wl -i $INTF nmode`"
	echo "obss_coex     	: `wl -i $INTF obss_coex`"
	echo "Security suite	: `wl -i $INTF wpa_auth`"
	echo "Counters info 	: `wl -i $INTF counters`"
	BAND=`wl -i $INTF band`
	case "$BAND" in
		"a")
			echo "VHT mode 	: `wl -i $INTF vhtmode`"
			echo "bw_cap 5g	: `wl -i $INTF bw_cap 5g`"
			echo "mode_reqd	: `wl -i $INTF mode_reqd`"
			;;
		"b")
			echo "VHT mode 	: `wl -i $INTF vht_features`"
			echo "bw_cap 5g	: `wl -i $INTF bw_cap 2g`"
			echo "mode_reqd	: `wl -i $INTF mode_reqd`"
			echo "frameburst: `wl -i $INTF frameburst`"
			echo "ampdu_mpdu: `wl -i $INTF ampdu_mpdu`"
			echo "mpc		: `wl -i $INTF mpc`"
			echo "ack_ratio	: `wl -i $INTF ack_ratio`"
			;;
	esac
	
	if [ "1" = "`syscfg get ${VIR_IFNAME}_txbf_enabled`" ]; then
		echo "Beamforming setting	 	:"
		echo "txbf		: `wl -i $INTF txbf`"
		echo "txbf_bfr_cap	: `wl -i $INTF txbf_bfr_cap`"
		echo "txbf_bfe_cap	: `wl -i $INTF txbf_bfe_cap`"
		echo "stbc_tx	 	: `wl -i $INTF stbc_tx`"
	fi
		echo ""
		echo "---------- wifi: ${IF_FRIENDLY_NAME} acsd info ----------" 		
		echo "acsd $INTF 	:"
		echo "bss for $INTF: "
		echo "`acs_cli -i $INTF dump bss`"
		echo "candidate for $INTF: "
		echo "`acs_cli -i $INTF dump candidate`"
		echo "chanim for $INTF: "
		echo "`acs_cli -i $INTF dump chanim`"
	echo ""
	echo "---------- wifi: ${IF_FRIENDLY_NAME} association list ----------" 
	wl -i $INTF assoclist > $ASSOC_FILE"."$INTF".tmp"
	PROCESS=1
	FILESIZE=`stat -c%s $ASSOC_FILE"."$INTF".tmp"`
	if [ 0 = $FILESIZE ]; then
		PROCESS=0
	fi
	CLIENT_CNT=`cat $ASSOC_FILE"."$INTF".tmp" | wc -l`
	echo "There is $CLIENT_CNT client(s) on $INTF"
	while read line
	do
		STA_MAC=`echo $line | awk -F" " '{print $2}'`
		wl -i $INTF sta_info $STA_MAC
		wl -i $INTF rssi $STA_MAC
		echo "rssi=`wl -i $INTF rssi $STA_MAC`"
	done < $ASSOC_FILE"."$INTF".tmp"
	echo ""
	echo "---------- wifi: ${IF_FRIENDLY_NAME} scanning results ----------" 
	wl -i $INTF scan
	sleep 3
	wl -i $INTF scanresults
done
WLLIST="/tmp/wliflist"
ifconfig | grep wl | awk '{print $1}' > "$WLLIST"
while read line
do
		echo "Client(s) on interface $line"
	echo "`wl -i $line assoclist`"
done < "$WLLIST"
rm -rf "$WLLIST"
