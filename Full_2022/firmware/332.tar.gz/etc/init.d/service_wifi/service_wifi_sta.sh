#!/bin/sh
source /etc/init.d/ulog_functions.sh
source /etc/init.d/event_handler_functions.sh
source /etc/init.d/service_wifi/wifi_sta_utils.sh
SERVICE_NAME="wifi_sta"
WIFI_DEBUG_SETTING=`syscfg get ${SERVICE_NAME}_debug`
DEBUG() 
{
    [ "$WIFI_DEBUG_SETTING" = "1" ] && $@
}
DEBUG set -x
service_init()
{
	ulog wlan status "${SERVICE_NAME}, service_init()"
	SYSCFG_FAILED='false'
	FOO=`utctx_cmd get wifi_sta_enabled wifi_sta_radio wifi_sta_ssid bridge_mode`
	eval $FOO
	if [ $SYSCFG_FAILED = 'true' ] ; then
		ulog wlan status "${SERVICE_NAME}, $PID utctx failed to get some configuration data required by service-forwarding"
		DEBUG echo "[utopia] THE SYSTEM IS NOT SANE" > /dev/console
		sysevent set ${SERVICE_NAME}-status error
		sysevent set ${SERVICE_NAME}-errinfo "Unable to get crucial information from syscfg"
		return 0
	fi
}
service_start()
{
	ulog wlan status "${SERVICE_NAME}, service_start()"
	DEBUG echo "Start ${SERVICE_NAME}" > /dev/console
}
service_stop()
{
	ulog wlan status "${SERVICE_NAME}, service_stop()"
	bring_down_sta_link
	DEBUG echo "Stop ${SERVICE_NAME}" > /dev/console
}
service_restart()
{
	ulog wlan status "${SERVICE_NAME}, service_restart()"
	service_stop
	service_start
}
bring_down_sta_link()
{
	if [ "1" != "`syscfg get wifi_sta_enabled`" ] || [ "started" != "`sysevent get lan-status`" ] ; then
		return
	fi
	STA_IF=`syscfg get wifi_sta_user_vap`
	if [ "eth1" = "$STA_IF" ] || [ "eth2" = "$STA_IF" ]; then
		wl -i $STA_IF down
	fi
	sysevent set wifi_sta_up 0
	WIFI_PREFIX=`syscfg get wifi_sta_nvram_ifname`
	IFS_FILE=/tmp/wifi_sta_list.txt
	ifconfig -a | awk -v search=$WIFI_PREFIX '$0 ~ search {print $1}' > "$IFS_FILE"
	while read line
	do
		wl -i $line down
	done < "$IFS_FILE"
	echo -e "\n"
}
update_sta_link()
{
	if [ "1" != "`syscfg get wifi_sta_enabled`" ] || [ "started" != "`sysevent get lan-status`" ] ; then
		return
	fi
	WIFI_STA_UP=`sysevent get wifi_sta_up`
	if [ "1" != "$WIFI_STA_UP" ]; then
		exit
	fi
	WIFI_PREFIX=`syscfg get wifi_sta_nvram_ifname`
	IFS_FILE=/tmp/wifi_sta_list.txt
	ifconfig -a | awk -v search=$WIFI_PREFIX '$0 ~ search {print $1}' > "$IFS_FILE"
	ulog wlan status "Hotplug: Insert a new interface" 
	while read line
	do
		CHECK=`wl -i $line status | grep BSSID`
		if [ -z "$CHECK" ]; then
			wifi_sta_join $line
			sleep 1
		fi
	done < "$IFS_FILE"
	echo -e "\n"
	sysevent set system_state-normal
}
service_init 
case "$1" in
	${SERVICE_NAME}-start)
		service_start
		;;
	${SERVICE_NAME}-stop)
		service_stop
		;;
	${SERVICE_NAME}-restart)
		service_restart
		;;
	notification_event-device-online)
		update_sta_link
		;;
	notification_event-device-offline)
		update_sta_link
		;;
	notification_event-hotplug)
		update_sta_link
		;;
	*)
	echo "Usage: service-${SERVICE_NAME} [ ${SERVICE_NAME}-start | ${SERVICE_NAME}-stop | ${SERVICE_NAME}-restart]" > /dev/console
		exit 3
		;;
esac
