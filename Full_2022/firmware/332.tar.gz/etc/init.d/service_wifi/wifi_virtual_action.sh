#!/bin/sh
source /etc/init.d/service_wifi/wifi_utils.sh
source /etc/init.d/ulog_functions.sh
source /etc/init.d/event_handler_functions.sh
source /etc/init.d/service_wifi/service_wps.sh
source /etc/init.d/service_wifi/wifi_platform_specific_setting.sh
source /etc/init.d/syscfg_api.sh
source /etc/init.d/service_wifi/wifi_user.sh
source /etc/init.d/service_wifi/wifi_guest.sh
source /etc/init.d/service_wifi/wifi_wl1_guest.sh
source /etc/init.d/service_wifi/wifi_simpletap.sh
wifi_virtual_onetime_setting()
{
	ulog wlan status "${SERVICE_NAME}, wifi_virtual_onetime_setting"
	platform_virtual_onetime_setting
}
start_sub_components()
{
	ulog wlan status "${SERVICE_NAME}, ${VIRTUAL_ACTION}, start_sub_components()"
	wifi_simpletap_start
	wifi_wl0_guest_start
	wifi_wl1_guest_start
}
stop_sub_components()
{
	ulog wlan status "${SERVICE_NAME}, ${VIRTUAL_ACTION}, stop_sub_components()"
	wifi_wl0_guest_stop
	wifi_wl1_guest_stop
	wifi_simpletap_stop
}
wifi_virtual_action_start ()
{	
	wait_till_end_state ${VIRTUAL_ACTION}
	STATUS=`sysevent get ${VIRTUAL_ACTION}-status`
	if [ "started" = "$STATUS" ] || [ "starting" = "$STATUS" ] ; then
		ulog wlan status "${SERVICE_NAME}, ${VIRTUAL_ACTION} is starting/started, ignore the request"
		return 1
	fi
	ulog wlan status "${SERVICE_NAME}, wifi_virtual_action_start()"
	sysevent set ${VIRTUAL_ACTION}-status starting
	wifi_user_start	
	start_eapd_wps_nas
	sleep 2
	
	for PHY_IF in $PHYSICAL_IF_LIST; do
		WL_SYSCFG=`get_syscfg_interface_name $PHY_IF`
		USER_VAP=`syscfg get "${WL_SYSCFG}"_user_vap`
		USER_VAP_STATE=`syscfg get ${WL_SYSCFG}_state`
		if [ "down" = "$USER_VAP_STATE" ]; then
			ulog wlan status "${SERVICE_NAME}, $USER_VAP is disable"
			continue
		fi
		if [ -z "$USER_VAP" ]; then
			ulog wlan status "${SERVICE_NAME}, something wrong, user vap name is empty"
			continue
		fi
		USER_SSID=`syscfg get "${WL_SYSCFG}"_ssid`
		if [ -z "$USER_SSID" ]; then 
			DEBUG wlan status "User VAP ssid  $WL_SYSCFG is empty"
			continue
		fi
		ifconfig ${PHY_IF} up
		bring_phy_if_up ${PHY_IF}
		bring_vir_if_up ${PHY_IF} 0
		set_driver_post_virtual_settings $USER_VAP
		if [ "${WL_SYSCFG}" = "wl0" ] ; then
			set_driver_24VHT ${PHY_IF}
		fi
		ulog wlan status "${SERVICE_NAME}, user vap $USER_VAP is up"
		echo "${SERVICE_NAME}, user vap $USER_VAP is up"
	done
	start_sub_components
	set_driver_mac_filter
	/etc/init.d/service_wifi/chanspecfix.sh &
	update_wifi_cache "virtual"
	if [ "1" != "`syscfg get User_Accepts_WiFi_Is_Unsecure`" ] && [ "disabled" != "`syscfg get wl0_security_mode`" ] && [ "disabled" != "`syscfg get wl1_security_mode`" ] && [ "1" = "`syscfg get device::hw_revision`" ] ; then
		MODEL_NUMBER=`syscfg get device::modelNumber`
		case "$MODEL_NUMBER" in
			EA2700* | EA6500*)
				ulog wlan status "disable the redirection, skip the unsecured pages"
				syscfg_set User_Accepts_WiFi_Is_Unsecure 1 # use smart syscfg_set (not "syscfg set")
				sysevent set ctf-restart
				sysevent set firewall-restart
				;;
			*)
				;;
		esac
	fi
	sysevent set ${VIRTUAL_ACTION}-status started
	return 0
}
wifi_virtual_action_stop ()
{
	wait_till_end_state ${VIRTUAL_ACTION}
	STATUS=`sysevent get ${VIRTUAL_ACTION}-status`
	if [ "stopped" = "$STATUS" ] || [ "stopping" = "$STATUS" ] || [ -z "$STATUS" ]; then
		ulog wlan status "${SERVICE_NAME}, ${VIRTUAL_ACTION} is already stopping/stopped, ignore the request"
		return 1
	fi
	ulog wlan status "${SERVICE_NAME}, wifi_virtual_action_stop()"
	sysevent set ${VIRTUAL_ACTION}-status stopping
	stop_sub_components
	stop_eapd_wps_nas 
	wifi_user_stop	
	sysevent set ${VIRTUAL_ACTION}-status stopped
	return 0
}
wifi_virtual_action_restart()
{
	ulog wlan status "${SERVICE_NAME}, wifi_virtual_action_restart()"
	wifi_virtual_action_stop
	wifi_virtual_action_start
}
