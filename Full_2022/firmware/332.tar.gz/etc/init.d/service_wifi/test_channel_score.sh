#!/bin/sh
echo "Hint: cmd option. Option 0)For all, 1)For 2.4GHz(default), 2)For 5GHz)"
OPTION=$1
case "$OPTION" in
		"0")
		IF_2G_INDEX=`syscfg get wl0_physical_ifname | cut -c4`
		IF_5G_INDEX=`syscfg get wl1_physical_ifname | cut -c4`
		IFS_TOKENS="`echo $IF_2G_INDEX` `echo $IF_5G_INDEX`"
		;;
		"1")
		IF_2G_INDEX=`syscfg get wl0_physical_ifname | cut -c4`
		IF_5G_INDEX=""
		IFS_TOKENS="`echo $IF_2G_INDEX`"
		;;
		"2")
		IF_2G_INDEX=""
		IF_5G_INDEX=`syscfg get wl1_physical_ifname | cut -c4`
		IFS_TOKENS="`echo $IF_5G_INDEX`"
		;;
		*)
		IF_2G_INDEX=`syscfg get wl0_physical_ifname | cut -c4`
		IF_5G_INDEX=""
		IFS_TOKENS="`echo $IF_2G_INDEX`"
		;;
esac
get_point() {
	LINE="$1"
	POINT=0
	POINT=`echo "$LINE" | awk -F" " '{total=$2+$3+$4+$5+$6+$7+$8+$9+$10+$11+$12+$13; print total}'`
	echo "$POINT"
}
for TOKEN in $IFS_TOKENS
do
	FILE_IN=/tmp/eth"$TOKEN"_in.txt
	FILE_OUT=/tmp/eth"$TOKEN"_out.txt
	FILE_SORT=/tmp/eth"$TOKEN"_sorted.txt
	BEST_CHANNEL=0
	rm -f "$FILE_IN"
	rm -f "$FILE_OUT"
	rm -f "$FILE_SORT"
	acs_cli -i eth"$TOKEN" dump bss > "$FILE_IN"
	while read line
	do
		HEADER=`echo $line | grep -in channel`
		if [ -n "$HEADER" ]; then
			continue
		fi
		POINT=`get_point "$line"`
		CHANNEL_NUM=`echo "$line" | awk -F" " '{print $1}'`
		echo "$POINT on $CHANNEL_NUM" >> "$FILE_OUT"
	done < "$FILE_IN"
	sort -n "$FILE_OUT" > "$FILE_SORT"
	BEST_CHANNEL=`head -n 1 "$FILE_SORT" | awk -F " " '{print $3}'`
	if ! [ "$BEST_CHANNEL" -eq "$BEST_CHANNEL" ] 2>/dev/null ; then
		return
	fi
	BAND_TYPE=`wl -i eth"$TOKEN" band`
	CUR_CHAN=`wl -i eth"$TOKEN" status | grep "Primary channel" | awk -F" " '{print $3}'`
	echo "Current selected channel $CUR_CHAN"
	if [ "a" = "$BAND_TYPE" ]; then
		echo "Best channel on 5GHZ is $BEST_CHANNEL"
	else
		echo "Best channel on 2.4GHZ is $BEST_CHANNEL"
	fi
	echo -e "Channel \tScore"
	while read line
	do
		CHAN=`echo $line | awk -F" " '{print $3}'`
		SCORE=`echo $line | awk -F" " '{print $1}'`
		case "$CHAN" in
		"$BEST_CHANNEL")
			echo -e "$CHAN(Best) \t$SCORE"
			;;
		"$CUR_CHAN")
			echo -e "$CHAN(Selected) \t$SCORE"
			;;
		*)
			echo -e "$CHAN \t\t$SCORE"
			;;
		esac
	done < "$FILE_SORT"
done
