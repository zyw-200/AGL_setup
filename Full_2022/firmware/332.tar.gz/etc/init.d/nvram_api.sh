nvram_set()
{
	name=$1
	new_value=$2
	current_value=`nvram get "$name"`
	if [ "$current_value" != "$new_value" ]; then
		nvram set "$name"="$new_value"
		sysevent set NVRAM_DIRTY "1"
	fi
}
nvram_unset()
{
	name=$1
	current_value=`nvram get "$name"`
	if [ ! -z "$current_value" ]; then
		nvram unset "$name"
		sysevent set NVRAM_DIRTY "1"
	fi
}
nvram_commit()
{
	if [ "1" = "`sysevent get NVRAM_DIRTY`" ] ; then
		nvram commit
		sysevent set NVRAM_DIRTY "0"
	fi
}
