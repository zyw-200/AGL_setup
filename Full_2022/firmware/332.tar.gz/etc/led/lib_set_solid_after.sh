#!/bin/sh

. /etc/led/lib_led_functions.sh

SetSolidAfter $1
