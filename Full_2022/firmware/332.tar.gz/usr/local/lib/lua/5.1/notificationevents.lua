#!/usr/bin/lua

--
-- 2013 Belkin International, Inc. and/or its affiliates. All rights reserved.
--
-- $Author$
-- $DateTime$
-- $Id$
--

-- notificaitonevents.lua - script to execute notification events generated
-- in the JNAP services layer

local util = require('util')
local platform = require('platform')
local sysctx = require('libsysctxlua')

local eventName, eventValue = arg[1], arg[2] or ''
-- Notification events must have a name and payload
if not eventName or eventValue == 'NULL' then
    return
end

local logFile
local logPath = os.getenv('NOTIFICATION_EVENTS_LOG_PATH')
if logPath then
    logFile = io.open(logPath, 'a+')
end

local function log(level, message)
    if logFile then
        logFile:write(level..': '..message)
        logFile:write('\n')
    else
        io.stderr:write(level..': '..message..'\n')
    end
end

platform.registerLoggingCallback(log)

log(platform.LOG_INFO, string.format('Received event %s with value "%s".', eventName, eventValue))

local function deviceNotification(deviceID, isOnline)
    if deviceID ~= 'NULL' then
        local sc = sysctx.new()
        sc:writelock()

        -- Clear out the event
        sc:setevent(isOnline and 'notification_event-device-online' or 'notification_event-device-offline', '')

        sc:commit()

        local error = require('notification').deviceNotification(sc, deviceID, isOnline)
        if error and error ~= 'ErrorDeviceNotificationDisabled' then -- Ignore device notification disabled error
            platform.logMessage(platform.LOG_ERROR, ('Failed to do device notification with error "%s"\n'):format(error))
        end
    end
end
local function notifyDeviceOffline(deviceID)
    deviceNotification(deviceID, false)
end
local function notifyDeviceOnline(deviceID)
    deviceNotification(deviceID, true)
end

--
-- Add your event handler here
--
-- The handler will be called with the event value (or '') as the only parameter.
--
local handlers = {
    ['notification_event-device-online'] = notifyDeviceOnline,
    ['notification_event-device-offline'] = notifyDeviceOffline
}


local handler = handlers[eventName]
if handler then
    local success, error = pcall(handler, eventValue)
    if success then
        log(platform.LOG_INFO, string.format('Handled event %s.', eventName))
    else
        log(platform.LOG_ERROR, string.format('Handler for event %s failed (%s).', eventName, error))
    end
else
    log(platform.LOG_ERROR, string.format('No handler found for event %s.', eventName))
end

if logFile then
    logFile:close()
end
